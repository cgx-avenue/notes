const Mock = require('mockjs')
const { number } = require('yargs')


const data = Mock.mock({
    "basicInfo": "上海市嘉定区马陆镇博学路1258号 西门子FASO样板工厂; \r\n技术负责人：李虎",
    "cycle": 90,
    "maintenanceRecord": [
        {
            "alarmCode": "1200",
            "times": 41,
            "top": "Lifter_11003HE Bearing17",
            "type": "Vibration anomaly"
        },
        {
            "alarmCode": "1100",
            "times": 39,
            "top": "Lifter_11003HE Bearing3",
            "type": "Vibration anomaly"
        },
        {
            "alarmCode": "1100",
            "times": 38,
            "top": "Lifter_11003HE Bearing20",
            "type": "Vibration anomaly"
        },
        {
            "alarmCode": "1100",
            "times": 37,
            "top": "Lifter_11003HE Bearing15",
            "type": "Vibration anomaly"
        },
        {
            "alarmCode": "1200",
            "times": 37,
            "top": "Lifter_11003HE Bearing16",
            "type": "Vibration anomaly"
        }
    ]
},

)

module.exports = [
    {
        url: '/failureTop/area/.+',
        type: 'get',
        response: () => {
            
            return {
                code: 20000,
                body: {
                    basicInfo: data.basicInfo,
                    cycle: data.cycle,
                    maintenanceRecord: data.maintenanceRecord,

                },
                message: "OK"
            }
        }
    },

]


