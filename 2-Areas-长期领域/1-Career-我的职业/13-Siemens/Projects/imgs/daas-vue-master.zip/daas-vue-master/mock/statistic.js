const Mock = require('mockjs')

const data = Mock.mock({
  statistic: [
    {
      "areaName": "输送线",
      "highAlertNum": 22,
      "mediumAlertNum": 10,
      "poritory": "high",
      "totalNum": 2
    },
    {
      "areaName": "物流线",
      "highAlertNum": 7,
      "mediumAlertNum": 4,
      "poritory": "high",
      "totalNum": 2
    },
    {
      "areaName": "装配线",
      "highAlertNum": 11,
      "mediumAlertNum": 15,
      "poritory": "high",
      "totalNum": 5
    },
    {
      "areaName": "测试线",
      "highAlertNum": 0,
      "mediumAlertNum": 0,
      "poritory": "healthy",
      "totalNum": 0
    }
  ],
  week: {
    "areaMaintenance": {
      "areaName": "测试线",
      "basicInfo": "上海市嘉定区马陆镇博学路1258号 西门子FASO样板工厂; 技术负责人：李虎",
      "maintenanceRecord": [
        {
          "alarm": 0,
          "solvedAlarm": 0,
          "solvedWarning": 0,
          "warning": 0,
          "week": 30
      },
      {
          "alarm": 8,
          "solvedAlarm": 6,
          "solvedWarning": 3,
          "warning": 4,
          "week": 29
      },
      {
          "alarm": 6,
          "solvedAlarm": 6,
          "solvedWarning": 3,
          "warning": 3,
          "week": 28
      },
      {
          "alarm": 8,
          "solvedAlarm": 8,
          "solvedWarning": 4,
          "warning": 4,
          "week": 27
      },
      {
          "alarm": 6,
          "solvedAlarm": 6,
          "solvedWarning": 3,
          "warning": 3,
          "week": 26
      },
      {
          "alarm": 8,
          "solvedAlarm": 8,
          "solvedWarning": 4,
          "warning": 4,
          "week": 25
      },
      {
          "alarm": 6,
          "solvedAlarm": 6,
          "solvedWarning": 3,
          "warning": 3,
          "week": 24
      },
      {
          "alarm": 4,
          "solvedAlarm": 4,
          "solvedWarning": 2,
          "warning": 2,
          "week": 23
      }
      ],
      "priority": "healthy"
    }
  },
  month: {
    "areaMaintenance": {
      "areaName": "测试线",
      "basicInfo": "上海市嘉定区马陆镇博学路1258号 西门子FASO样板工厂; 技术负责人：李虎",
      "maintenanceRecord": [
        {
          "alarm": 18,
          "month": "July",
          "solvedAlarm": 16,
          "solvedWarning": 8,
          "warning": 9
        },
        {
          "alarm": 26,
          "month": "June",
          "solvedAlarm": 26,
          "solvedWarning": 13,
          "warning": 13
        },
        {
          "alarm": 26,
          "month": "May",
          "solvedAlarm": 26,
          "solvedWarning": 13,
          "warning": 13
        },
        {
          "alarm": 30,
          "month": "April",
          "solvedAlarm": 30,
          "solvedWarning": 15,
          "warning": 15
        },
        {
          "alarm": 31,
          "month": "March",
          "solvedAlarm": 31,
          "solvedWarning": 15,
          "warning": 15
        },
        {
          "alarm": 10,
          "month": "February",
          "solvedAlarm": 10,
          "solvedWarning": 5,
          "warning": 5
        }
      ],
      "priority": "healthy"
    }
  },

})

/// YSP, 2021-07-16
/// tmd, 这里是有顺序的,这才是终极解决方案
module.exports = [
  {
    /// YSP, 2021-07-16
    /// regexp finallllllllll solution
    url: '/statistic/area/.+/timeWindow/month',
    type: 'get',
    response: () => {
      return {
        code: 20000,
        body: {
          data: data.month
        },
        message: "OK"
      }
    }
  },
  {
    /// YSP, 2021-07-16
    /// regexp finallllllllll solution
    url: '/statistic/area/.+/timeWindow/week',
    type: 'get',
    response: () => {
      return {
        code: 20000,
        body: {
          data: data.week
        },
        message: "OK"
      }
    }
  },

  {
    url: '/statistic',
    type: 'get',
    response: () => {
      /// YSP, should be modified if connected to previous DaaS backend
      /// please refer to
      /// https://blog.csdn.net/chen798213337/article/details/111300947
      /// but, in fact, only make code : 20000 will solve this problem
      return {
        code: 20000,
        body: {
          statistic: data.statistic
        },
        message: "OK"
      }
    }
  },

]
