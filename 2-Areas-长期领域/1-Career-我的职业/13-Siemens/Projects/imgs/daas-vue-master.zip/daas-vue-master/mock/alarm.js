const Mock = require('mockjs')

const data = Mock.mock({
    alarmList: [
        {
            "alarmID": 3816,
            "alertTime": "2021-07-06 09:32:45",
            "components": [
                {
                    "pointName": "Bearing16",
                    "pointPriority": "high"
                },
                {
                    "pointName": "Bearing15",
                    "pointPriority": "medium"
                }
            ],
            "deviceNum": "Lifter_11003HE",
            "deviceType": "HighSpeed Lifter",
            "priority": "high",
            "status": 0
        },
        {
            "alarmID": 3815,
            "alertTime": "2021-07-06 09:32:35",
            "components": [
                {
                    "pointName": "Bearing17",
                    "pointPriority": "high"
                }
            ],
            "deviceNum": "Lifter_11003HE",
            "deviceType": "HighSpeed Lifter",
            "priority": "high",
            "status": 0
        },
        {
            "alarmID": 3817,
            "alertTime": "2021-07-06 09:32:55",
            "components": [
                {
                    "pointName": "Bearing3",
                    "pointPriority": "medium"
                },
                {
                    "pointName": "Bearing20",
                    "pointPriority": "medium"
                }
            ],
            "deviceNum": "Lifter_11003HE",
            "deviceType": "HighSpeed Lifter",
            "priority": "medium",
            "status": 0
        }
    ],
    alarmList2: [
        {
            "alarmID": 3817,
            "alertTime": "2021-07-06 09:32:55",
            "completeTime": null,
            "components": [
                {
                    "pointName": "Bearing3",
                    "pointPriority": "medium"
                },
                {
                    "pointName": "Bearing20",
                    "pointPriority": "medium"
                }
            ],
            "deviceNum": "Lifter_11003HE",
            "deviceType": "HighSpeed Lifter",
            "priority": "medium",
            "status": 0
        },
        {
            "alarmID": 3816,
            "alertTime": "2021-07-06 09:32:45",
            "completeTime": null,
            "components": [
                {
                    "pointName": "Bearing16",
                    "pointPriority": "high"
                },
                {
                    "pointName": "Bearing15",
                    "pointPriority": "medium"
                }
            ],
            "deviceNum": "Lifter_11003HE",
            "deviceType": "HighSpeed Lifter",
            "priority": "high",
            "status": 0
        },
        {
            "alarmID": 3815,
            "alertTime": "2021-07-06 09:32:35",
            "completeTime": "2021-07-09 09:33:22",
            "components": [
                {
                    "pointName": "Bearing17",
                    "pointPriority": "high"
                }
            ],
            "deviceNum": "Lifter_11003HE",
            "deviceType": "HighSpeed Lifter",
            "priority": "high",
            "status": 1
        }
    ],
    alarmIndicate: [
        {
            "alarmCode": "1200",
            "alarmType": "Vibration anomaly",
            "alertTime": "2021-07-06 09:32:45",
            "areaName": "输送线",
            "components": [
                {
                    "number": 3,
                    "pointName": "Bearing16",
                    "pointPriority": "high",
                    "spare_num": "SPS11003HE_Bearing16",
                    "timestamp": "2021-07-27 08:37:23",
                    "vendor": "SKF"
                },
                {
                    "number": 4,
                    "pointName": "Bearing10",
                    "pointPriority": "medium",
                    "spare_num": "SPS11003HE_Bearing10",
                    "timestamp": "2021-07-12 10:29:50",
                    "vendor": "SKF"
                }
            ],
            "deviceNum": "Lifter_11003HE",
            "deviceType": "HighSpeed Lifter",
            "lineName": "输送线",
            "priority": "high",
            "status": 1
        }
    ],
    suggestions: [
        {
            "component": "Motor",
            "queue": 1,
            "requireSkill": null,
            "sugCode": "ACT0001",
            "suggestion": "Check if any external scrap influence, like iron filings, gungo or junk"
        },
        {
            "component": "Motor",
            "queue": 2,
            "requireSkill": null,
            "sugCode": "ACT0002",
            "suggestion": "Check if any human disturbance, like carelessness, or operation parameter changed"
        },
        {
            "component": "Motor",
            "queue": 3,
            "requireSkill": null,
            "sugCode": "ACT0003",
            "suggestion": "Check bearing's lubricating oil status"
        },
        {
            "component": "Motor",
            "queue": 4,
            "requireSkill": null,
            "sugCode": "ACT0006",
            "suggestion": "Check noise and temperature and give system feedback"
        },
        {
            "component": "Motor",
            "queue": 5,
            "requireSkill": null,
            "sugCode": "ACT0008",
            "suggestion": "Schedule maintenance and do afterwork test"
        }
    ]
})

module.exports = [
    {
        url: '/alarm/deviceAlarm/area/.+/line/.+/priority/.+',
        type: 'get',
        response: () => {
            return {
                code: 20000,
                body:{
                    alarmList:data.alarmList
                    //.concat(data.alarmList).concat(data.alarmList)
                    //.concat(data.alarmList).concat(data.alarmList)
                    //.concat(data.alarmList).concat(data.alarmList)
                }, 

                
                message: "OK"
            }
        }
    },
    {
        url: '/historyAlarm/area/.+/line/.+/deviceNum/.+',
        type: 'get',
        response: () => {
            return {
                code: 20000,
                body: {
                    alarmList: data.alarmList2
                    //.concat(data.alarmList2).concat(data.alarmList2).concat(data.alarmList2).concat(data.alarmList2).concat(data.alarmList2).concat(data.alarmList2),
                },
                message: "OK"
            }
        }
    },
    {
        url: '/alarm/indicate/alarmID/.+',
        type: 'get',
        response: () => {
            return {
                code: 20000,
                body: {
                    alarmIndicate: data.alarmIndicate
                },
                message: "OK"
            }
        }
    },
    {
        url: '/alarm/suggestion/alarmID/.+',
        type: 'get',
        response: () => {
            return {
                code: 20000,
                body: {
                    suggestions: data.suggestions
                },
                message: "OK"
            }
        }
    },
]