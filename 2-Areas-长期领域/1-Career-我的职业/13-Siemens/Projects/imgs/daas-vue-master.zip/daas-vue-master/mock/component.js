
const Mock = require('mockjs')

const data = Mock.mock({

    queryComponent: [
        {
            "component": "Bearing1",
            "number": 10,
            "spare_num": "SPS11003HE_Bearing1",
            "timestamp": "2019-08-21 13:33:04",
            "vendor": "SKF"
        },
        {
            "component": "Bearing2",
            "number": 5,
            "spare_num": "SPS11003HE_Bearing2",
            "timestamp": "2019-08-21 13:34:03",
            "vendor": "SKF"
        },
        {
            "component": "Bearing3",
            "number": 4,
            "spare_num": "SPS11003HE_Bearing3",
            "timestamp": "2019-08-21 13:34:48",
            "vendor": "SKF"
        },
        {
            "component": "Bearing4",
            "number": 5,
            "spare_num": "SPS11003HE_Bearing4",
            "timestamp": "2019-08-21 13:35:19",
            "vendor": "FAG"
        },
        {
            "component": "Bearing5",
            "number": 6,
            "spare_num": "SPS11003HE_Bearing5",
            "timestamp": "2019-08-21 13:36:48",
            "vendor": "FAG"
        },
        {
            "component": "Bearing6",
            "number": 7,
            "spare_num": "SPS11003HE_Bearing6",
            "timestamp": "2019-08-21 13:37:31",
            "vendor": "INA"
        },
        {
            "component": "Bearing7",
            "number": 3,
            "spare_num": "SPS11003HE_Bearing7",
            "timestamp": "2019-08-21 13:38:04",
            "vendor": "SKF"
        },
        {
            "component": "Bearing8",
            "number": 5,
            "spare_num": "SPS11003HE_Bearing8",
            "timestamp": "2019-08-21 13:38:34",
            "vendor": "SKF"
        },
        {
            "component": "Bearing9",
            "number": 4,
            "spare_num": "SPS11003HE_Bearing9",
            "timestamp": "2019-08-21 13:39:32",
            "vendor": "INA"
        },
        {
            "component": "Bearing10",
            "number": 4,
            "spare_num": "SPS11003HE_Bearing10",
            "timestamp": "2019-08-21 13:40:59",
            "vendor": "SKF"
        },
        {
            "component": "Bearing11",
            "number": 3,
            "spare_num": "SPS11003HE_Bearing11",
            "timestamp": "2019-08-21 13:41:45",
            "vendor": "INA"
        },
        {
            "component": "Bearing12",
            "number": 4,
            "spare_num": "SPS11003HE_Bearing12",
            "timestamp": "2019-08-21 13:42:14",
            "vendor": "FAG"
        },
        {
            "component": "Bearing13",
            "number": 3,
            "spare_num": "SPS11003HE_Bearing13",
            "timestamp": "2019-08-21 13:42:52",
            "vendor": "FAG"
        },
        {
            "component": "Bearing14",
            "number": 2,
            "spare_num": "SPS11003HE_Bearing14",
            "timestamp": "2019-08-21 13:43:23",
            "vendor": "INA"
        },
        {
            "component": "Bearing15",
            "number": 3,
            "spare_num": "SPS11003HE_Bearing15",
            "timestamp": "2019-08-21 13:43:54",
            "vendor": "INA"
        },
        {
            "component": "Bearing16",
            "number": 3,
            "spare_num": "SPS11003HE_Bearing16",
            "timestamp": "2019-08-21 13:44:28",
            "vendor": "SKF"
        },
        {
            "component": "Bearing17",
            "number": 3,
            "spare_num": "SPS11003HE_Bearing17",
            "timestamp": "2019-08-21 13:44:57",
            "vendor": "INA"
        },
        {
            "component": "Bearing18",
            "number": 4,
            "spare_num": "SPS11003HE_Bearing18",
            "timestamp": "2019-08-21 13:45:38",
            "vendor": "SKF"
        },
        {
            "component": "Bearing19",
            "number": 5,
            "spare_num": "SPS11003HE_Bearing19",
            "timestamp": "2019-08-21 13:46:12",
            "vendor": "INA"
        },
        {
            "component": "Bearing20",
            "number": 3,
            "spare_num": "SPS11003HE_Bearing20",
            "timestamp": "2019-08-21 13:46:43",
            "vendor": "SKF"
        }

    ],

})


module.exports = [
    {
        /// need modification
        url: '/deviceManagement/queryComponent/.+',
        type: 'get',
        response: () => {
            return {
                code: 20000,
                body: data.queryComponent,
                message: "OK"

            }
        }

    }

]