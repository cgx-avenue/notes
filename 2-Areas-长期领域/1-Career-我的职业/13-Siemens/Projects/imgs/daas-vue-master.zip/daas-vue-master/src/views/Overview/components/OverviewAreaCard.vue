<template>
  <div style="height: 600px">
    <el-scrollbar style="height: 100%">
      <el-row>
        <el-col
          style="width: 25%"
          v-for="area in statList"
          :key="area.areaName"
        >
          <el-container class="card">
            <el-header :class="area.poritory + 'AlertBgLogo elheader'">
              <div style="margin-top: 5px">
                {{ area.areaName }}
              </div>
              <div style="margin-left: 20px; margin-top: 10px">
                {{ area.areaName }}
              </div>
            </el-header>
            <el-main>
              <el-row>
                <el-col :span="8" class="infoAlertText">{{
                  "设备数量：" + area.totalNum
                }}</el-col>
                <el-col :span="8" class="highAlertText">{{
                  "高级报警：" + area.highAlertNum
                }}</el-col>
                <el-col :span="8" class="mediumAlertText">{{
                  "中级报警：" + area.mediumAlertNum
                }}</el-col>
              </el-row>
              <el-row style="margin-top: 5%">
                <el-col :span="8" :offset="8">
                  <el-button
                    type="primary"
                    plain
                    @click="showAreaDialog(true, area)"
                    >统计概览</el-button
                  >
                </el-col>
                <el-col :span="8">
                  <el-button
                    type="primary"
                    plain
                    @click="gotoAlarm(area.areaName)"
                    >告警详情</el-button
                  >
                </el-col>
              </el-row>
            </el-main>
          </el-container>
        </el-col>
      </el-row>
    </el-scrollbar>
    <!-- 
                YSP, 2021-07-05
                1. for auto refresh by timer, please refer to 
                    https://www.cnblogs.com/rever/p/10565042.html
                2. for el-dialog as a child component, please refer to
                    https://blog.csdn.net/weixin_44296432/article/details/107817302
                    https://www.cnblogs.com/moon-yyl/p/13163536.html

                YSP, 2021-08-02
                notice the v-if below!!!

             -->
    <overview-area-stat
      :dialogShow.sync="dialogVisible"
      :area="currentArea"
      :key="Math.random()"
      v-if="dialogVisible"
    ></overview-area-stat>
  </div>
</template>

<script>
import OverviewAreaStat from "./OverviewAreaStat";

export default {
  name: "OverviewAreaCard",
  props: { statList: Array },
  components: { OverviewAreaStat },
  data() {
    return {
      dialogVisible: false,
      currentArea: null,
    };
  },

  methods: {
    showAreaDetail(visible) {
      this.dialogVisible = visible;
    },
    showAreaDialog(visible, area) {
      this.dialogVisible = visible;
      this.currentArea = area;
    },
    gotoAlarm(areaName) {
      this.$router.push({ name: "alarmPara", params: { area: areaName } });
    },
  },
};
</script>

<style lang="scss" scoped>
@import "../../../styles/variables.scss";
/*  YSP,2021-07-01
    added to delete horizontal scrollbar
    but not effective, :(
*/

.card {
  height: 180px;
  box-shadow: rgb(156, 153, 153) 5px 5px 10px;
  width: 96%;
  margin: 2%;
  transition: 0.1s;
}

.el-scrollbar__wrap {
  overflow-x: hidden;
}

.card:hover {
  transform: scale(1.03);
}

.el-main {
  background-color: #e9eef3;
  text-align: left;
}
.el-button {
  margin-right: 20px;
  float: right;
}
.elheader {
  color: white;
  text-align: left;
  //height: 10px;
  //min-height: 10px;
}
</style>