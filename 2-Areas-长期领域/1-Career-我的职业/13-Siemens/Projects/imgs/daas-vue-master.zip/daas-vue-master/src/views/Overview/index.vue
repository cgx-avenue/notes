<template>
  <div>
    <overview-summary :stat="stat" ></overview-summary>
 
    <el-divider></el-divider>
    <!-- 
        YSP, 2021-07-01 
        plese refer to 
        https://cn.vuejs.org/v2/guide/components-props.html#%E4%BC%A0%E5%85%A5%E4%B8%80%E4%B8%AA%E6%95%B0%E7%BB%84 
        for how to pass an array to a component through prop
    -->
    <overview-area-card :stat-list="areaStatList" ></overview-area-card>
  </div>
</template>

<script>
import { getStat } from "@/api/statistic";

// YSP, 2021-06-30
// really shit
// 1. please refer to https://www.cnblogs.com/xym0710/p/14722849.html
// cannot write import {areaStat} here
// 2. please refer to https://blog.csdn.net/qq_41654729/article/details/117849352
// cannot write with .vue here
import OverviewAreaCard from "./components/OverviewAreaCard";
import OverviewSummary from "./components/OverviewSummary";


export default {
  data() {
    return {
      intervalId: null,
      areaStatList: null,
      stat: {
        facTitle: "FAW-VW 成都工厂",
        facIntro:
          "四川省成都市成龙大道三段 177号 一汽大众成都分公司; 技术负责人：李虎",
        deviceCnt: 0,
        areaCnt:0,
        highAlertNum: 0,
        mediumAlertNum: 0,
        status: "good",
      },
    };
  },
  components: {
    OverviewAreaCard: OverviewAreaCard,
    OverviewSummary: OverviewSummary,
    
  },
  /*  YSP, 2021-07-01
      if auto refresh is needed, please refer to below page via using Vue intercal timer
      https://www.cnblogs.com/aurora-ql/p/13300202.html
      
      As for websocket push, later.      
  */
  created() {
    this.fetchData();
  },
  mounted() {
    this.dataRefresh();
  },
  destroyed() {
    this.clearTimer();
  },

  methods: {
    fetchData() {
      getStat().then((response) => {
        this.areaStatList = response.body.statistic;
        for (var i = 0; i < this.areaStatList.length; i++) {
          this.stat.areaCnt++;
          this.stat.deviceCnt += this.areaStatList[i].totalNum;
          this.stat.highAlertNum += this.areaStatList[i].highAlertNum;
          this.stat.mediumAlertNum += this.areaStatList[i].mediumAlertNum;
          if (this.areaStatList[i].poritory === "medium") {
            this.stat.status = "medium";
          } else if (this.areaStatList[i].poritory === "high") {
            this.stat.status = "high";
          }
        }
      });
    },

    // YSP, 2021-07-02
    // for vue timer, please refer to
    // https://www.cnblogs.com/aurora-ql/p/13300202.html

    dataRefresh() {
      // 计时器正在进行中，退出函数
      if (this.intervalId != null) {
        return;
      }

      // 计时器为空，操作.
      // default reload interval = 5s
      this.intervalId = setInterval(() => {
        console.log("刷新" + new Date());
        this.resetStat();
        this.fetchData();
      }, 5000);
    },
    // stop the timer
    clearTimer() {
      clearInterval(this.intervalId);
      this.intervalId = null;
    },
    resetStat() {
      this.stat.areaCnt=0;
      this.stat.deviceCnt = 0;
      this.stat.highAlertNum = 0;
      this.stat.mediumAlertNum = 0;
      //this.stat.status = "good";
    },
  },
};
</script>

<style  scoped>
</style>
