<script>
// to store global varables here if not so many and not so much
// so when no need to use vuex
// https://www.cnblogs.com/yangchin9/p/11002636.html
  const timeWindow = '周';
//   function add(a,b) {
//     return a+ b
//   }
  export default {
    timeWindow,
    //add
    
  }
</script>