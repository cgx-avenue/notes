<template>
  <div class="history-alarm">
    <device-selector
      @onSubmit="onSubmit"
      :showDevice="true"
      :showTimePicker="true"
    ></device-selector>
    <el-divider></el-divider>
    <el-table
      :data="
        tableData.slice((currentPage - 1) * pageSize, currentPage * pageSize)
      "
      style="width: 80%; margin-left: 3%"
    >
      <el-table-column
        prop="status"
        label="状态"
        sortable
        :filters="[
          { text: '待处理', value: '待处理' },
          { text: '已完成', value: '已完成' },
        ]"
        :filter-method="filterStatus"
        filter-placement="bottom-end"
      >
        <template slot-scope="scope">
          <el-tag
            style="width: 70px; text-align: center"
            :type="scope.row.status === '已完成' ? 'success' : 'danger'"
            disable-transitions
            effect="dark"
            >{{ scope.row.status }}</el-tag
          >
        </template>
      </el-table-column>
      <el-table-column prop="alertTime" label="报警时间" sortable width="180">
      </el-table-column>
      <el-table-column prop="deviceNum" label="设备"> </el-table-column>
      <el-table-column prop="deviceType" label="类型"> </el-table-column>
      <el-table-column prop="component" label="组件"> </el-table-column>

      <el-table-column prop="completeTime" label="完成时间" sortable>
      </el-table-column>
      <el-table-column prop="details" label="维护详情">
        <template slot-scope="scope">
          <router-link
            :to="'/alarmdetail/' + scope.row.alarmID"
            style="color: blue"
            >维护详情</router-link
          >
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      style="text-align: center"
      background
      layout="prev, pager, next"
      :total="total"
      :current-page="currentPage"
      @current-change="current_change"
    >
    </el-pagination>
  </div>
</template>

<script>
import { getDeviceHistoryAlarm } from "@/api/alarm";
import DeviceSelector from "@/components/DeviceSelector/index";

export default {
  components: { DeviceSelector },
  data() {
    return {
      tableData: [],
      currentPage: 1,
      total: 0, //count of table items
      pageSize: 10,
    };
  },

  methods: {
    onSubmit(form) {
      this.tableData = [];
      console.log("submit!");
      getDeviceHistoryAlarm(
        form.area === "" ? "*" : form.area,
        form.area === "" ? "*" : form.area,
        form.device === "" ? "*" : form.device,
        form.dpValue[0],
        form.dpValue[1]
      ).then((resp) => {
        var items = resp.body.alarmList;
        for (let index = 0; index < items.length; index++) {
          var temp = items[index];
          var cpts = "";
          for (let index2 = 0; index2 < temp.components.length; index2++) {
            var cpt = temp.components[index2];
            cpts += cpt.pointName + ", ";
          }
          this.tableData.push({
            alarmID: temp.alarmID,
            alertTime: temp.alertTime,
            deviceNum: temp.deviceNum,
            deviceType: temp.deviceType,
            component: cpts.substr(0, cpts.length - 2),
            priority: temp.priority,
            status: temp.status === 0 ? "待处理" : "已完成",
            completeTime: temp.completeTime,
          });
        }
        this.currentPage = 1;
        this.current_change(this.currentPage);
        this.total = this.tableData.length;
      });
    },
    // pagination
    current_change(currentPage) {
      this.currentPage = currentPage;
    },
    filterStatus(value, row) {
      return row.status === value;
    },
  },
};
</script>

<style  >
</style>
