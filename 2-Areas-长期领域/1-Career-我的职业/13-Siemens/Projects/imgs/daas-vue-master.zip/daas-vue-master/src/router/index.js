import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'/'el-icon-x' the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  {
    path: '/about',
    component: () => import('@/views/About/index'),
    hidden: true
  },
  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },
 
  {
    path: '/',
    component: Layout,
    redirect: '/overview',
    children: [{
      path: 'overview',
      name: 'overview',
      component: () => import('@/views/Overview/index'),
      meta: { title: 'Overview', icon: 'dashboard' }
    }]
  },
  // below for newly added pages
  // /alarm route should be modified
  {
    path: '/alarm',
    //name:'alarm',
    component: Layout,
    redirect:"",
    children: [
      {
        path: ':area',
        component: () => import('@/views/Alarm/index'),
        name: 'alarmPara',
        meta: {
          title: 'Alarm',
          icon: 'alarm',
          activeMenu: '/alarm'
        },
        hidden:true
      },
      {
        path: '',
        component: () => import('@/views/Alarm/index'),
        name: 'alarm',
        meta: {
          title: 'Alarm',
          icon: 'alarm'
        },
        
      }
    ]
  },
  {
    // YSP, 2021-07-07
    // for parameter passing, with routerlink, please refer to below page
    // https://www.hangge.com/blog/cache/detail_2121.html
    path: '/alarmdetail/:alarmID',
    component: Layout,
    hidden: true,
    children: [
      {
        path: '',
        component: () => import('@/views/Alarm/AlarmDetail/index'),
        name: 'alarm-detail',
        meta: {
          title: "AlarmDetail",
          activeMenu: '/alarm'
        }

      }
    ]

  },
  {
    
    path: '/alarmdatainsight/:alarmID',
    component: Layout,
    hidden: true,
    children: [
      {
        path: '',
        component: () => import('@/views/Alarm/AlarmDataInsight/index'),
        name: 'alarm-data-insight',
        meta: {
          title: "AlarmDataInsight",
          activeMenu: '/alarm'
        }

      }
    ]

  },
  {
    path: '/datainsight',
    component: Layout,
    // YSP, 2021-06-30
    // please do not use name: in parent route level, otherwise it will output
    // warning in browser console
    // refer to https://blog.csdn.net/qq_25479327/article/details/79523092
    // name: 'device-data-insight',
    children: [
      {
        path: '',
        component: () => import('@/views/DataInsight/index'),
        name: 'datainsight',
        meta: {
          title: 'DataInsight',
          icon: 'datainsight'
        }
      }
    ]
  },

  {
    path: '/alarmhistory',
    component: Layout,
    children: [
      {
        path: '',
        component: () => import('@/views/AlarmHistory/index'),
        name: 'alarmhistory',
        meta: {
          title: 'AlarmHistory',
          icon: 'history'
        }
      }
    ]
  },
  {
    path: '/devicemanagement',
    component: Layout,
    children: [
      {
        path: '',
        component: () => import('@/views/DeviceManagement/index'),
        name: 'devicemanagement',
        meta: {
          title: 'DeviceManagement',
          icon: 'devicemanagement'
        }
      }
    ]
  },
  
  
  // 404 page must be placed at the end !!!
  { path: '*', redirect: '/404', hidden: true },

]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
