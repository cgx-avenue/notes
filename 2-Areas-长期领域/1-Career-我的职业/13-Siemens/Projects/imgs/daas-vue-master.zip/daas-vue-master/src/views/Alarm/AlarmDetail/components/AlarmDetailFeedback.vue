<template>
  <div class="feedback">
    <el-dialog
      title="反馈"
      :visible.sync="shownTriggered"
      width="30%"
      @close="closeCallback"
      @open="openCallback"
    >
      <el-form :model="form">
        <el-form-item label="报警是否准确？">
          <el-radio v-model="form.useful" label="yes">有用</el-radio>
          <el-radio v-model="form.useful" label="no">没用</el-radio>
        </el-form-item>
        <el-form-item label="维护状态">
          <el-select v-model="form.usefulSug" clearable placeholder="对应那一条维护建议？">
            <el-option
              v-for="line in tableData"
              :key="line.sug"
              :label="line.sug"
              :value="line.sug"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="真实维护建议描述">
          <el-input
            type="textarea"
            :rows="2"
            placeholder="请输入内容"
            v-model="form.text"
            maxlength="200"
            show-word-limit
            :autosize="{ minRows: 2, maxRows: 4}"
          >
          </el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="closeCallback">取 消</el-button>
        <el-button type="primary" @click="submit">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      form: {
        useful: "yes",
        usefulSug: "",
        text:""
      },
    };
  },
  props: {
    shown: {
      type: Boolean,
      default: false,
    },
    tableData: null,
  },
  methods: {
    closeCallback() {
      this.$emit("update:shown", false);
    },
    openCallback() {
        this.form.useful="yes";
        this.form.usefulSug="";
        this.form.text="";
    },
    submit(){
        /// need further implementation
        if(this.form.usefulSug===""){
            alert("维护状态不能为空！");
            return;

        }
    }
  },
  computed: {
    shownTriggered: {
      get() {
        return this.shown;
      },
      set(val) {
        this.$emit("update:shown", val);
      },
    },
  },
};
</script>

<style scoped>
</style>