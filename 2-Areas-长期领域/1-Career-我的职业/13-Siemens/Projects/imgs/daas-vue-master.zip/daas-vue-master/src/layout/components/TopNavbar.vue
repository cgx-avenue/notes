<template>
  <div>
    <el-menu
      mode="horizontal"
      background-color="#303030"
      text-color="#fff"
      active-text-color="#ffd04b"
    >
      <el-menu-item>
        <el-link style="font-size: 150%" type="primary" href="/" target="_self"
          >Maintenance Service</el-link
        >
      </el-menu-item>
      <el-menu-item style="float: right">
        <div class="right-menu">
          <el-dropdown class="avatar-container" trigger="click">
            <div class="avatar-wrapper">
              <img src="../../icons/png/user.png" class="user-avatar" />
              <i class="el-icon-caret-bottom" />
            </div>
            <el-dropdown-menu slot="dropdown" class="user-dropdown">
              <router-link to="/">
                <el-dropdown-item> Home </el-dropdown-item>
              </router-link>
              <el-dropdown-item divided @click.native="switchLang('CN')"
                >中文</el-dropdown-item
              >
              <el-dropdown-item @click.native="switchLang('EN')"
                >English</el-dropdown-item
              >
              <el-dropdown-item divided @click.native="logout">
                <span style="display: block">Log Out</span>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
        <el-link
          type="primary"
          style="margin-left: 20px; margin-right: 20px"
          href="/#/about"
          target="_blank"
          >Siemens. V0.0.1</el-link
        >
      </el-menu-item>
    </el-menu>
  </div>
</template>

<script>
export default {
  data() {
    return {
      language: "中文",
    };
  },

  methods: {
    async logout() {
      await this.$store.dispatch("user/logout");
      this.$router.push(`/login?redirect=${this.$route.fullPath}`);
    },
    switchLang(lang) {
      this.$message("click on item " + lang);
    },
  },
};
</script>
<style lang="scss" scoped>
.right-menu {
  float: right;
  height: 100%;
  line-height: 50px;

  &:focus {
    outline: none;
  }

  .right-menu-item {
    display: inline-block;
    padding: 0 8px;
    height: 100%;
    font-size: 18px;
    color: #5a5e66;
    vertical-align: text-bottom;

    &.hover-effect {
      cursor: pointer;
      transition: background 0.3s;

      &:hover {
        background: rgba(0, 0, 0, 0.025);
      }
    }
  }

  .avatar-container {
    margin-right: 30px;

    .avatar-wrapper {
      margin-top: 5px;

      position: relative;

      .user-avatar {
        cursor: pointer;
        width: 30px;
        height: 30px;
        border-radius: 10px;
      }

      .el-icon-caret-bottom {
        cursor: pointer;
        position: absolute;
        right: -20px;
        top: 25px;
        font-size: 12px;
      }
    }
  }
}
</style>
