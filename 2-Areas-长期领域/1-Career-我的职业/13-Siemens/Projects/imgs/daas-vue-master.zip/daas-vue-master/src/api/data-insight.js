import request from '@/utils/request'


export function getDataInsight(deviceNum, from, to) {
    return request({
        url: `/dataInsight/deviceNum/${deviceNum}`,
        method: 'get',
        params: { from: from, to: to, }

    })
}

export function getAlarmTS(alarmID,from,to){
    return request({
        url: `/dataInsight/TS/alarmID/${alarmID}`,
        method: 'get',
        params: { from: from, to: to, }

    })
}

export function getDataInsightFailure(deviceNum){
    return request({
        url: `/dataInsight/deviceFailure/deviceNum/${deviceNum}`,
        method: 'get',

    })

}