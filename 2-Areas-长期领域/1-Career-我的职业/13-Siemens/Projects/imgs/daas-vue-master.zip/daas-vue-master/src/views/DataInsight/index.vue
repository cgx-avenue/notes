<template>
  <div class="data-insight">
    <device-selector
      @onSubmit="onSubmit"
      :showDevice="true"
      :showTimePicker="true"
    ></device-selector>
    <el-divider></el-divider>
    <el-collapse
      style="margin: 20px; width: 1200px; height: 650px; min-height: 500px"
      v-model="activeNames"
      @change="handleChange"
    >
      <el-scrollbar style="height: 100%">
        <el-collapse-item
          v-for="prop in propData"
          :key="prop.propName"
          
          :name="prop.propName"
          ><template slot="title" style="font-size:200">
            <i class=" el-icon-cpu" style="margin-right:1%" ></i>
            {{ prop.propName }}
          </template>
          <div :id="prop.propName" style="width: 1200px; height: 300px"></div>
        </el-collapse-item>
      </el-scrollbar>
    </el-collapse>
  </div>
</template>

<script>
import { getDataInsight } from "@/api/data-insight";
import DeviceSelector from "@/components/DeviceSelector/index";
let Echarts = require("echarts/lib/echarts");
require("echarts/lib/chart/line");

export default {
  components: { DeviceSelector },
  data() {
    return {
      propData: [],
      activeNames: [], // for el-collapse
    };
  },

  methods: {
    handleChange(val) {
      console.log(val);
      var t = this.propData[1].data[0].data;
      //t = JSON.stringify(t);
      var xData = t.map((item) => {
        return item[0];
      });
      var yData = t.map((item) => {
        return item[1];
      });

      console.log(yData);
      // YSP, 2021-07-09, this.$refs is filled after all
      // the essence of this problem is v-for and v-if cannot be used together
      // so cannot use
      for (let index = 0; index < val.length; index++) {
        const element = val[index];
        this.initChart(xData, yData, element);
      }
    },
    initChart(xData, yData, name) {
      //this.chart = Echarts.init(this.$refs[name]);
      this.chart = Echarts.init(document.getElementById(name));
      let option = {
        xAxis: { type: "category", data: xData },
        yAxis: { type: "value" },
        series: [
          {
            symbolSize: 20,
            data: yData,
            type: "line",
          },
        ],
      };
      this.chart.setOption(option);
    },

    onSubmit(form) {
      console.log("submit!" + form.area);
      if (form.area === "" /*||form.line===""*/ || form.device === "") {
        alert("区域，产线，设备均不能为空！");
        return;
      }
      this.propData = [];
      getDataInsight(form.device, form.dpValue[0], form.dpValue[1]).then(
        (resp) => {
          var items = resp.body.TimeSeries;
          for (let index = 0; index < items.length; index++) {
            var dataTemp = [];
            var temp = items[index];
            //console.log(temp.data);
            var devices = [];
            for (let index2 = 0; index2 < temp.data.length; index2++) {
              const element = temp.data[index2];
              var timestamp = new Date(element["_time"]);
              // YSP, 2021-07-08
              // really full of shit
              //var keys = Object.keys(element);
              for (var el in element) {
                if (el != "_time" && el.indexOf("_qc") === -1) {
                  if (devices.indexOf(el) === -1) {
                    devices.push(el);
                    dataTemp.push({
                      device: el,
                      data: [[timestamp, element[el]]],
                    });
                  } else {
                    //console.log(el);
                    dataTemp
                      .find((item) => item.device == el)
                      .data.push([timestamp, element[el]]);
                  }
                }
              }
            }
            this.propData.push({
              propName: items[index].propertysetName,
              data: dataTemp,
            });
          }

          console.log(this.propData);
        }
      );
    },
  },
};
</script>

<style >
</style>
