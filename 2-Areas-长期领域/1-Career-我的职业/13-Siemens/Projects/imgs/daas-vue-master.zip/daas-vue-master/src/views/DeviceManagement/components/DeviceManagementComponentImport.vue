<template>
  <div class="deviceManagementComponentImport">
    <el-dialog
      title="组件信息导入"
      :visible.sync="shownTriggered"
      width="25%"
      @close="closeCallback"
      @open="openCallback"
    >
      <el-form :model="form">
        <el-alert
          title="注意事项"
          description="1. 请遵循导入模板，以免丢失信息。 2. 请注意设备ID具有唯一性，不能重复。"
          type="success"
          show-icon
          :closable="false"
        >
        </el-alert>
        <el-form-item
          label="设备类型"
          prop="deviceType"
          style="margin-left: 5%; margin-top: 2%"
        >
          <el-select
            style="width: 80%"
            v-model="form.deviceType"
            placeholder="请选择类型"
            clearable
          >
            <el-option
              v-for="device in deviceTypesList"
              :key="device"
              :label="device"
              :value="device"
            ></el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="设备信息" style="margin-left: 5%">
          <!-- need modification here -->
          <!-- https://element.eleme.cn/#/zh-CN/component/upload -->
          <el-upload action="none" accept=".csv, .xlsx">
            <el-button size="medium" plain type="primary"
              >点击上传(.csv, .xlsx)</el-button
            >
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="closeCallback">取 消</el-button>
        <el-button type="primary" @click="onSubmit">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { getDeviceTypes } from "@/api/device";
export default {
  props: {
    shown: {
      type: Boolean,
      default: false,
    },
  },

  data() {
    return {
      form: { deviceType: "" },
      deviceTypesList: null,
    };
  },
  created() {
    getDeviceTypes().then((resp) => {
      this.deviceTypesList = resp.body.typeList;
    });
  },
  methods: {
    /// YSP 2021-07-22
    /// need complete modification with el-upload together
    onSubmit() {},
    closeCallback() {
      this.$emit("update:shown", false);
    },
    openCallback() {
      this.form.deviceType = "";
    },
  },
  computed: {
    shownTriggered: {
      get() {
        return this.shown;
      },
      set(val) {
        this.$emit("update:shown", val);
      },
    },
  },
};
</script>
<style lang="sss" scoped>
</style>