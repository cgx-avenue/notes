<template>
  <div>
    <el-dialog
      title="设备导入"
      :visible.sync="shownTriggered"
      @close="closeCallback"
      width="22%"
    >
      <el-alert
        title="注意事项"
        description="1. 请遵循导入模板，以免丢失信息。 2. 请注意设备ID具有唯一性，不能重复。"
        type="success"
        show-icon
        :closable="false"
      >
      </el-alert>
      <!-- also need modification -->
      <el-upload drag action="none" multiple>
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">
          选中并拖动.cvs或者.xlsx文件到该区域以导入设备信息
        </div>
      </el-upload>

      <div slot="footer" class="dialog-footer">
        <el-button @click="closeCallback">取 消</el-button>
        <el-button @click="onSubmit" type="primary">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
export default {
  props: {
    shown: {
      type: Boolean,
      default: false,
    },
  },
  methods: {
    /// YSP 2021-07-22
    /// need complete modification with el-upload together
    onSubmit() {},
    closeCallback() {
      this.$emit("update:shown", false);
    },
  },
  computed: {
    shownTriggered: {
      get() {
        return this.shown;
      },
      set(val) {
        this.$emit("update:shown", val);
      },
    },
  },
};
</script>

<style scoped></style>