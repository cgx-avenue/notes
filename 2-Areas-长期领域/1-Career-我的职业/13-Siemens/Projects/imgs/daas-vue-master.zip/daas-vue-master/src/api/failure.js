import request from '@/utils/request'

// YSP, 2021-07-05
// areaname needed to be changed to unicode
// please refer to https://www.cnblogs.com/Rock-Lee/p/7146154.html

export function getFailureTop(areaName) {
    return request({
        url: `/failureTop/area/${areaName}`,
        method: 'get',
    
    })
}