/*
Navicat PGSQL Data Transfer

Source Server         : SiMaintDB
Source Server Version : 90424
Source Host           : localhost:63386
Source Database       : pod8495d3
Source Schema         : public

Target Server Type    : PGSQL
Target Server Version : 90424
File Encoding         : 65001

Date: 2020-04-02 09:01:24
*/


-- ----------------------------
-- Sequence structure for agv_device_status_id_seq
-- ----------------------------
CREATE SEQUENCE "public"."agv_device_status_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 1
 CACHE 1;
SELECT setval('"public"."agv_device_status_id_seq"', 1, true);

-- ----------------------------
-- Sequence structure for alarm_component_id_seq
-- ----------------------------
CREATE SEQUENCE "public"."alarm_component_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 1
 CACHE 1;
SELECT setval('"public"."alarm_component_id_seq"', 1, true);

-- ----------------------------
-- Sequence structure for alarm_id_seq
-- ----------------------------
CREATE SEQUENCE "public"."alarm_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 1
 CACHE 1;
SELECT setval('"public"."alarm_id_seq"', 1, true);

-- ----------------------------
-- Sequence structure for area_id_seq
-- ----------------------------
CREATE SEQUENCE "public"."area_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 4
 CACHE 1;
SELECT setval('"public"."area_id_seq"', 4, true);
-- ----------------------------
-- Sequence structure for componentinfo_id_seq
-- ----------------------------
CREATE SEQUENCE "public"."componentinfo_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 1
 CACHE 1;
SELECT setval('"public"."componentinfo_id_seq"', 1, true);

-- ----------------------------
-- Sequence structure for device_id_seq
-- ----------------------------
CREATE SEQUENCE "public"."device_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 14
 CACHE 1;
SELECT setval('"public"."device_id_seq"', 14, true);

-- ----------------------------
-- Sequence structure for deviceType_id_seq
-- ----------------------------
CREATE SEQUENCE "public"."deviceType_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 7
 CACHE 1;
SELECT setval('"public"."deviceType_id_seq"', 7, true);

-- ----------------------------
-- Sequence structure for feedback_id_seq
-- ----------------------------
CREATE SEQUENCE "public"."feedback_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 1
 CACHE 1;
SELECT setval('"public"."feedback_id_seq"', 1, true);

-- ----------------------------
-- Sequence structure for line_id_seq
-- ----------------------------
CREATE SEQUENCE "public"."line_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 4
 CACHE 1;
 SELECT setval('"public"."line_id_seq"', 4, true);

-- ----------------------------
-- Sequence structure for suggestion_id_seq
-- ----------------------------
CREATE SEQUENCE "public"."suggestion_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 1
 CACHE 1;
SELECT setval('"public"."suggestion_id_seq"', 1, true);

-- ----------------------------
-- Table structure for agv_device_status
-- ----------------------------
DROP TABLE IF EXISTS "public"."agv_device_status";
CREATE TABLE "public"."agv_device_status" (
"id" int4 DEFAULT nextval('agv_device_status_id_seq'::regclass) NOT NULL,
"deviceType" varchar(100) COLLATE "default",
"eventType" int4,
"priority" varchar(20) COLLATE "default",
"position" float8,
"motorTemp" float8,
"actSpeed" float8,
"motorVibration" float8,
"alarmId" int4,
"load" bool,
"direction" float8
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for alarm
-- ----------------------------
DROP TABLE IF EXISTS "public"."alarm";
CREATE TABLE "public"."alarm" (
"id" int4 DEFAULT nextval('alarm_id_seq'::regclass) NOT NULL,
"devicenum" varchar(25) COLLATE "default" NOT NULL,
"type" varchar(50) COLLATE "default",
"alarm_type" varchar(60) COLLATE "default",
"priority" varchar(25) COLLATE "default" NOT NULL,
"timestamp" timestamp(6) NOT NULL,
"status" int4 NOT NULL,
"completetime" timestamp(6),
"other" varchar(100) COLLATE "default",
"alarm_code" varchar(10) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for alarm_component
-- ----------------------------
DROP TABLE IF EXISTS "public"."alarm_component";
CREATE TABLE "public"."alarm_component" (
"id" int4 DEFAULT nextval('alarm_component_id_seq'::regclass) NOT NULL,
"alarm_id" int4 NOT NULL,
"component" varchar(25) COLLATE "default" NOT NULL,
"priority" varchar(25) COLLATE "default" NOT NULL,
"other" varchar(100) COLLATE "default",
"component_type" varchar(60) COLLATE "default" NOT NULL,
"check_time" timestamp(6),
"error_code" varchar(10) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for area
-- ----------------------------
DROP TABLE IF EXISTS "public"."area";
CREATE TABLE "public"."area" (
"id" int4 DEFAULT nextval('area_id_seq'::regclass) NOT NULL,
"area" varchar(25) COLLATE "default" NOT NULL,
"basic_info" varchar(200) COLLATE "default",
"timestamp" timestamp(6),
"other" varchar(100) COLLATE "default"
)
WITH (OIDS=FALSE)

;
-- ----------------------------
-- Records of area
-- ----------------------------
-- ----------------------------
-- Records of area
-- ----------------------------
INSERT INTO "public"."area" VALUES ('1', '输送线', '上海市嘉定区马陆镇博学路1258号 西门子FASO样板工厂; 
技术负责人：李虎', '2019-08-09 09:43:31', null);
INSERT INTO "public"."area" VALUES ('2', '物流线', '上海市嘉定区马陆镇博学路1258号 西门子FASO样板工厂; 技术负责人：张宇乐', '2019-08-09 09:43:42', null);
INSERT INTO "public"."area" VALUES ('3', '装配线', '上海市嘉定区马陆镇博学路1258号 西门子FASO样板工厂; 技术负责人：张宇乐', '2019-08-09 09:43:10', null);
INSERT INTO "public"."area" VALUES ('4', '测试线', '上海市嘉定区马陆镇博学路1258号 西门子FASO样板工厂; 技术负责人：李虎', '2019-08-09 09:42:59', null);

-- ----------------------------
-- Table structure for componentinfo
-- ----------------------------
DROP TABLE IF EXISTS "public"."componentinfo";
CREATE TABLE "public"."componentinfo" (
"id" int4 DEFAULT nextval('componentinfo_id_seq'::regclass) NOT NULL,
"device_type" varchar(50) COLLATE "default" NOT NULL,
"component" varchar(25) COLLATE "default" NOT NULL,
"spare_num" varchar(50) COLLATE "default",
"number" int4 NOT NULL,
"vendor" varchar(50) COLLATE "default",
"timestamp" timestamp(6),
"other" varchar(200) COLLATE "default",
"other1" varchar(200) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of componentinfo
-- ----------------------------
INSERT INTO "public"."componentinfo" VALUES ('1', 'HighSpeed Lifter', 'Bearing1', 'SPS11003HE_Bearing1', '10', 'SKF', '2019-08-21 13:33:04', null, null);
INSERT INTO "public"."componentinfo" VALUES ('2', 'HighSpeed Lifter', 'Bearing2', 'SPS11003HE_Bearing2', '5', 'SKF', '2019-08-21 13:34:03', null, null);
INSERT INTO "public"."componentinfo" VALUES ('3', 'HighSpeed Lifter', 'Bearing3', 'SPS11003HE_Bearing3', '4', 'SKF', '2019-08-21 13:34:48', null, null);
INSERT INTO "public"."componentinfo" VALUES ('4', 'HighSpeed Lifter', 'Bearing4', 'SPS11003HE_Bearing4', '5', 'FAG', '2019-08-21 13:35:19', null, null);
INSERT INTO "public"."componentinfo" VALUES ('5', 'HighSpeed Lifter', 'Bearing5', 'SPS11003HE_Bearing5', '6', 'FAG', '2019-08-21 13:36:48', null, null);
INSERT INTO "public"."componentinfo" VALUES ('6', 'HighSpeed Lifter', 'Bearing6', 'SPS11003HE_Bearing6', '7', 'INA', '2019-08-21 13:37:31', null, null);
INSERT INTO "public"."componentinfo" VALUES ('7', 'HighSpeed Lifter', 'Bearing7', 'SPS11003HE_Bearing7', '3', 'SKF', '2019-08-21 13:38:04', null, null);
INSERT INTO "public"."componentinfo" VALUES ('8', 'HighSpeed Lifter', 'Bearing8', 'SPS11003HE_Bearing8', '5', 'SKF', '2019-08-21 13:38:34', null, null);
INSERT INTO "public"."componentinfo" VALUES ('9', 'HighSpeed Lifter', 'Bearing9', 'SPS11003HE_Bearing9', '4', 'INA', '2019-08-21 13:39:32', null, null);
INSERT INTO "public"."componentinfo" VALUES ('10', 'HighSpeed Lifter', 'Bearing10', 'SPS11003HE_Bearing10', '4', 'SKF', '2019-08-21 13:40:59', null, null);
INSERT INTO "public"."componentinfo" VALUES ('11', 'HighSpeed Lifter', 'Bearing11', 'SPS11003HE_Bearing11', '3', 'INA', '2019-08-21 13:41:45', null, null);
INSERT INTO "public"."componentinfo" VALUES ('12', 'HighSpeed Lifter', 'Bearing12', 'SPS11003HE_Bearing12', '4', 'FAG', '2019-08-21 13:42:14', null, null);
INSERT INTO "public"."componentinfo" VALUES ('13', 'HighSpeed Lifter', 'Bearing13', 'SPS11003HE_Bearing13', '3', 'FAG', '2019-08-21 13:42:52', null, null);
INSERT INTO "public"."componentinfo" VALUES ('14', 'HighSpeed Lifter', 'Bearing14', 'SPS11003HE_Bearing14', '2', 'INA', '2019-08-21 13:43:23', null, null);
INSERT INTO "public"."componentinfo" VALUES ('15', 'HighSpeed Lifter', 'Bearing15', 'SPS11003HE_Bearing15', '3', 'INA', '2019-08-21 13:43:54', null, null);
INSERT INTO "public"."componentinfo" VALUES ('16', 'HighSpeed Lifter', 'Bearing16', 'SPS11003HE_Bearing16', '3', 'SKF', '2019-08-21 13:44:28', null, null);
INSERT INTO "public"."componentinfo" VALUES ('17', 'HighSpeed Lifter', 'Bearing17', 'SPS11003HE_Bearing17', '3', 'INA', '2019-08-21 13:44:57', null, null);
INSERT INTO "public"."componentinfo" VALUES ('18', 'HighSpeed Lifter', 'Bearing18', 'SPS11003HE_Bearing18', '4', 'SKF', '2019-08-21 13:45:38', null, null);
INSERT INTO "public"."componentinfo" VALUES ('19', 'HighSpeed Lifter', 'Bearing19', 'SPS11003HE_Bearing19', '5', 'INA', '2019-08-21 13:46:12', null, null);
INSERT INTO "public"."componentinfo" VALUES ('20', 'HighSpeed Lifter', 'Bearing20', 'SPS11003HE_Bearing20', '3', 'SKF', '2019-08-21 13:46:43', null, null);
INSERT INTO "public"."componentinfo" VALUES ('21', 'Logistics AGV', 'Motor', 'SPSLogistics 15001FTS', '4', 'JiaShun', '2019-08-21 14:15:19', null, null);
INSERT INTO "public"."componentinfo" VALUES ('22', 'Cobot AGV', 'Motor', 'SPSCobot 1200FTS', '5', 'JiaTeng', '2019-08-21 14:16:09', null, null);
INSERT INTO "public"."componentinfo" VALUES ('23', 'Assembly AGV', 'Motor', 'SPSAssembly 14001FTS', '4', 'JiaTeng', '2019-08-21 14:17:55', null, null);
INSERT INTO "public"."componentinfo" VALUES ('24', 'AGV Simulator', 'Motor', 'SPSAGV Simulator MindDot', '2', 'CT IoT INW CN', '2019-11-21 16:02:31', null, null);

-- ----------------------------
-- Table structure for device
-- ----------------------------
DROP TABLE IF EXISTS "public"."device";
CREATE TABLE "public"."device" (
"id" int4 DEFAULT nextval('device_id_seq'::regclass) NOT NULL,
"line_id" int4 NOT NULL,
"device_num" varchar(25) COLLATE "default" NOT NULL,
"device_type" varchar(50) COLLATE "default",
"description" varchar(100) COLLATE "default",
"timestamp" timestamp(6),
"other" varchar(100) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of device
-- ----------------------------
INSERT INTO "public"."device" VALUES ('1', '1', 'Lifter_11003HE', 'HighSpeed Lifter', 'Conveyer Line HighSpeed Lifter', '2019-08-21 09:08:18', null);
INSERT INTO "public"."device" VALUES ('2', '2', 'LogisticsAGV_13001FTS', 'Logistics AGV', 'Logistics AGV', '2019-08-21 10:47:37', null);
INSERT INTO "public"."device" VALUES ('3', '2', 'LogisticsAGV_13002FTS', 'Logistics AGV', 'Logistics AGV', '2019-08-21 10:48:13', null);
INSERT INTO "public"."device" VALUES ('4', '4', 'CobotAGV_12001FTS', 'Cobot AGV', 'Cobot AGV', '2019-08-21 10:49:07', null);
INSERT INTO "public"."device" VALUES ('5', '4', 'CobotAGV_12002FTS', 'Cobot AGV', 'Cobot AGV', '2019-08-21 10:49:33', null);
INSERT INTO "public"."device" VALUES ('6', '4', 'AssemblyAGV_14001FTS', 'Assembly AGV', 'Assembly AGV', '2019-08-21 10:50:51', null);
INSERT INTO "public"."device" VALUES ('7', '4', 'AssemblyAGV_14002FTS', 'Assembly AGV', 'Assembly AGV', '2019-08-21 10:51:28', null);
INSERT INTO "public"."device" VALUES ('8', '4', 'MindDot', 'AGV Simulator', 'AGV Simulator', '2019-08-21 10:52:19', null);

-- ----------------------------
-- Table structure for deviceType
-- ----------------------------
DROP TABLE IF EXISTS "public"."deviceType";
CREATE TABLE "public"."deviceType" (
"id" int4 NOT NULL,
"typeName" varchar(50) COLLATE "default",
"updateTime" timestamp(6),
"other" varchar(100) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of deviceType
-- ----------------------------
INSERT INTO "public"."deviceType" VALUES ('1', 'HighSpeed Lifter', '2019-10-25 09:06:50', null);
INSERT INTO "public"."deviceType" VALUES ('2', 'Assembly AGV', '2019-10-25 09:07:40', null);
INSERT INTO "public"."deviceType" VALUES ('3', 'Cobot AGV', '2019-10-25 09:08:08', null);
INSERT INTO "public"."deviceType" VALUES ('4', 'Logistics AGV', '2019-10-25 09:10:47', null);
INSERT INTO "public"."deviceType" VALUES ('5', 'Marriage Line', '2019-10-25 09:11:06', null);
INSERT INTO "public"."deviceType" VALUES ('6', 'AGV Simulator', '2019-10-25 09:11:23', null);
INSERT INTO "public"."deviceType" VALUES ('7', 'End of Line', '2019-10-25 09:12:41', null);

-- ----------------------------
-- Table structure for feedback
-- ----------------------------
DROP TABLE IF EXISTS "public"."feedback";
CREATE TABLE "public"."feedback" (
"id" int4 DEFAULT nextval('feedback_id_seq'::regclass) NOT NULL,
"alarm_id" int4 NOT NULL,
"valid" int4,
"validQueue" int4,
"comments" varchar(200) COLLATE "default",
"timestamp" timestamp(6),
"other" varchar(100) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for line
-- ----------------------------
DROP TABLE IF EXISTS "public"."line";
CREATE TABLE "public"."line" (
"id" int4 DEFAULT nextval('line_id_seq'::regclass) NOT NULL,
"area_id" int4 NOT NULL,
"line" varchar(50) COLLATE "default",
"info" varchar(200) COLLATE "default",
"timestamp" timestamp(6),
"other" varchar(100) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO "public"."line" VALUES ('1', '1', '输送线', 'ShowRoom Lifter Test Line', '2019-08-21 08:38:23', null);
INSERT INTO "public"."line" VALUES ('2', '2', '物流线', 'ShowRoom Logistics Line', '2019-08-21 08:42:55', null);
INSERT INTO "public"."line" VALUES ('3', '4', '测试线', 'ShowRoom End of Line', '2019-08-21 10:44:22', null);
INSERT INTO "public"."line" VALUES ('4', '3', '装配线', 'ShowRoom Assembly Line', '2019-08-21 10:44:51', null);

-- ----------------------------
-- Table structure for process_data
-- ----------------------------
DROP TABLE IF EXISTS "public"."process_data";
CREATE TABLE "public"."process_data" (
"last_event_timestamp" timestamp(6),
"last_feedback_timestamp" timestamp(6),
"id" int4 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for suggestion
-- ----------------------------
DROP TABLE IF EXISTS "public"."suggestion";
CREATE TABLE "public"."suggestion" (
"id" int4 DEFAULT nextval('suggestion_id_seq'::regclass) NOT NULL,
"alarm_id" int4 NOT NULL,
"queue" int4 NOT NULL,
"suggestion" varchar(200) COLLATE "default",
"timestamp" timestamp(6),
"other" varchar(100) COLLATE "default",
"component" varchar(25) COLLATE "default",
"sugCode" varchar(10) COLLATE "default",
"requireSkill" varchar(20) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS "public"."user";
CREATE TABLE "public"."user" (
"id" int4 NOT NULL,
"email" varchar(50) COLLATE "default" NOT NULL,
"username" varchar(50) COLLATE "default" NOT NULL,
"password" varchar(50) COLLATE "default" NOT NULL,
"role" varchar(100) COLLATE "default" NOT NULL,
"updateTime" timestamp(6) NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Alter Sequences Owned By 
-- ----------------------------
ALTER SEQUENCE "public"."agv_device_status_id_seq" OWNED BY "agv_device_status"."id";

-- ----------------------------
-- Primary Key structure for table agv_device_status
-- ----------------------------
ALTER TABLE "public"."agv_device_status" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table alarm
-- ----------------------------
ALTER TABLE "public"."alarm" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table alarm_component
-- ----------------------------
ALTER TABLE "public"."alarm_component" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table area
-- ----------------------------
ALTER TABLE "public"."area" ADD UNIQUE ("area");

-- ----------------------------
-- Primary Key structure for table area
-- ----------------------------
ALTER TABLE "public"."area" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table componentinfo
-- ----------------------------
ALTER TABLE "public"."componentinfo" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table device
-- ----------------------------
ALTER TABLE "public"."device" ADD UNIQUE ("device_num");

-- ----------------------------
-- Primary Key structure for table device
-- ----------------------------
ALTER TABLE "public"."device" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table deviceType
-- ----------------------------
ALTER TABLE "public"."deviceType" ADD UNIQUE ("typeName");

-- ----------------------------
-- Primary Key structure for table deviceType
-- ----------------------------
ALTER TABLE "public"."deviceType" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table feedback
-- ----------------------------
ALTER TABLE "public"."feedback" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table line
-- ----------------------------
ALTER TABLE "public"."line" ADD UNIQUE ("line");

-- ----------------------------
-- Primary Key structure for table line
-- ----------------------------
ALTER TABLE "public"."line" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table process_data
-- ----------------------------
ALTER TABLE "public"."process_data" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table suggestion
-- ----------------------------
ALTER TABLE "public"."suggestion" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table user
-- ----------------------------
ALTER TABLE "public"."user" ADD UNIQUE ("username");

-- ----------------------------
-- Foreign Key structure for table "public"."alarm"
-- ----------------------------
ALTER TABLE "public"."alarm" ADD FOREIGN KEY ("devicenum") REFERENCES "public"."device" ("device_num") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Key structure for table "public"."alarm_component"
-- ----------------------------
ALTER TABLE "public"."alarm_component" ADD FOREIGN KEY ("alarm_id") REFERENCES "public"."alarm" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Key structure for table "public"."componentinfo"
-- ----------------------------
ALTER TABLE "public"."componentinfo" ADD FOREIGN KEY ("device_type") REFERENCES "public"."deviceType" ("typeName") ON DELETE RESTRICT ON UPDATE RESTRICT;

-- ----------------------------
-- Foreign Key structure for table "public"."device"
-- ----------------------------
ALTER TABLE "public"."device" ADD FOREIGN KEY ("device_type") REFERENCES "public"."deviceType" ("typeName") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "public"."device" ADD FOREIGN KEY ("line_id") REFERENCES "public"."line" ("id") ON DELETE RESTRICT ON UPDATE RESTRICT;

-- ----------------------------
-- Foreign Key structure for table "public"."feedback"
-- ----------------------------
ALTER TABLE "public"."feedback" ADD FOREIGN KEY ("alarm_id") REFERENCES "public"."alarm" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Key structure for table "public"."line"
-- ----------------------------
ALTER TABLE "public"."line" ADD FOREIGN KEY ("area_id") REFERENCES "public"."area" ("id") ON DELETE RESTRICT ON UPDATE RESTRICT;

-- ----------------------------
-- Foreign Key structure for table "public"."suggestion"
-- ----------------------------
ALTER TABLE "public"."suggestion" ADD FOREIGN KEY ("alarm_id") REFERENCES "public"."alarm" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;
