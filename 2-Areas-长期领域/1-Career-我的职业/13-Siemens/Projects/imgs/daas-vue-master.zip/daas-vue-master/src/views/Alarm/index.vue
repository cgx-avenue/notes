<template>
  <div class="alarm">
    <device-selector
      :selectedArea="this.$route.params.area"
      :showDevice="false"
      :showTimePicker="true"
      @onSubmit="onsubmit"
    ></device-selector>
    <el-divider></el-divider>
    <el-table
      
      :data="
        tableData.slice((currentPage - 1) * pageSize, currentPage * pageSize)
      "
      style="width: 100%; margin-left: 3%"
      highlight-current-row
    >
      <el-table-column
        prop="priority"
        label="报警类别"
        sortable
        :filters="[
          { text: '高级', value: 'high' },
          { text: '中级', value: 'medium' },
        ]"
        :filter-method="filterPriority"
        filter-placement="bottom-end"
        width="150"
      >
        <template slot-scope="scope">
          <el-tag
            style="width: 70px; text-align: center"
            :type="scope.row.priority === 'high' ? 'danger' : 'warning'"
            disable-transitions
            effect="dark"
            
            >{{ scope.row.priority.toUpperCase() }}</el-tag
          >
        </template>
      </el-table-column>
      <el-table-column prop="alertTime" label="报警时间" sortable width="180">
      </el-table-column>
      <el-table-column prop="deviceNum" label="设备"> </el-table-column>
      <el-table-column prop="deviceType" label="类型"> </el-table-column>
      <el-table-column prop="component" label="组件"> </el-table-column>
      <el-table-column prop="details" label="维护详情">
        <template slot-scope="scope">
          <router-link
            :to="'/alarmdetail/' + scope.row.alarmID"
            style="color: blue"
            >维护详情</router-link
          >
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      style="text-align: center"
      background
      layout="prev, pager, next"
      :total="total"
      :current-page="currentPage"
      @current-change="current_change"
    >
    </el-pagination>
  </div>
</template>

<script>
import { getDeviceAlarm } from "@/api/alarm";
import DeviceSelector from "@/components/DeviceSelector/index";
export default {
  components: { DeviceSelector },
  data() {
    return {
      tableData: [],
      currentPage: 1,
      total: 0, //count of table items
      pageSize: 10,
    };
  },
  
  methods: {
    onsubmit: function (form) {
      console.log("submit!" + form.area);

      this.tableData = [];
      getDeviceAlarm(
        form.area === "" ? "*" : form.area,
        form.area === "" ? "*" : form.area,
        "*",
        form.dpValue[0],
        form.dpValue[1]
      ).then((resp) => {
        var items = resp.body.alarmList;
        for (let index = 0; index < items.length; index++) {
          var temp = items[index];
          var cpts = "";
          for (let index2 = 0; index2 < temp.components.length; index2++) {
            var cpt = temp.components[index2];
            cpts += cpt.pointName + ", ";
          }
          this.tableData.push({
            alarmID: temp.alarmID,
            alertTime: temp.alertTime,
            deviceNum: temp.deviceNum,
            deviceType: temp.deviceType,
            component: cpts.substr(0, cpts.length - 2),
            priority: temp.priority,
          });
        }
        this.currentPage = 1;
        this.current_change(this.currentPage);
        this.total = this.tableData.length;
      });
    },
    // pagination
    current_change(currentPage) {
      this.currentPage = currentPage;
    },
    filterPriority(value, row) {
      return row.priority === value;
    },
  },
};
</script>

<style   >
</style>
