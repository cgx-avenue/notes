<template>
  <div class="device-selector">
    <el-form ref="form" :model="form" label-width="80px">
      <el-form-item label="设备信息"> </el-form-item>
      <el-row>
        <el-col :span="4">
          <el-form-item label="区域">
            <el-select
              v-model="form.area"
              placeholder="请选择区域"
              clearable
              @change="bindDevices(form.area)"
            >
              <el-option
                v-for="area in areaStatList"
                :key="area.areaName"
                :label="area.areaName"
                :value="area.areaName"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="4">
          <el-form-item label="产线">
            <!-- later should be changed to lineName cause current data doesn't have line  -->
            <el-select
              v-model="form.area"
              placeholder="请选择产线"
              @change="bindDevices(form.area)"
              clearable
            >
              <el-option
                v-for="area in areaStatList"
                :key="area.areaName"
                :label="area.areaName"
                :value="area.areaName"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <!-- device? -->
        <el-col :span="4">
          <el-form-item label="设备" v-show="showDevice">
            <!-- later should be changed to lineName cause current data doesn't have line  -->
            <el-select v-model="form.device" placeholder="请选择设备" clearable>
              <el-option
                v-for="device in deviceDetailList"
                :key="device"
                :label="device"
                :value="device"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item
            label="选择时间日期"
            label-width="150px"
            v-show="showTimePicker"
          >
            <el-date-picker
              v-model="form.dpValue"
              type="datetimerange"
              :picker-options="pickerOptions"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
            >
            </el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="4">
          <el-form-item>
            <el-button
              type="primary"
              icon="el-icon-search"
              @click="emitToParent"
              >查询</el-button
            >
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import { getStat } from "@/api/statistic";
import { getDeviceInfo } from "@/api/device";
export default {
  props: {
    selectedArea: String,
    selectedDevice: String,
    showDevice: Boolean,
    showTimePicker: Boolean,
  },

  data() {
    return {
      //selectedArea:this.selectedArea,
      form: {
        area: "",
        device: "",
        dpValue: "",
        line: "",
      },
      deviceInfoList: null,
      deviceDetailList: null,
      tableData: [],
      areaStatList: null,
      pickerOptions: {
        shortcuts: [
          {
            text: "前一天",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setDate(start.getDate() - 1);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近7天",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近30天",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "本月",
            onClick(picker) {
              const end = new Date();
              const start = new Date(
                end.getFullYear(),
                end.getMonth(),
                1,
                0,
                0,
                0
              );
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "上月",
            onClick(picker) {
              const now = new Date();
              var year = now.getFullYear();
              var month = now.getMonth();
              var end = new Date(year, month);
              month -= 1;
              if (month === 0) {
                month = 12;
                year = year - 1;
              }
              var start = new Date(year, month, 1);
              picker.$emit("pick", [start, end]);
            },
          },
        ],
      },
    };
  },
  mounted() {
    this.fetchData();
    this.initDatetimePicker();
    console.log(this.selectedArea);
    if (this.selectedArea != null) {
      this.form.area = this.selectedArea;
      this.emitToParent();
    }
    if (this.selectedDevice != null) {
      this.form.device = this.selectedDevice;
    }
    //this.onSubmit();
    // later will have to solve the para pass issue!!!!!!!!!!!!!!!!!!!!!!!!!!!
    ///this.form.area=$route.params.areaName;
  },

  methods: {
    emitToParent() {
      this.$emit("onSubmit", this.form);
    },
    fetchData() {
      getStat().then((response) => {
        this.areaStatList = response.body.statistic;
        console.log(this.areaStatList);
      });
      if (this.showDevice === false) {
        console.log(this.showDevice);
        return;
      }
      getDeviceInfo().then((resp) => {
        // YSP, 2021-07-08
        // really a 坑 here
        this.deviceInfoList = resp.body.deviceInfo[0].areas;
        console.log(this.deviceInfoList);
      });
    },
    initDatetimePicker() {
      if(this.showTimePicker===false){
        return;
      }
      this.form.dpValue = [
        /// YSP, 2021-07-20
        /// if not embedded in new Date(), it will return linux timestamp
        new Date(new Date().getTime() - 3600 * 1000 * 24 * 2),
        new Date(),
      ];
    },
    bindDevices(line) {
      if (this.showDevice === false) {
        console.log(this.showDevice);
        return;
      }
      this.deviceDetailList = null;
      this.form.device = "";
      // YSP, 2021-07-08
      // really shit
      for (var i = 0; i < this.deviceInfoList.length; i++) {
        if (this.deviceInfoList[i].name === line) {
          console.log(this.deviceInfoList[i].lines[0].devices);
          this.deviceDetailList = this.deviceInfoList[i].lines[0].devices;
          console.log(this.deviceDetailList);
        }
      }
    },
  },
};
</script>

<style scoped>
</style>