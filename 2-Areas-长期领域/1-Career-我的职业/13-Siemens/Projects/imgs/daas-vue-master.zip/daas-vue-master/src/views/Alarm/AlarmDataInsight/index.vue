<template>
  <div class="alarmDataInsight">
    <el-row>
      <el-col :span="12">
        <el-row style="margin-left: 3%; width: 100%; height: 500px">
          <div style="font-weight: bold">设备部件故障统计</div>
          <div ref="pieChart" style="width: 100%; height: 100%"></div>
        </el-row>
        <el-row style="margin-left: 3%">
          <el-col :span="16">
            <div style="font-weight: bold">当前报警故障</div>
            <el-image
              fit="scale-down"
              style="width: 90%; height: 80%"
            ></el-image>
          </el-col>
          <el-col :span="8">
            <div class="infoAlertText">设备类型:LogisticsAGV</div>
            <div style="margin-top: 20%" :class="alarmClass">
              设备编号:LogisticsAGV_13002FTS
            </div>
            <div style="margin-top: 20%" :class="alarmClass">维护级别:高</div>
            <div style="margin-top: 20%" :class="alarmClass">
              报警时间:2021-07-26 09:44:29
            </div>
          </el-col>
        </el-row>
      </el-col>
      <el-col :span="12">
        <div style="font-weight: bold">时间日期选择</div>
        <el-row style="margin-top: 2%">
          <el-col :span="16">
            <el-date-picker
              v-model="dpValue"
              type="datetimerange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
            ></el-date-picker>
          </el-col>
          <el-col :span="4">
            <el-button type="primary">查询</el-button>
          </el-col>
          <el-col :span="4">
            <el-button type="primary">下载报告</el-button>
          </el-col>
        </el-row>
        <el-row style="width: 100%; height: 700px; margin-top: 1%">
          <div ref="tsChart" style="width: 100%; height: 100%"></div>
        </el-row>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { getAlarmIndicate } from "@/api/alarm";
import { getDataInsightFailure, getAlarmTS } from "@/api/data-insight";
import deviceList from "@/assets/img/devicelocal.json";
let Echarts = require("echarts");
//require("echarts/lib/chart/pie");

export default {
  data() {
    return {
      alarmID: this.$route.params.alarmID,
      alarmIndicateInfo: { deviceType: "" },
      alarmClass: "",
      dpValue: [],
      pickerOptions: {
        shortcuts: [
          {
            text: "前一天",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setDate(start.getDate() - 1);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近7天",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近30天",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "本月",
            onClick(picker) {
              const end = new Date();
              const start = new Date(
                end.getFullYear(),
                end.getMonth(),
                1,
                0,
                0,
                0
              );
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "上月",
            onClick(picker) {
              const now = new Date();
              var year = now.getFullYear();
              var month = now.getMonth();
              var end = new Date(year, month);
              month -= 1;
              if (month === 0) {
                month = 12;
                year = year - 1;
              }
              var start = new Date(year, month, 1);
              picker.$emit("pick", [start, end]);
            },
          },
        ],
      },
    };
  },
  mounted() {
    this.initDatetimePicker();
    getAlarmIndicate(this.alarmID).then((resp) => {
      this.alarmIndicateInfo = resp.body.alarmIndicate[0];
      console.log(this.alarmIndicateInfo);
      console.log(this.alarmIndicateInfo.deviceType);
      if (this.alarmIndicateInfo["priority"] === "high") {
        this.alarmClass = "highAlertText";
      } else if (this.alarmIndicateInfo.priority === "medium") {
        this.alarmClass = "mediumAlertText";
      } else {
        this.alarmClass = "healthyAlertText";
      }
    });
    this.initPieChart();
    this.initTSChart();
  },

  methods: {
    initDatetimePicker() {
      this.dpValue = [
        new Date(new Date().getTime() - 3600 * 1000 * 24 * 2),
        new Date(),
      ];
    },

    getImgFile(deviceType) {
      var temp = deviceList.deviceList;
      var fileName = "";
      for (let index = 0; index < temp.length; index++) {
        if (temp[index].deviceType === deviceType) {
          var filetemp = temp[index].img_path.split("/");
          fileName = filetemp[filetemp.length - 1];
        }
      }
      return fileName;
    },

    initPieChart() {
      getDataInsightFailure().then((resp) => {
        var failures = resp.body.deviceFailures;
        console.log(failures);
        var legends = [];
        var top5Data = [];
        var top1Title = failures[0].component;
        var top1Data = [];

        top1Title = failures[0].component;
        for (let index = 0; index < failures.length; index++) {
          legends.push(failures[index].component);
          top5Data.push({
            value: failures[index].times,
            name: failures[index].component,
          });
        }

        var top1failures = failures[0].failures;
        for (let index = 0; index < top1failures.length; index++) {
          const element = top1failures[index];
          top1Data.push({
            value: element.times,
            name: element.failure,
          });
        }

        this.chart = Echarts.init(this.$refs.pieChart);

        let option = {
          color: [
            "#5470c6",
            "#fac858",
            "#ee6666",
            "#73c0de",
            "#fc8452",
            "#9a60b4",
            "#3ba272",
            "#91cc75",
            "#ea7ccc",
          ],
          title: [
            {
              text: "故障部件Top5",
              left: "20%",
              top: "10%",
              textAlign: "center",
            },
            {
              text: top1Title + "故障类型",
              left: "80%",
              top: "10%",
              textAlign: "center",
            },
          ],
          tooltip: {
            trigger: "item",
            formatter: "{a} <br/>{b} : {c} ({d}%)",
          },
          legend: {
            left: "left",
            top: "top",
            data: legends,
          },
          series: [
            {
              name: "报警次数",
              type: "pie",
              radius: [20, 140],
              center: ["25%", "50%"],
              roseType: "radius",
              itemStyle: {
                borderRadius: 5,
              },
              emphasis: {
                label: {
                  show: true,
                  formatter: "{d}%",
                },
              },
              data: top5Data,
            },
            {
              name: "故障详情",
              type: "pie",
              radius: [20, 140],
              center: ["75%", "50%"],
              roseType: "radius",
              itemStyle: {
                borderRadius: 5,
              },
              label: {
                show: true,
              },
              emphasis: {
                label: {
                  show: true,
                  formatter: "{d}%",
                },
              },
              data: top1Data,
            },
          ],
        };
        this.chart.setOption(option);
      });
    },
    /// need modification
    /// according to different deviceType, initiate different chart
    /// with temperature data or not
    initTSChart() {
      getAlarmTS(this.alarmID, this.dpValue[0], this.dpValue[1]).then(
        (resp) => {
          var timeSeries = resp.body.TimeSeries;
          console.log(timeSeries);

          var temperatureData = timeSeries[0].data.map((item) => {
            return item.Temperature;
          });
          var vibData = timeSeries[1].data.map((item) => {
            return item.Vibration;
          });
          var xAxisData = timeSeries[0].data.map((item) => {
            return item._time;
          });

          this.chart = Echarts.init(this.$refs.tsChart);
          let option = {
            tooltip: {
              trigger: "axis",
              axisPointer: {
                type: "cross",
                animation: false,
                label: {
                  backgroundColor: "#505765",
                },
              },
            },
            legend: {
              data: ["温度", "振动值"],
              left: "center",
            },
            dataZoom: [
              {
                show: true,
                realtime: true,
                start: 0,
                end: 100,
                bottom:340,
                xAxisIndex:0
              },
              {
                show: true,
                realtime: true,
                start: 0,
                end: 100,
                xAxisIndex:1
              },
            ],
            grid: [
              {
                left: 50,
                right: 50,
                height: "35%",
              },
              {
                left: 50,
                right: 50,
                top: "58%",
                height: "35%",
              },
            ],

            xAxis: [
              {
                type: "category",
                boundaryGap: false,
                axisLine: { onZero: false },
                data: xAxisData,
              },
              {
                type: "category",
                boundaryGap: false,
                axisLine: { onZero: false },
                data: xAxisData,
                gridIndex: 1,
              },
            ],
            yAxis: [
              {
                name: "温度(\u2103)",
                type: "value",
                max: 45,
              },
              {
                name: "振动值(g)",
                max: 1,
                type: "value",
                gridIndex: 1,
              },
            ],
            series: [
              {
                name: "温度",
                type: "line",
                areaStyle: {
                  opacity: 0.2,
                },
                lineStyle: {
                  width: 2,
                },
                emphasis: {
                  focus: "series",
                  blurScope: "coordinateSystem",
                },
                markLine: {
                  label: {
                    formatter: "Temperature:35",
                    position: "insideStartTop",
                    fontWeight: "bold",
                    fontStyle: "italic",
                  },
                  lineStyle: {
                    width: 2,
                  },
                  data: [
                    {
                      name: "Temperature",
                      yAxis: 35,
                    },
                  ],
                },
                data: temperatureData,
              },
              {
                name: "振动值",
                type: "line",
                yAxisIndex: 1,
                areaStyle: {
                  opacity: 0.3,
                },
                lineStyle: {
                  width: 2,
                  type: "solid",
                },
                markLine: {
                  label: {
                    formatter: "Vibration:0.103",
                    position: "insideStartTop",
                    fontWeight: "bold",
                    fontStyle: "italic",
                  },
                  lineStyle: {
                    width: 2,
                  },
                  data: [
                    {
                      name: "Vibration",
                      yAxis: 0.103,
                    },
                  ],
                },
                emphasis: {
                  focus: "series",
                  blurScope: "coordinateSystem",
                },
                xAxisIndex: 1,
                yAxisIndex: 1,
                data: vibData,
              },
            ],
          };
          this.chart.setOption(option);
        }
      );
    },
  },
};
</script>

<style lang="scss" scoped>
</style>