<template>
  <div class="overviewareastat">
    <el-dialog
      :title="'区域统计详情 -- ' + area.areaName + ' ' + showDatetime()"
      :visible.sync="dialogVisible"
      @close="$emit('update:dialogVisible', false)"
      width="80%"
    >
      <el-row style="margin-top: -2%">
        <el-col :span="12">
          <el-row style="text-align: center">
            <el-col :span="6">
              <div class="infoAlertText font">
                {{ "设备数量： " + area.totalNum }}
              </div>
            </el-col>

            <el-col :span="6">
              <div class="highAlertText font">
                {{ "高级报警： " + area.highAlertNum }}
              </div></el-col
            >
            <el-col :span="6"
              ><div class="mediumAlertText font">
                {{ "中级报警： " + area.mediumAlertNum }}
              </div></el-col
            >
          </el-row>

          <div
            style="width: 100%; margin-top: 27px; height: 500px"
            ref="top5chart"
          ></div>
        </el-col>
        <el-col :span="12">
          <el-row>
            <el-col :span="12"
              ><div class="infoAlertText font">维修总览</div>
            </el-col>
            <el-col :span="12">
              <el-radio-group
                v-model="timeWindow"
                style="float: right"
                size="mini"
                @change="reloadTimwWindowChart"
              >
                <el-radio-button label="周"></el-radio-button>
                <el-radio-button label="月"></el-radio-button>
              </el-radio-group>
            </el-col>
          </el-row>
          <div style="width: 100%; height: 500px" ref="weekChart"></div>
        </el-col>
      </el-row>
    </el-dialog>
  </div>
</template>

<script>
import { getFailureTop } from "@/api/failure";
import { getStatArea } from "@/api/statistic";
import Globals from "@/components/Globals";
// YSP, 2021-07-02
// 我就不用v-charts, 我就要用原生echarts
let Echarts = require("echarts/lib/echarts");
require("echarts/lib/chart/bar");
require("echarts/lib/component/title");
require("echarts/lib/component/legend");
export default {
  data() {
    return {
      timeWindow: Globals.timeWindow,
    };
  },
  props: {
    dialogShow: {
      type: Boolean,
      default: false,
    },
    area: null,
  },
  mounted() {
      this.fetchData();
  },
  computed: {
    dialogVisible: {
      get() {
        return this.dialogShow;
      },
      set(val) {
        this.$emit("update:dialogShow", val);
      },
    },
  },

  methods: {
    showDatetime() {
      return new Date().toLocaleString("en-GB", { hour12: false });
    },
    reloadTimwWindowChart() {
      Globals.timeWindow = this.timeWindow;
      this.fetchData();
    },
    fetchData() {      
      let tw = Globals.timeWindow === "周" ? "week" : "month";
      getFailureTop(this.area.areaName).then((resp) => {
        var failureRecords = resp.body.maintenanceRecord;
        this.initTop5Chart(failureRecords);
      });
      getStatArea(this.area.areaName, tw).then((resp) => {
        var maintenanceRecords =
          resp.body.data.areaMaintenance.maintenanceRecord;
        this.initTWChart(maintenanceRecords, this.timeWindow);
      });
    },

    initTWChart(maintenanceRecord, timeWindowIndex) {
      this.chart = Echarts.init(this.$refs.weekChart);
      let option = {
        title: {
          text: this.timeWindow,
          textStyle: {
            fontStyle: 16,
          },
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            // Use axis to trigger tooltip
            type: "shadow", // 'shadow' as default; can also be 'line' or 'shadow'
          },
        },
        legend: {
          data: [
            "高级报警",
            "已处理的高级报警",
            "中级报警",
            "已处理的中级报警",
          ],
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true,
        },
        dataset: {
          dimensions: [
            timeWindowIndex === "周" ? "week" : "month",
            "alarm",
            "solvedAlarm",
            "warning",
            "solvedWarning",
          ],
          source: maintenanceRecord.reverse(),
        },
        yAxis: {
          type: "value",
        },
        xAxis: {
          type: "category",
          //data: xAxisData.reverse(),
        },
        series: [
          {
            name: "高级报警",
            type: "bar",
            stack: "total",
            label: {
              show: true,
            },
            emphasis: {
              focus: "series",
            },
            itemStyle: {
              color: "#dd4b39",
            },
            barWidth: 50,

            //data: alarmArray.reverse(),
          },
          {
            name: "已处理的高级报警",
            type: "bar",
            stack: "total",
            label: {
              show: true,
            },
            emphasis: {
              focus: "series",
            },
            itemStyle: {
              color: "#00b359",
            },
            //data: solvedAlarmArray.reverse(),
          },
          {
            name: "中级报警",
            type: "bar",
            stack: "total",
            label: {
              show: true,
            },
            emphasis: {
              focus: "series",
            },
            itemStyle: {
              color: "#f8a333",
            },
            // data: warningArray.reverse(),
          },
          {
            name: "已处理的中级报警",
            type: "bar",
            stack: "total",
            label: {
              show: true,
            },
            emphasis: {
              focus: "series",
            },
            itemStyle: {
              color: "#1a8cff",
            },
            //data: solvedWarningArray.reverse(),
          },
        ],
      };
      this.chart.setOption(option);
    },

    initTop5Chart(failureRecords) {
      this.chart = Echarts.init(this.$refs.top5chart);
      let option = {
        title: {
          text: "报警Top5",
          subtext: "90天内",
          textStyle: {
            fontSize: 14,
          },
          left: "center",
        },
        tooltip: {
          show: true,
          trigger: "axis",
          axisPointer: {
            type: "shadow",
          },
        },
        /// YSP. 2021--8-02
        /// directly using object type
        /// https://echarts.apache.org/examples/zh/editor.html?c=dataset-simple1
        dataset: {
          dimensions: ["top", "times"],
          /// YSP, 2021-07-19
          /// trap here, need to reverse the order
          source: failureRecords.reverse(),
        },
        yAxis: {
          type: "category",
          name: "部件",
          /// YSP, 2021-07-19
          /// https://blog.csdn.net/r4NqiAn/article/details/47834093
          axisLabel: {
            interval: 0,

            color: "#000",
            formatter: function (params) {
              var newParamsName = "";
              var paramsNameNumber = params.length;
              var provideNumber = 10;
              var rowNumber = Math.ceil(paramsNameNumber / provideNumber);
              if (paramsNameNumber > provideNumber) {
                for (var p = 0; p < rowNumber; p++) {
                  var tempStr = "";
                  var start = p * provideNumber;
                  var end = start + provideNumber;
                  if (p == rowNumber - 1) {
                    tempStr = params.substring(start, paramsNameNumber);
                  } else {
                    tempStr = params.substring(start, end) + "\n";
                  }
                  newParamsName += tempStr;
                }
              } else {
                newParamsName = params;
              }
              return newParamsName;
            },
          },
        },
        xAxis: {
          type: "value",
        },
        series: [
          {
            type: "bar",
            label: {
              show: true,
              position: "insideRight",
            },
            itemStyle: {
              color: "#dd4b39",
            },
            barWidth: 50,
          },
        ],
      };
      this.chart.setOption(option);
    },
  },
};
</script>

<style lang="scss" scoped>
.font {
  font-size: 15px;
}
</style>