<template>
  <div class="deviceManagementComponentTable">
    <el-dialog
      title="组件清单"
      :visible.sync="shownTriggered"
      @close="closeCallback"
      @open="openCallback"
    >
      <el-scrollbar style="height: 600px">
        <el-table :data="tableData">
          <el-table-column prop="component" label="组件" width="180">
          </el-table-column>
          <el-table-column prop="number" label="库存量" width="80">
          </el-table-column>
          <el-table-column prop="spare_num" label="存货号" width="180">
          </el-table-column>
          <el-table-column prop="timestamp" label="更新时间" width="180">
          </el-table-column>
          <el-table-column prop="vendor" label="供应商" width="180">
          </el-table-column>
        </el-table>
      </el-scrollbar>
    </el-dialog>
  </div>
</template>

<script>
export default {
  props: {
    shown: {
      type: Boolean,
      default: false,
    },
    tableData: {
      type: Array,
    },
  },
  data() {
    return {};
  },
  methods: {
    closeCallback() {
      this.$emit("update:shown", false);
    },
    openCallback() {},
  },
  computed: {
    shownTriggered: {
      get() {
        return this.shown;
      },
      set(val) {
        this.$emit("update:shown", val);
      },
    },
  },
};
</script>

<style>
</style>