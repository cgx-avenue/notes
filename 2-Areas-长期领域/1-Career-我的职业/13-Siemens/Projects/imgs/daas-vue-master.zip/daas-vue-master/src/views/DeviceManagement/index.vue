<template>
  <div class="management">
    <device-selector
      @onSubmit="onSubmit"
      :showDevice="true"
      :showTimePicker="false"
    ></device-selector>

    <el-divider></el-divider>
    <div style="margin-top: 20px">
      <el-button
        icon="el-icon-circle-plus-outline"
        type="primary"
        plain
        style="margin-left: 40px"
        @click="showAddComponentDialog"
        >添加设备</el-button
      >
      <el-button
        icon="el-icon-document"
        type="primary"
        plain
        style="margin-left: 20px"
        @click="componentImportVisible = true"
        >组件导入</el-button
      >
      <el-button
        icon="el-icon-office-building"
        type="primary"
        plain
        style="margin-left: 20px"
        @click="deviceImportVisible = true"
        >设备导入</el-button
      >
      <el-button
        icon="el-icon-download"
        type="primary"
        plain
        style="margin-left: 20px"
        @click="exportExcel"
        >导出文档</el-button
      >
    </div>
    <el-table
      ref="filterTable"
      :data="
        tableData.slice((currentPage - 1) * pageSize, currentPage * pageSize)
      "
      tooltip-effect="dark"
      style="width: 80%; margin-left: 3%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55"> </el-table-column>
      <el-table-column prop="deviceID" label="ID" v-if="false">
      </el-table-column>
      <el-table-column prop="deviceNum" width="250" label="设备">
      </el-table-column>
      <el-table-column prop="area" label="区域" width="120"> </el-table-column>
      <el-table-column prop="line" label="产线" width="120"> </el-table-column>
      <el-table-column prop="deviceType" label="类型" width="200">
      </el-table-column>
      <el-table-column prop="component" label="组件" width="100">
        <template slot-scope="scope">
          <el-button
            icon="el-icon-setting"
            @click="showComponents(scope.row)"
            plain
            type="warning"
            size="small"
          >
          </el-button>
        </template>
      </el-table-column>
      <el-table-column prop="updateTime" label="更新时间" width="200" sortable>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            icon="el-icon-edit"
            @click="showEditComponentDialog(scope.row)"
            plain
            type="primary"
            size="small"
          >
          </el-button>
          <el-button
            icon="el-icon-delete"
            @click="deleteComponent(scope.row)"
            plain
            type="danger"
            size="small"
          >
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      style="text-align: center"
      background
      layout="prev, pager, next"
      :total="total"
      :current-page="currentPage"
      @current-change="current_change"
    >
    </el-pagination>

    <device-management-component-table
      :shown.sync="componentDialogVisible"
      :tableData="componentTable"
    ></device-management-component-table>

    <device-management-device-dialog
      :title="deviceDialogTitle"
      :shown.sync="deviceDialogVisible"
      :form.sync="deviceDialogForm"
      @onSubmit="onSubmit"
    ></device-management-device-dialog>
    <device-management-component-import
      :shown.sync="componentImportVisible"
    ></device-management-component-import>
    <device-management-device-import
      :shown.sync="deviceImportVisible"
    ></device-management-device-import>
  </div>
</template>

<script>
import { queryDevice, deleteComponent } from "@/api/device";
import { queryComponent } from "@/api/component";
import DeviceSelector from "@/components/DeviceSelector/index";
import DeviceManagementDeviceDialog from "./components/DeviceManagementDeviceDialog";
import DeviceManagementComponentImport from "./components/DeviceManagementComponentImport";
import DeviceManagementDeviceImport from "./components/DeviceManagementDeviceImport";
import DeviceManagementComponentTable from "./components/DeviceManagementComponentTable.vue";

export default {
  components: {
    DeviceSelector,
    DeviceManagementDeviceDialog,
    DeviceManagementComponentImport,
    DeviceManagementDeviceImport,
    DeviceManagementComponentTable,
  },
  data() {
    return {
      tableData: [],
      currentPage: 1,
      total: 0, 
      pageSize: 10,
      componentTable: [],
      componentDialogVisible: false,

      deviceDialogVisible: false,
      componentImportVisible: false,
      deviceImportVisible: false,

      deviceDialogForm: {
        deviceNum: "",
        area: "",
        line: "",
        deviceType: "",
        deviceID: 0,
      },
      deviceDialogTitle: "",
    };
  },

  methods: {
    onSubmit: function (form) {
      console.log("submit!" + form.area);
      this.tableData = [];

      queryDevice(
        form.area === "" ? "*" : form.area,
        form.line === "" ? "*" : form.area,
        form.device === "" ? "*" : form.device
      ).then((resp) => {
        var items = resp.body.deviceInfo;
        console.log(items);
        for (let index = 0; index < items.length; index++) {
          const temp = items[index];
          this.tableData.push({
            area: temp.area,
            line: temp.line,
            deviceNum: temp.deviceNum,
            deviceType: temp.deviceType,
            updateTime: temp.updateTime,
            deviceID: temp.deviceID,
          });
        }
        this.currentPage = 1;
        this.current_change(this.currentPage);
        this.total = this.tableData.length;
      });
    },

    showComponents(row) {
      this.componentDialogVisible = true;
      queryComponent(row.deviceType).then((resp) => {
        this.componentTable = resp.body;
      });
    },

    showEditComponentDialog(row) {
      console.log(row);
      this.deviceDialogVisible = true;
      this.deviceDialogTitle = "编辑设备";
      this.deviceDialogForm = row;
    },
    showAddComponentDialog() {
      this.deviceDialogVisible = true;
      this.deviceDialogTitle = "添加设备";
    },
    deleteComponent(row) {
      this.tableData = [];
      deleteComponent(row.deviceNum).then((resp) => {
        var items = resp.data.items;
        console.log(items);
        for (let index = 0; index < items.length; index++) {
          const temp = items[index];
          this.tableData.push({
            area: temp.area,
            line: temp.line,
            deviceNum: temp.deviceNum,
            deviceType: temp.deviceType,
            updateTime: temp.updateTime,
            deviceID: temp.deviceID,
          });
        }
      });
    },
    ///bug inside
    exportExcel() {
      console.log(111);
      import("@/utils/Export2Excel").then((excel) => {
        const tHeader = [
          "area",
          "line",
          "deviceNum",
          "deviceType",
          "updateTime",
          "deviceID",
        ];
        const data = this.tableData;
        console.log(data);

        excel.export_json_to_excel({
          header: tHeader,
          data,
          filename: "table-list",
        });
      });
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    // pagination
    current_change(currentPage) {
      this.currentPage = currentPage;
    },
  },
};
</script>

<style  >
</style>
