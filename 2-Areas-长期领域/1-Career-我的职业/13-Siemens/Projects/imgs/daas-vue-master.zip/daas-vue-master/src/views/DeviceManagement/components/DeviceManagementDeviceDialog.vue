<template >
  <div class="deviceManagementDeviceDialog">
    <el-dialog
      :title="title"
      :visible.sync="shownTriggered"
      width="25%"
      @close="closeCallback"
      @open="openCallback"
    >
      <el-form :model="formdata">
        <el-form-item label="设备:" label-width="20%">
          <el-input
            style="width: 80%"
            v-model="formdata.deviceNum"
            placeholder="请输入设备"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item label="区域:" label-width="20%" prop="area">
          <el-select
            v-model="formdata.area"
            placeholder="请选择区域"
            clearable
            style="width: 80%"
          >
            <el-option
              v-for="area in areaStatList"
              :key="area.areaName"
              :label="area.areaName"
              :value="area.areaName"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="产线:" label-width="20%" prop="line">
          <el-select
            v-model="formdata.area"
            placeholder="请选择产线"
            clearable
            style="width: 80%"
          >
            <el-option
              v-for="area in areaStatList"
              :key="area.areaName"
              :label="area.areaName"
              :value="area.areaName"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="类型:" label-width="20%" prop="deviceType">
          <el-select
            style="width: 80%"
            v-model="formdata.deviceType"
            placeholder="请选择类型"
            clearable
          >
            <el-option
              v-for="device in deviceTypesList"
              :key="device"
              :label="device"
              :value="device"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="closeCallback">取 消</el-button>
        <el-button type="primary" @click="submit">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { getDeviceTypes,updateDevice, addDevice } from "@/api/device";
import { getStat } from "@/api/statistic";

export default {
  props: {
    shown: {
      type: Boolean,
      default: false,
    },
    form: {
      type: Object,
      default: () => {
        return {
          deviceNum: "",
          area: "",
          //line: "",
          deviceType: "",
          deviceID:0,
        };
      },
    },
    title: {
      type: String,
      default: null,
    },
  },
  data() {
    return {
      areaStatList: null,
      deviceTypesList: null,
      isEdit: false,
      formdata: JSON.parse(JSON.stringify(this.form)),
    };
  },
  computed: {
    shownTriggered: {
      get() {
        return this.shown;
      },
      set(val) {
        this.$emit("update:shown", val);
      },
    },
  },
  mounted() {
    this.fetchData();
  },

  methods: {
    fetchData() {
      getStat().then((resp) => {
        this.areaStatList = resp.body.statistic;
      });
      getDeviceTypes().then((resp) => {
        this.deviceTypesList = resp.body.typeList;
      });
    },
    submit() {
      if (
        this.formdata.area.trim() === "" ||
        //this.formdata.line.trim() === "" ||
        this.formdata.deviceNum.trim() === "" ||
        this.formdata.deviceType.trim() === ""
      ) {
        alert("所有项均不能为空！");
        return;
      }
      if (this.title.indexOf("编辑") != -1) {
        console.log("edition");
        updateDevice(this.formdata.deviceID,this.form);
       
      } else {
        console.log("addtion");
         addDevice(
          this.formdata.area.trim(),
          this.formdata.deviceType.trim(),
          this.formdata.deviceNum.trim()
        );
      }
      /// refresh parent datatable
      var allForm={
        area:"",
        line:"",
        device:"",
        dpvalue:""
      }
      this.$emit("onSubmit",allForm);
      this.closeCallback();
    },
    closeCallback() {
      this.$emit("update:shown", false);
    },
    openCallback() {
      /// YSP, 2021-07-21
      /// deep clone each time to store the status of form
      this.formdata = JSON.parse(JSON.stringify(this.form));
      if (this.title.indexOf("添加") != -1) {
        this.formdata.area = "";
        //this.formdata.line = "";
        this.formdata.deviceNum = "";
        this.formdata.deviceType = "";
      }
    },
  },
};
</script>
<style scoped lang="scss">
</style>

