import request from '@/utils/request'

export function getStat() {
  return request({
    url: '/statistic',
    method: 'get',
    
  })
}

export function getStatArea(areaName,timeWindow){
  return request({
    url:`/statistic/area/${areaName}/timeWindow/${timeWindow}`,
    method:'get',
  })
}

