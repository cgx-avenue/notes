import request from '@/utils/request'

export function getDeviceAlarm(areaName,lineName,priority,from,to){
    return request ({
        url:`/alarm/deviceAlarm/area/${areaName}/line/${lineName}/priority/${priority}`,
        method:'get',
        params:{
            from:from,
            to:to,
        }
    })

}
// YSP, 2021-07-09
// later need to change back to /historyAlarm api
export function getDeviceHistoryAlarm(areaName,lineName,device,from,to){
    return request ({
        url:`/historyAlarm/area/${areaName}/line/${lineName}/deviceNum/${device}`,
        method:'get',
        params:{
            from:from,
            to:to,
        }
    })

}

export function getAlarmIndicate(alarmID){
    return request({
        url:`/alarm/indicate/alarmID/${alarmID}`,
        method:'get',
    })
}


export function getAlarmSuggestion(alarmID){
    return request({
        url:`/alarm/suggestion/alarmID/${alarmID}`,
        method:'get',
    })
}


