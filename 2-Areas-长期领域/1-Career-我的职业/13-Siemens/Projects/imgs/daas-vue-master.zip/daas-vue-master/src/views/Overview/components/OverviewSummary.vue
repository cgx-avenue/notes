<template>
  <div class="overview">
    <el-row :gutter="30" class="panel-group">
      <el-col :span="5">
        <div>
          <h1>{{ stat.facTitle }}</h1>
          <p style="width: 80%; margin-left: 20px">{{ stat.facIntro }}</p>
        </div>
      </el-col>

      <el-col :span="2" class="card-panel-col">
        <div id="preloader-5">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </el-col>

      <el-col :span="4" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper">
            <svg-icon icon-class="area" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text infoAlertText">区域数量</div>
            <count-to
              :start-val="0"
              :end-val="stat.areaCnt"
              :duration="2000"
              class="card-panel-num infoAlertText"
            />
          </div>
        </div>
      </el-col>

      <el-col :span="4" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper">
            <svg-icon icon-class="device" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text infoAlertText">设备数量</div>
            <count-to
              :start-val="0"
              :end-val="stat.deviceCnt"
              :duration="2000"
              class="card-panel-num infoAlertText"
            />
          </div>
        </div>
      </el-col>

      <el-col :span="4" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper">
            <svg-icon icon-class="highAlarm" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text highAlertText">高级报警</div>
            <count-to
              :start-val="0"
              :end-val="stat.highAlertNum"
              :duration="2000"
              class="card-panel-num highAlertText"
            />
          </div>
        </div>
      </el-col>

      <el-col :span="4" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper">
            <svg-icon icon-class="mediumAlarm" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text mediumAlertText">中级报警</div>
            <count-to
              :start-val="0"
              :end-val="stat.mediumAlertNum"
              :duration="2000"
              class="card-panel-num mediumAlertText"
            />
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import CountTo from "vue-count-to";
export default {
  data() {
    return {
      statusClass: "",
    };
  },
  components: {
    CountTo,
  },
  // mounted() {
  //   this.colorizeStatusSpan();
  // },
  updated(){
    this.colorizeStatusSpan();

  },
  methods: {
    colorizeStatusSpan() {
      console.log(this.stat);
      var c = document
        .getElementById("preloader-5")
        .getElementsByTagName("span");
      var cArray = Array.from(c);
      for (let index = 0; index < cArray.length; index++) {
        const element = cArray[index];
        if (this.stat.status === 'high') {
          element.style.setProperty("border", "5px solid #f9553f");
        } else if (this.stat.status === 'medium') {
          element.style.setProperty("border", "5px solid #f8a333");
        } else {
          element.style.setProperty("border", "5px solid #00a65a");
        }
      }
    },
  },
  name: "OverviewSummary",
  props: {
    stat: Object,
  },
};
</script>

<style lang="scss" scoped>
@import "../../../styles/variables.scss";

.highAlert {
  border: 5px solid $alertHighClr;
}

.mediumAlert {
  border: 5px solid $alertMediumClr;
}

.healthyAlert {
  border: 5px solid $alertHealthyClr;
}

#preloader-5 {
  position: absolute;
  top: 30%;
}
#preloader-5 span {
  position: absolute;
  width: 50px;
  height: 50px;
  //border: 5px solid #f9553f;
  border-radius: 999px;
  opacity: 0;
  animation: radar 2s infinite linear;
}
#preloader-5 span:nth-child(1) {
  animation-delay: 0s;
}
#preloader-5 span:nth-child(2) {
  animation-delay: 0.66s;
}
#preloader-5 span:nth-child(3) {
  animation-delay: 1.33s;
}

@keyframes radar {
  0% {
    transform: scale(0);
    opacity: 0;
  }
  25% {
    transform: scale(0);
    opacity: 0.5;
  }
  50% {
    transform: scale(1);
    opacity: 1;
  }
  75% {
    transform: scale(1.5);
    opacity: 0.5;
  }
  100% {
    transform: scale(2);
    opacity: 0;
  }
}

.overview {
  max-height: 270px;
  margin-left: 20px;
  position: relative;
}

.el-scrollbar__wrap {
  overflow-x: hidden;
}

.panel-group {
  margin-top: 18px;
  background: #e9eef3;
  .card-panel-col {
    //vertical-align: middle;
    margin-top: 0.5%;
    //margin-bottom: 12px;
  }

  .card-panel {
    height: 108px;
    cursor: pointer;
    font-size: 12px;
    position: relative;

    overflow: hidden;
    color: rgb(119, 118, 118);
    background: #fff;
    box-shadow: 4px 4px 40px rgba(0, 0, 0, 0.05);
    border-color: rgba(0, 0, 0, 0.05);
    transition: 0.1s;

    &:hover {
      transform: scale(1.05);
    }

    .card-panel-icon-wrapper {
      float: left;
      margin: 14px 0 0 14px;
      padding: 16px;
      transition: all 0.38s ease-out;
      border-radius: 6px;
    }

    .card-panel-icon {
      float: left;
      font-size: 48px;
    }

    .card-panel-description {
      float: right;
      font-weight: bold;
      margin: 26px;
      margin-left: 0px;

      .card-panel-text {
        line-height: 18px;
        // color: rgba(0, 0, 0, 0.45);
        font-size: 16px;
        margin-bottom: 12px;
      }

      .card-panel-num {
        font-size: 20px;
      }
    }
  }
}

@media (max-width: 550px) {
  .card-panel-description {
    display: none;
  }

  .card-panel-icon-wrapper {
    float: none !important;
    width: 100%;
    height: 100%;
    margin: 0 !important;

    .svg-icon {
      display: block;
      margin: 14px auto !important;
      float: none !important;
    }
  }
}
</style>
