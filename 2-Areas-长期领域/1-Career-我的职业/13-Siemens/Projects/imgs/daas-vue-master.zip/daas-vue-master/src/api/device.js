import request from '@/utils/request'

export function getDeviceInfo() {

    return request({
        url: '/device',
        method: 'get'
    })
}

export function getDeviceTypes(){
    return request({
        url:'/device/type',
        method:'get'
    })
}

export function queryDevice(area,line,device){
    return request({
        url:`/deviceManagement/querydevice/area/${area}/productionline/${line}/device/${device}`,
        method:'get',
    })
}

export function addDevice(line,type,device){
    return request({
        url:`/deviceManagement/addDevice/line/${line}/type/${type}/device/${device}`,
        method:'post'
    })
}

/// what the fuck?!
export function updateDevice(deviceID,form){
    return request({
        url:`/deviceManagement/updateDevice/${deviceID}`,
        method:'post',
        data:{
            'deviceNum':form.deviceNum,
            'deviceType':form.deviceType,
            'line':form.area,
            'timestamp':form.updateTime,
        },
        header:{
            'Content-Type':'application/json'  //如果写成contentType会报错
        },    
    })
}

export function deleteDevice(deviceID){
    return request({
        url:`/deviceManagement/deleteDevice/${deviceID}`,
        method:'POST',

    })
}

/// need modification
export function batchImport(){
    return request({
        url:'/deviceManagement/batchImport',
        method:'post'
    })
}

