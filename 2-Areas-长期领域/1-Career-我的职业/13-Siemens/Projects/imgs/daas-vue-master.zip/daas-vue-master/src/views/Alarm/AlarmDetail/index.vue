<template>
  <div class="alarm-detail">
    <el-form ref="form" :model="alarmIndicateInfo" label-width="80px">
      <el-form-item label="设备信息"> </el-form-item>
      <el-row>
        <el-col :span="6">
          <el-form-item label="区域">
            <el-input
              v-model="alarmIndicateInfo.areaName"
              :readonly="true"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="产线">
            <el-input
              v-model="alarmIndicateInfo.areaName"
              :readonly="true"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="设备">
            <el-input
              v-model="alarmIndicateInfo.deviceNum"
              :readonly="true"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <router-link target="_self" :to="'/alarmdatainsight/' + alarmID">
            <el-button type="primary" style="margin-left: 15%"
              >数据详情</el-button
            >
          </router-link>
          <el-button type="primary" style="margin-left: 5%">下载报告</el-button>
        </el-col>
      </el-row>
      <el-divider></el-divider>
    </el-form>
    <el-row style="margin-top: 1%" :gutter="30">
      <el-col :span="16">
        <el-row style="font-size: 110%; text-align: center">
          <el-col :span="6"
            ><div class="infoAlertText">
              {{ "设备类型： " + alarmIndicateInfo.deviceType }}
            </div></el-col
          >
          <el-col :span="6"
            ><div :class="alarmClass">
              {{ "维护级别： " + alarmIndicateInfo.priority.toUpperCase() }}
            </div></el-col
          >
          <el-col :span="6"
            ><div :class="alarmClass">
              {{ "报警时间： " + alarmIndicateInfo.alertTime }}
            </div></el-col
          >
          <el-col :span="6"
            ><div :class="alarmClass">
              {{ "报警类型： " + alarmIndicateInfo.alarmType }}
            </div></el-col
          >
        </el-row>
        <el-row>
          <el-image
            :src="
              require('@/assets/img/' +
                getImgFile(alarmIndicateInfo.deviceType))
            "
            style="margin-top: 2%;height:600px"
            fit="scale-down"
          ></el-image>
        </el-row>
      </el-col>

      <el-col :span="8">
        <div style="font-size: 110%">
          <i class="el-icon-finished" style="margin-right: 10px"></i>维护建议
        </div>
        <el-table :data="tableData" max-height="600">
          <el-table-column prop="sug" label="顺序/建议/详细"></el-table-column>
        </el-table>
        <el-button
          type="primary"
          style="width: 100%"
          round
          size="small"
          @click="feedbackVisible = true"
          >反馈</el-button
        >
      </el-col>
    </el-row>
    <alarm-detail-feedback :shown.sync="feedbackVisible" :tableData="tableData"></alarm-detail-feedback>
  </div>
</template>
<script>
import { getAlarmIndicate, getAlarmSuggestion } from "@/api/alarm";
import AlarmDetailFeedback from "./components/AlarmDetailFeedback";
import deviceList from "@/assets/img/devicelocal.json";

export default {
  data() {
    return {
      alarmID: this.$route.params.alarmID,
      feedbackVisible: false,
      alarmIndicateInfo: {
        areaName: "",
      },
      tableData: [],
      alarmClass: "",
    };
  },
  components: { AlarmDetailFeedback },
  mounted() {
    getAlarmIndicate(this.alarmID).then((resp) => {
      this.alarmIndicateInfo = resp.body.alarmIndicate[0];
      console.log(this.alarmIndicateInfo);
      console.log(this.alarmIndicateInfo.deviceType);
      if (this.alarmIndicateInfo["priority"] === "high") {
        this.alarmClass = "highAlertText";
      } else if (this.alarmIndicateInfo.priority === "medium") {
        this.alarmClass = "mediumAlertText";
      } else {
        this.alarmClass = "healthyAlertText";
      }
    });
    getAlarmSuggestion(this.alarmID).then((resp) => {
      var items = resp.body.suggestions;
      console.log(items);
      for (let index = 0; index < items.length; index++) {
        var temp = items[index];
        this.tableData.push({
          sug: temp.queue + ". 检查" + temp.component + "-->" + temp.suggestion,
        });
      }
    });
  },
  methods: {
    onSubmit() {},
    /// YSP, 2021-07-28
    /// https://blog.csdn.net/qq_29869111/article/details/100154941
    getImgFile(deviceType) {
      var temp = deviceList.deviceList;
      var fileName = "";
      //console.log(temp);
      for (let index = 0; index < temp.length; index++) {
        if (temp[index].deviceType === deviceType) {
          var filetemp = temp[index].img_path.split("/");
          fileName = filetemp[filetemp.length - 1];
          //console.log(fileName);
        }
      }
      return fileName;
    },
  },
};
</script>

<style scoped >
</style>
