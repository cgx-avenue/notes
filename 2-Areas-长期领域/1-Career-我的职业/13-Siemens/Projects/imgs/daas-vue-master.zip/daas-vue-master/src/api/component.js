import request from '@/utils/request'

export function queryComponent(deviceType){
    return request({
        ///need modification
        url:`/deviceManagement/queryComponent/${deviceType}`,
        method:'get'
    })
}



