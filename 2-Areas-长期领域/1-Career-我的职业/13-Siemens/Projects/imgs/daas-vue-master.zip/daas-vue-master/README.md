# DaaS-vue

* Arthor: Yang, Shaopeng
* Date: 2021-06-28
# background
This repo is to refactor front-end using Vue.js 2.x framework for DaaS related project.

With Vue.js 2.x, also choosed:
* element-ui
* vue-admin-template

Please check OSS license cause both element-ui and vue-admin-template are under MIT license.

# install dependency
npm install

# develop
npm run dev
```

This will automatically open http://localhost:9528

## Build

```bash
# build for test environment
npm run build:stage

# build for production environment
npm run build:prod
```

## Advanced

```bash
# preview the release environment effect
npm run preview

# preview the release environment effect + static resource analysis
npm run preview -- --report

# code format check
npm run lint

# code format check and auto fix
npm run lint -- --fix
```

Refer to [Documentation](https://panjiachen.github.io/vue-element-admin-site/guide/essentials/deploy.html) for more information

# notes
## adding new vue component
@/components folder is for global componets, like search, datetimepicker. For page related or module related component, please add into @/views folder.
* If it's related to layout, please add it into src/layout, e.g. TopNavbar.vue
* If it's a view in sidebar, please add it into src/views, and follow the structure in that folder, e.g. alarm/index.vue.
* If it's only a component, please add it into src/components folder, e.g. Hamburger. 

