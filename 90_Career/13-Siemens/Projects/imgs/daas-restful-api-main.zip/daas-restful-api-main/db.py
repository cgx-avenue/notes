'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 10:08:47
LastEditors: Yang, Shao Peng
LastEditTime: 2021-11-23 14:26:26
'''
from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()
