from matplotlib import pyplot as plt
from common.file_helper import FileHelper
from common.util import Util
from io import BytesIO
from PIL import Image as Img
from PIL import ImageDraw, ImageFont
import json
import datetime
import matplotlib.dates as mdates
import matplotlib
from reportlab.platypus import Table, SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors, fonts

# 注册字体
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
pdfmetrics.registerFont(TTFont('simsun', "simsun.ttc"))
# 加载字体
fonts.addMapping('simsun', 0, 0, "simsun.ttc")

matplotlib.use('Agg')
# 统计函数的实例对象


class Report():

    def generate_report(self, data, suggestions, TimeSeries, language):

        data_report = FileHelper.get_data("common/report/report.json",
                                          language)
        # print(data_report)
        firstTable, priority_alert_Table, deviceType, devicenum, priority = self.report(
            data, language)
        # 拿到了 绘出的所有表,处理后的各种数据
        # pdf放入缓存
        if priority == "high":
            str_pri = "priority1"
        elif priority == "medium":
            str_pri = "priority2"
        sio = BytesIO()
        reportname = devicenum + \
            data_report[str_pri] + data_report["fileName"] + ".pdf"
        styles = getSampleStyleSheet()
        doc = SimpleDocTemplate(sio)

        # elements pdf的内容数组
        elements = []
        # 画标题，并设置样式，支持中文字体
        title = styles['Title']
        # print(data_report["title"])
        title.fontName = 'simsun'
        elements.append(Paragraph(data_report["title"], title))
        elements.append(Spacer(1, 15))
        # 画表
        for table in firstTable:
            elements.append(table)
            elements.append(Spacer(1, 15))
        # 第一段 Alert Key Component
        heading2 = styles['Heading2']
        heading2.fontName = 'simsun'
        elements.append(Paragraph(data_report["heading2_1"], heading2))
        # 打完点的图
        elements.append(self.Alert_Picture(deviceType, priority_alert_Table))
        elements.append(Spacer(1, 5))
        # 第二段 建议
        elements.append(Paragraph(data_report["heading2_2"], heading2))
        elements.append(Spacer(1, 5))

        if language == "CN":
            field = "cnSuggestion"
        elif language == "EN":
            field = "enSuggestion"
        suggestions_tran = FileHelper.get_data("common/report/suggestion.json",
                                         field)
        bodyText = styles['BodyText']
        bodyText.fontName = 'simsun'
        for suggestion in suggestions:
            sugCode = suggestion["sugCode"]
            ptext = '<font size = 9>%d.%s</font>' % (
                suggestion["queue"], suggestions_tran[sugCode])
            elements.append(Paragraph(ptext, bodyText))
        elements.append(Spacer(1, 12))

        # 第三段 Data Insight 标题
        for alert in priority_alert_Table:
            if alert == None:
                continue
            if alert[1] == 'high' or alert[1] == 'medium':
                elements.append(Paragraph(data_report["heading2_3"], heading2))
                elements.append(Spacer(1, 5))
                break

        # 3.？ 小标题 和 内容
        heading3 = styles['Heading3']
        heading3.fontName = 'simsun'
        highflag = 0
        for alert in priority_alert_Table:
            if alert == None:
                continue
            if alert[1] == 'high':
                if highflag == 0:
                    highflag = 1
                    elements.append(
                        Paragraph(data_report["heading3_1"], heading3))
                    elements.append(Spacer(1, 5))
                if highflag == 1:
                    elements.append(
                        Paragraph(
                            data_report["body"] +
                            str(alert[4]) + " " + str(alert[3]),
                            bodyText))
                    elements.append(alert[0])
                    elements.append(Spacer(1, 1))
                    # 折线图
                    try:
                        elements.append(
                            Image(self.Line_Plot(alert[3], TimeSeries), 500,
                                  300))
                    except Exception:
                        pass
                    finally:
                        elements.append(Spacer(1, 5))
        # 3.2?
        mediumflag = 0
        for alert in priority_alert_Table:
            if alert == None:
                continue
            if alert[1] == 'medium':
                if mediumflag == 0:
                    mediumflag = 1
                    if highflag == 1:
                        elements.append(
                            Paragraph(data_report["heading3_3"], heading3))
                    else:
                        elements.append(
                            Paragraph(data_report["heading3_2"], heading3))
                    elements.append(Spacer(1, 5))
                if mediumflag == 1:
                    elements.append(
                        Paragraph(
                            data_report["body"] +
                            str(alert[4]) + " " + str(alert[3]),
                            bodyText))
                    elements.append(alert[0])
                    elements.append(Spacer(1, 1))
                    # 折线图
                    try:
                        elements.append(
                            Image(self.Line_Plot(alert[3], TimeSeries), 500,
                                  300))
                    except Exception:
                        pass
                    finally:
                        elements.append(Spacer(1, 5))
        # print(elements)
        doc.build(elements)

        return sio, reportname  # ,reportpath#

    # 解析处理数据
    def report(self, data, language):
        firstTable = []
        priority_alert_Table = []
        for alarmIndicate in data:
            deviceNum = alarmIndicate["deviceNum"]
            areaName = alarmIndicate["areaName"]
            lineName = alarmIndicate["lineName"]
            deviceType = alarmIndicate["deviceType"]
            alertTime = alarmIndicate["alertTime"]
            priority = alarmIndicate["priority"]
            status = alarmIndicate["status"]
            components = alarmIndicate["components"]
            firstTable.append(
                self.draw_First_Table(deviceNum, areaName, lineName,
                                      deviceType, alertTime, priority, status, language))
            for component in components:
                pointName = component["pointName"]
                pointPriority = component["pointPriority"]
                number = component["number"]
                spare_num = component["spare_num"]
                timestamp = component["timestamp"]
                vendor = component["vendor"]
                priority_alert_Table.append(
                    self.draw_Component_Table(areaName, lineName, deviceType,
                                              pointName, pointPriority, number,
                                              spare_num, timestamp, vendor, language))

        return firstTable, priority_alert_Table, deviceType, deviceNum, priority

    '''
    firstTable: [Table ]
    priority_alert_Table: [(Table,pointPriority,deviceType,pointName,marker,x,y),...]  + get_Marker_xy_ByName  
    deviceType: str deviceType
    devicenum:devicenum
    priority:priority
    '''

    def draw_First_Table(self, devicenum, areaName, lineName, deviceType,
                         alertTime, priority, status, language):
        a = FileHelper.get_data("common/report/report.json",
                                               language)
        data = [[a["table_1"], devicenum], [a["table_2"], areaName],
                [a["table_3"], lineName], [a["table_4"], deviceType],
                [a["table_5"], priority], [a["table_6"], alertTime],
                [
                    a["table_7"],
                    str(datetime.datetime.utcnow() +
                        datetime.timedelta(hours=8))[:-7]
        ]]

        ts = [('ALIGN', (1, 1), (-1, -1), 'LEFT'),
              ('INNERGRID', (0, 0), (-1, -1), 1, colors.black),
              ('BOX', (0, 0), (-1, -1), 1, colors.black),
              ('TEXTCOLOR', (1, 4), (-1, -2), colors.red),
              ('FONT', (0, 0), (-1, -1), 'simsun')]
        #   ('FONT', (0, 0), (-1, -1), 'Times-Bold')]
        t = Table(data, [80, 150], style=ts, hAlign='LEFT')
        return t

    # 画部件的表，并同时获得pointPriority,deviceType,pointName,marker,x,y坐标
    def draw_Component_Table(self, areaName, lineName, deviceType, pointName,
                             pointPriority, number, spare_num, timestamp,
                             vendor, language):
        a = FileHelper.get_data("common/report/report.json",
                                               language)
        data = [
            [a["table2_1"], pointName],
            [a["table2_2"], areaName + '.' + lineName],
            [a["table2_3"], deviceType],
            [a["table2_4"], vendor],
            [a["table2_5"], spare_num],
            #['Purchase Date', '2018-06-02'],
            [a["table2_6"], timestamp]
            # [a["table2_7"], number]
        ]
        ts = [
            ('ALIGN', (1, 1), (-1, -1), 'LEFT'),  # ('SPAN', (0, 7), (-1, 7)),
            ('INNERGRID', (0, 0), (-1, -1), 1, colors.black),
            ('BOX', (0, 0), (-1, -1), 1, colors.black),
            ('FONT', (0, 0), (-1, -1), 'simsun')
        ]
        t = Table(data, [140, 260], style=ts, hAlign='LEFT')

        deviceTypeList = FileHelper.get_data("common/report/device/chainbed.json",
                                       "deviceTypeList")
        for devicetypelist in deviceTypeList:
            if devicetypelist["deviceType"] == deviceType:
                componentList = devicetypelist["componentList"]
                for component in componentList:
                    if component['componentName'] == pointName:
                        return t, pointPriority, deviceType, pointName, component[
                            'marker'], component["style"]["left"][
                                0:-1], component["style"]["top"][
                                    0:-1], component["style"]["width"][
                                        0:-3], component["style"]["height"][0:-3]

    # 图片打点
    def Alert_Picture(self, deviceType, priority_alert_Table):
        # 拿图片路劲
        img_path=''
        deviceList = FileHelper.get_data('common/report/device/device.json', "deviceList")
        for device in deviceList:
            if device['deviceType'] == deviceType:
                img_path = device['img_path']
                break
        image = Img.open(img_path)

        # 创建绘制对象
        draw = ImageDraw.Draw(image)

        # 设置字体
        #setfont = ImageFont.load_default()
        setfont = ImageFont.truetype("report/simsun.ttc",
                                     size=18,
                                     encoding="unic")

        # 打点
        sizex, sizey = image.size
        for alert in priority_alert_Table:
            if alert == None:
                continue
            try:
                Xzuobiao = float(alert[5])
                Yzuobiao = float(alert[6])
                Xwidth = float(alert[7])
                Yheight = float(alert[8])
            except ValueError:
                break
            if alert[1] == 'high':
                fill = (232, 72, 72)
            elif alert[1] == 'medium':
                fill = (255, 128, 0)
            else:
                fill = (0, 200, 0)
            draw.ellipse((sizex * Xzuobiao / 100, sizey * Yzuobiao / 100,
                          sizex * Xzuobiao / 100 + Xwidth * 20,
                          sizey * Yzuobiao / 100 + Yheight * 20),
                         fill=fill)
            draw.text([
                sizex * Xzuobiao / 100 + Xwidth * 12 -
                Xwidth * 4 * len(str(alert[4])),
                sizey * Yzuobiao / 100 + Yheight * 4
            ],
                str(alert[4]),
                "white",
                font=setfont)

        # 存储并生成Image对象
        tmpbmp = BytesIO()
        image.save(tmpbmp, 'bmp')
        t = Image(tmpbmp, sizex / 3, sizey / 3)

        return t

    def Line_Plot(self, pointName, TimeSeries):
        # print(TimeSeries)
        plt.figure(figsize=[15, 10])
        # 配置横坐标
        plt.gca().xaxis.set_major_formatter(
            mdates.DateFormatter('%m-%d %H:%M:%S'))
        plt.gca().xaxis.set_major_locator(
            mdates.AutoDateLocator())  # 日期显示粒度为自动，可以换成天、周、月、年等

        timestamp = []
        variable = []
        for component in TimeSeries:
            if component['pointName'] == pointName:
                for var in component['data']:
                    for key, value in var.items():
                        if key == '_time':
                            timestamp.append(value)
                        elif "_qc" in key:
                            continue
                        else:
                            variableName = key
                            variable.append(round(float(value), 3))
                if variable:
                    x = [
                        datetime.datetime.strptime(d, '%Y-%m-%d %H:%M:%S.%f')
                        for d in timestamp
                    ]
                    plt.plot(x, variable, label=variableName)
                    # print(x)
                    # print(variable)
                variable.clear()
                timestamp.clear()

        plt.grid(b=True, which='major', axis='y')  # 显示网格线
        plt.legend()
        buf = BytesIO()
        plt.gcf().autofmt_xdate()  # 日期自动排列
        # plt.xlabel('date')
        # plt.ylabel('variable')
        # plt.title(u'双折线图')
        plt.savefig(buf, format='jpg')
        buf.seek(0)
        plt.close()
        return buf
