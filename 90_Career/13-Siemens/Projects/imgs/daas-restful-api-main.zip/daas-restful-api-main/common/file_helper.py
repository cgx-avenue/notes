'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-30 10:38:56
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-09 13:32:01
'''
import json

class FileHelper():
    @classmethod
    def get_json_data_from_file(cls,file):
        content = None
        try:
            with open(file, "r", encoding="utf-8") as json_data:
                content = json.load(json_data)
        except Exception as e:
            print(e)
        return content
    
        
    @classmethod
    def get_data(cls,file, key):
        try:
            with open(file, 'r', encoding="utf-8") as json_data:
                data = json.load(json_data)
                return data[key]
        except Exception as e:
            print(e)
