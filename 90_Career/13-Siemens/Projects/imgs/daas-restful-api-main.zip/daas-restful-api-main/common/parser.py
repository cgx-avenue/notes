'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-25 15:45:13
LastEditors: Yang, Shao Peng
LastEditTime: 2021-11-30 10:24:32
'''
from flask_restful import reqparse
import datetime
from config import Config


class Parser():
    now = datetime.datetime.utcnow() + datetime.timedelta(hours=8)
    before_24h = now - datetime.timedelta(hours=24)
    before_1m = now-datetime.timedelta(days=30)
    before_report = now-datetime.timedelta(hours=Config.REPORT_TIMEDELTA_HOURS)

    parser_from_to_limit = reqparse.RequestParser()
    parser_from_to_limit.add_argument('from')
    parser_from_to_limit.add_argument('to')
    parser_from_to_limit.add_argument('limit', type=int, default=500)

    parser_from_to_24h = reqparse.RequestParser()
    parser_from_to_24h.add_argument('from', default=before_24h)
    parser_from_to_24h.add_argument('to', default=now)

    parser_from_to_1m = reqparse.RequestParser()
    parser_from_to_1m.add_argument('from', default=before_1m)
    parser_from_to_1m.add_argument('to', default=now)

    @classmethod
    def gen_endTime(cls,startTime, timeDeltaHours):
        endTime = startTime-datetime.timedelta(hours=timeDeltaHours)
        return endTime

    @classmethod
    def gen_from_to_parser(cls, startTime=now, endTime=before_24h, needLimit=False, limit=500):
        parser = reqparse.RequestParser()
        parser.add_argument('from', startTime)
        parser.add_argument('to', endTime)
        if needLimit:
            parser.add_argument('limit', type=int, default=limit)
        return parser
