'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-25 11:40:43
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-09 13:09:26
'''
from typing import DefaultDict
from config import Config
from models.alarm_component import AlarmComponentModel
from models.area import AreaModel
from models.alarm import AlarmModel
from models.component_info import ComponentInfoModel
from models.device import DeviceModel
from models.feedback import FeedbackModel
from models.line import LineModel
import datetime
import csv
import calendar
from sqlalchemy import desc, nullslast, func, not_
from io import StringIO
from models.suggestion import SuggestionModel
import xlrd
from db import db


class Util():

    @classmethod
    def get_area_info(cls, areaName):
        now = datetime.datetime.utcnow() + datetime.timedelta(hours=8)
        startTime = now - datetime.timedelta(days=30 * 6)
        devices = cls.get_devices_by_condition(areaName, "*", "*")
        query = AlarmModel.query.join(
            DeviceModel,
            DeviceModel.device_num == AlarmModel.devicenum).join(LineModel).join(AreaModel).filter(
                AreaModel.area == areaName).filter(AlarmModel.timestamp >= startTime)
        alarmCnt = cls.count_alarm(query, "high")
        warningCnt = cls.count_alarm(query, "medium")
        priority = "high" if alarmCnt > 0 else "medium" if warningCnt > 0 else "healthy"
        return priority, len(devices), alarmCnt, warningCnt

    @classmethod
    def get_maintenance_record_by_week(cls, areaName):
        list = []
        now = datetime.datetime.utcnow() + datetime.timedelta(hours=8)
        year = now.year
        maxWeekNum = int(365 / 7) + 1
        # 从配置文件中获取当前年的第一天
        startDay = datetime.datetime.strptime(Config.CALENDAR_WEEK_START_DAY,
                                              "%m-%d")
        firstDay = datetime.datetime(year, startDay.month, startDay.day)
        now_date = datetime.datetime(year, now.month, now.day)
        # 获取多少周
        days = (now_date - firstDay).days
        weekNum = int(days / 7) + 1

        for i in range(Config.WEEKS):
            if i == 0:
                endTime = now
                # startTime = firstDay
                startTime = firstDay + datetime.timedelta(days=(weekNum - 1) *
                                                          7)
            elif weekNum == maxWeekNum:
                endTime = datetime.datetime(year+1, 1, 1)
                startTime = datetime.datetime(year, 12, 25)
            else:
                endTime = firstDay + datetime.timedelta(days=weekNum * 7-5)
                startTime = firstDay + datetime.timedelta(days=(weekNum-1) *
                                                          7-5)
            alarmCnt, warningCnt, solvedAlarmCnt, solvedWarningCnt = cls.get_area_record_timespan(
                areaName, endTime, startTime)
            recordDict = dict(week=weekNum,
                              solvedWarning=solvedWarningCnt,
                              solvedAlarm=solvedAlarmCnt,
                              warning=warningCnt,
                              alarm=alarmCnt)
            list.append(recordDict)
            weekNum -= 1
            if weekNum == 0:
                year -= 1
                weekNum = maxWeekNum
                firstDay = datetime.datetime(
                    year, startDay.month, startDay.day)
        return list

    @classmethod
    def get_area_record_timespan(cls, areaName, endTime, startTime):
        query = AlarmModel.query.join(
            DeviceModel, AlarmModel.devicenum == DeviceModel.device_num).join(LineModel).join(
            AreaModel).filter(AreaModel.area == areaName).filter(
            AlarmModel.timestamp >= startTime,
            AlarmModel.timestamp <= endTime)
        alarmCnt = cls.count_alarm(query, "high")
        warningCnt = cls.count_alarm(query, "medium")
        solvedAlarmCnt = cls.count_alarm(query, "high", 1)
        solvedWarningCnt = cls.count_alarm(query, "medium", 1)
        return alarmCnt, warningCnt, solvedAlarmCnt, solvedWarningCnt

    @classmethod
    def count_alarm(cls, query, priority, status=0):
        alarm_query = query.filter(AlarmModel.priority == priority).filter(
            AlarmModel.status == status)
        cnt = alarm_query.count()
        return cnt

    @classmethod
    def get_maintenance_record_by_month(cls, areaName):
        list = []
        now = datetime.datetime.utcnow() + datetime.timedelta(hours=8)
        year = now.year
        monthNum = now.month
        for i in range(Config.MONTHS):
            startTime = datetime.datetime(year, monthNum, 1)
            if i == 0:
                endTime = now
            elif monthNum == 12:
                endTime = datetime.datetime(year + 1, 1, 1)
            else:
                endTime = datetime.datetime(year, monthNum + 1, 1)

            alarmCnt, warningCnt, solvedAlarmCnt, solvedWarningCnt = cls.get_area_record_timespan(
                areaName, endTime, startTime)

            # 将数字月份转成英文月份，并将各字段添加至字典中
            recordDict = dict(month=calendar.month_name[monthNum],
                              solvedWarning=solvedWarningCnt,
                              solvedAlarm=solvedAlarmCnt,
                              warning=warningCnt,
                              alarm=alarmCnt)
            list.append(recordDict)
            monthNum -= 1
            if monthNum == 0:
                monthNum = 12
                year -= 1
        return list

    @classmethod
    def get_priority_alarm(cls, areaName, lineName, priority, startTime, endTime):
        limit_size = Config.ALARM_QUERY_SIZE
        query = AlarmModel.query.join(
            DeviceModel, AlarmModel.devicenum ==
            DeviceModel.device_num).join(LineModel).join(AreaModel).filter(
            AlarmModel.priority == priority, AlarmModel.status == 0,
            AlarmModel.timestamp >= startTime,
            AlarmModel.timestamp <= endTime)
        if areaName != "*":
            query = query.filter(AreaModel.area == areaName)
        if lineName != "*":
            query = query.filter(LineModel.line == lineName)
        alarms = query.order_by(desc(
            AlarmModel.timestamp)).limit(limit_size).all()

        def to_json(alarm):
            components_list = list(map(lambda x: dict(pointName=x.component,
                                                      pointPriority=x.priority), alarm.components))

            alertTime = datetime.datetime.strftime(alarm.timestamp,
                                                   "%Y-%m-%d %H:%M:%S")
            alarm_dict = dict(alarmID=alarm.id,
                              deviceNum=alarm.devicenum,
                              deviceType=alarm.type,
                              alertTime=alertTime,
                              priority=priority,
                              status=0,
                              components=components_list)
            return alarm_dict
        return list(map(lambda x: to_json(x), alarms))

    @classmethod
    def search_alarm_by_ID(cls, alarmID):
        alarmList = []
        alarm = AlarmModel.get_alarm_or_404(alarmID)
        alertTime = datetime.datetime.strftime(alarm.timestamp,
                                               "%Y-%m-%d %H:%M:%S")
        alarmIndicate = dict(deviceNum=alarm.devicenum,
                             areaName=alarm.device.line.area.area,
                             lineName=alarm.device.line.line,
                             deviceType=alarm.type,
                             alertTime=alertTime,
                             priority=alarm.priority,
                             alarmType=alarm.alarm_type,
                             alarmCode=alarm.alarm_code,
                             status=alarm.status)
        components = []
        for one in alarm.components:
            check_time = None
            component = AlarmComponentModel.query.join(
                AlarmModel, AlarmComponentModel.alarm_id == AlarmModel.id).filter(
                    AlarmModel.devicenum == one.alarm.devicenum).filter(
                        AlarmComponentModel.component == one.component).order_by(
                            nullslast(desc(
                                AlarmComponentModel.check_time))).first()
            if component.check_time:
                check_time = datetime.datetime.strftime(
                    component.check_time, "%Y-%m-%d %H:%M:%S")
            # 针对AGV中“Device”类型报警，是设备的电气故障，没有部件信息
            component_info = ComponentInfoModel.get_component_by_type_and_component(
                alarm.type, one.component)
            if component.component == "Device" or component_info == None:
                componentList = dict(pointName=one.component,
                                     pointPriority=one.priority,
                                     number=None,
                                     spare_num=None,
                                     timestamp=check_time,
                                     vendor=None)
            else:
                componentList = dict(pointName=one.component,
                                     pointPriority=one.priority,
                                     number=component_info.number,
                                     spare_num=component_info.spare_num,
                                     timestamp=check_time,
                                     vendor=component_info.vendor)
            components.append(componentList)
        alarmIndicate["components"] = components
        alarmList.append(alarmIndicate)
        return alarmList

    @classmethod
    def get_suggestion(cls, alarmID):
        suggestionList = []
        suggestions = SuggestionModel.get_suggestions_by_alarmID(alarmID)

        suggestionList = list(map(lambda x: dict(queue=x.queue, component=x.component, sugCode=x.sugCode,
                                                 requireSkill=x.requireSkill, suggestion=x.suggestion), suggestions))
        return suggestionList

    @classmethod
    def insert_feedback(cls, alarmID, dataJson):
        alarm = AlarmModel.get_alarm_or_404(alarmID)
        timestamp = datetime.datetime.strptime(dataJson["completeTime"],
                                               "%Y-%m-%d %H:%M:%S")
        feedback = FeedbackModel.get_feedback_by_alarmID(alarmID)
        if not feedback:
            feedback = FeedbackModel(alarmID, dataJson["valid"],
                                     dataJson["validQueue"], dataJson["comments"],
                                     timestamp)
            feedback.update_to_db()
        else:
            feedback.valid = dataJson["valid"]
            feedback.validQueue = dataJson["validQueue"]
            feedback.comments = dataJson["comments"]
            feedback.timestamp = timestamp
            feedback.update_to_db()
        alarm.completetime = timestamp
        alarm.status = 1  # dataJson["valid"]
        for one in alarm.components:
            one.check_time = timestamp
        alarm.update_to_db()

    # implement later
    @classmethod
    def get_device_insight(cls, deviceNum, startTime, endTime):
        return deviceNum+startTime+endTime

    @classmethod
    def get_devices_by_condition(cls, areaName, lineName, deviceNum):
        query = DeviceModel.query.join(LineModel).join(AreaModel)
        devices = []
        if areaName == "*":
            devices = query.all()
        elif lineName == "*":
            devices = query.filter_by(area=areaName).all()
        elif deviceNum == "*":
            devices = query.filter_by(area=areaName).filter(
                LineModel.line == lineName).all()
        else:
            devices = [DeviceModel.get_device_by_deviceNum(deviceNum)]
        return devices

    @classmethod
    def update_component_csv(cls, deviceType, data):
        data_buffer = StringIO(data.decode('utf-8'))
        next(data_buffer)
        reader = csv.reader(data_buffer)
        now = (datetime.datetime.utcnow() +
               datetime.timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
        for component in reader:
            componentname = component[0]
            spare_num = component[1]
            number = component[2]
            vendor = component[3]
            component_info = ComponentInfoModel().get_component_info_by_name(componentname)
            if component_info == None:
                component_info = ComponentInfoModel(device_type=deviceType,
                                                    component=componentname,
                                                    spare_num=spare_num,
                                                    number=number,
                                                    vendor=vendor,
                                                    timestamp=now)
                component_info.save_to_db()
            else:
                component_info.device_type = deviceType
                component_info.spare_num = spare_num
                component_info.number = number
                component_info.vendor = vendor
                component_info.timestamp = now
                component_info.update_to_db()

    @classmethod
    def update_component_xlsx(cls, deviceType, data):
        book = xlrd.open_workbook(file_contents=data)
        sheet = book.sheets()[0]
        now = (datetime.datetime.utcnow() +
               datetime.timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
        for i in range(sheet.nrows - 1):
            componentname = sheet.row_values(i + 1)[0]
            spare_num = sheet.row_values(i + 1)[1]
            number = sheet.row_values(i + 1)[2]
            vendor = sheet.row_values(i + 1)[3]
            component_info = ComponentInfoModel().get_component_info_by_name(componentname)
            if component_info == None:
                component_info = ComponentInfoModel(device_type=deviceType,
                                                    component=componentname,
                                                    spare_num=spare_num,
                                                    number=number,
                                                    vendor=vendor,
                                                    timestamp=now)
                component_info.save_to_db()
            else:
                component_info.device_type = deviceType
                component_info.spare_num = spare_num
                component_info.number = number
                component_info.vendor = vendor
                component_info.timestamp = now
                component_info.update_to_db()

    @classmethod
    def get_history_alarms(cls, areaName, lineName, deviceNum, startTime, endTime):
        historyList = []
        limit_size = Config.ALARM_QUERY_SIZE
        query = AlarmModel.query.join(
            DeviceModel, AlarmModel.devicenum ==
            DeviceModel.device_num).join(LineModel).join(AreaModel).filter(
            AlarmModel.timestamp >= startTime,
            AlarmModel.timestamp <= endTime)
        if areaName == "*" and lineName == "*":
            alarms = query.order_by(desc(
                AlarmModel.timestamp)).limit(limit_size).all()
        elif areaName != "*" and lineName == "*":
            alarms = query.filter(AreaModel.area == areaName).order_by(
                desc(AlarmModel.timestamp)).limit(limit_size).all()
        elif areaName != "*" and lineName != "*" and deviceNum == "*":
            alarms = query.filter(AreaModel.area == areaName).filter(
                LineModel.line == lineName).order_by(
                desc(AlarmModel.timestamp)).limit(limit_size).all()
        else:
            alarms = AlarmModel.get_alarm_list(
                deviceNum, startTime, endTime, limit_size)

        for alarm in alarms:
            components_list = []
            components = alarm.components

            for component in components:
                components_dict = dict(pointName=component.component,
                                       pointPriority=component.priority)
                components_list.append(components_dict)
            alertTime = datetime.datetime.strftime(alarm.timestamp,
                                                   "%Y-%m-%d %H:%M:%S")
            completeTime = None
            if alarm.completetime:
                completeTime = datetime.datetime.strftime(
                    alarm.completetime, "%Y-%m-%d %H:%M:%S")
            alarm_dict = dict(alarmID=alarm.id,
                              deviceNum=alarm.device.device_num,
                              deviceType=alarm.device.device_type,
                              alertTime=alertTime,
                              priority=alarm.priority,
                              status=alarm.status,
                              completeTime=completeTime,
                              components=components_list)
            historyList.append(alarm_dict)
        return historyList

    @classmethod
    def batch_import_csv(cls, data):
        d = []
        f = StringIO(data.decode('utf-8'))
        next(f)
        reader = csv.reader(f)
        now = (datetime.datetime.utcnow() +
               datetime.timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
        for device in reader:
            deviceNum = device[0]
            #Area = device[1]
            lineName = device[2]
            device_type = device[3]
            description = device[4]
            try:
                line = LineModel.get_line(lineName)
                device = DeviceModel(line_id=line.id,
                                     device_num=deviceNum,
                                     device_type=device_type,
                                     description=description,
                                     timestamp=now)
                device.save_to_db()
            except Exception:
                d.append(deviceNum)
        f.close()
        return d

    @classmethod
    def batch_import_xlsx(cls, data):
        d = []
        book = xlrd.open_workbook(file_contents=data)
        sheet = book.sheets()[0]
        now = (datetime.datetime.utcnow() +
               datetime.timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
        for i in range(sheet.nrows - 1):
            deviceNum = sheet.row_values(i + 1)[0]
            #Area = sheet.row_values(i + 1)[1]
            lineName = sheet.row_values(i + 1)[2]
            Type = sheet.row_values(i + 1)[3]
            Description = sheet.row_values(i + 1)[4]

            try:
                line = LineModel.get_line(lineName)
                device = DeviceModel(line_id=line.id,
                                     device_num=deviceNum,
                                     device_type=Type,
                                     description=Description,
                                     timestamp=now)
                device.save_to_db()
            except Exception:

                d.append(deviceNum)
        return d

    @classmethod
    def get_failure_top5(cls, areaName):
        recordList = []
        data = Config.FAULT_TYPE
        failureStatisticTime = Config.FAILURE_STATISTIC_TIME
        timeLimit = datetime.datetime.utcnow() + datetime.timedelta(
            hours=8) - datetime.timedelta(days=failureStatisticTime)
        # 根据查询条件查出top5的记录，数据结构：（设备名称,部件名称，故障代码，总的故障次数）
        # [('AssemblyAGV_14001FTS', 'Motor', '1250', 8), ...]
        top5 = db.session.query(
            DeviceModel.device_num,
            AlarmComponentModel.component, AlarmComponentModel.error_code,
            func.count(AlarmComponentModel.id)).join(AlarmComponentModel.alarm).join(
                AlarmModel.device).join(DeviceModel.line).join(
                    LineModel.area).filter(AreaModel.area == areaName).filter(
                        AlarmModel.timestamp >= timeLimit).filter(
                            not_(AlarmComponentModel.error_code == None)).group_by(
                                DeviceModel.device_num, AlarmComponentModel.component,
                                AlarmComponentModel.error_code).order_by(
                                    func.count(
                                        AlarmComponentModel.id).desc()).order_by(
                                            DeviceModel.device_num).limit(5).all()
        for a in top5:
            priority, alarm_type = cls.value_parse(int(a[2]))
            maintenanceRecord = dict(top="%s %s" % (a[0], a[1]),
                                     alarmCode=a[2],
                                     type=data[alarm_type],
                                     times=a[3])
            recordList.append(maintenanceRecord)
        basicInfo = AreaModel.query.filter(AreaModel.area == areaName).first()
        return dict(basicInfo=basicInfo.basic_info,
                    cycle=failureStatisticTime,
                    maintenanceRecord=recordList)

    def value_parse(value):
        # value = int(value, 10)
        t1 = value % 10
        t2 = int(value / 10) % 10
        t3 = int(value / 100) % 10
        t4 = int(value / 1000) % 10

        if t3 == 0:
            priority = "healthy"
        elif t3 == 1:
            priority = "medium"
        else:
            priority = "high"
        alarm_type = str(t2) + str(t1)
        return priority, alarm_type

    @classmethod
    def failure_statistics(cls, deviceNum):
        deviceFailuresArray = []
        deviceFailureStatisticTime = Config.DEVICE_FAILURE_STATISTIC_TIME
        timeLimit = datetime.datetime.utcnow() + datetime.timedelta(
            hours=8) - datetime.timedelta(days=deviceFailureStatisticTime)
        # 根据查询条件查出top5的记录，数据结构：（设备名称,部件名称，总的故障次数）
        # [('AssemblyAGV_14001FTS', 'Motor', 8), ('LogisticsAGV_13001FTS', 'Motor',  8)...]
        comTop5 = db.session.query(
            DeviceModel.device_num,
            AlarmComponentModel.component,
            func.count(AlarmComponentModel.id)).join(AlarmComponentModel.alarm).join(
                AlarmModel.device).filter(DeviceModel.device_num == deviceNum).filter(
            AlarmModel.timestamp >= timeLimit).group_by(
            DeviceModel.device_num, AlarmComponentModel.component).order_by(
            func.count(
                AlarmComponentModel.id).desc()).limit(5).all()
        # print(comTop5)
        for one in comTop5:
            failuresArray = []
            # 根据查询条件查出的记录，数据结构：（部件名称，故障代码，故障类型，总的故障次数）
            # [('Bearing2', '1100', 'Vibration anomaly', 41), ...]
            failures = db.session.query(
                AlarmComponentModel.component, AlarmComponentModel.component_type,
                func.count(AlarmComponentModel.id)).join(AlarmComponentModel.alarm).filter(AlarmComponentModel.component == one[1]).filter(
                AlarmModel.timestamp >= timeLimit).group_by(
                AlarmComponentModel.component, AlarmComponentModel.component_type).order_by(
                func.count(
                    AlarmComponentModel.id).desc()).all()
            # print(failures)
            num = 0
            other_times = 0
            for a in failures:
                jsodata = Config.FAULT_TYPE
                code = cls.get_error_by_faultType(jsodata, a[1])
                code_new = "12"+code
                num += 1
                if num <= 8:
                    failuresDict = dict(
                        failure=a[1], failureCode=code_new, times=a[2])
                    failuresArray.append(failuresDict)
                elif num > 8 and num < len(failures):
                    other_times += a[2]
                else:
                    other_times += a[2]
                    failuresDict = dict(
                        failure="others", failureCode="others", times=other_times)
                    failuresArray.append(failuresDict)
            deviceFailuresDict = dict(
                component=one[1], times=one[2], failures=failuresArray)
            deviceFailuresArray.append(deviceFailuresDict)

        return deviceFailuresArray

    def get_error_by_faultType(jsondata, faultType):
        for key, value in jsondata.items():
            if value == faultType:
                return key

    @classmethod
    def get_data_insight_ts(cls, alarmID, startTime, endTime):
        temp = AlarmComponentModel.query.join(
            AlarmModel).filter(AlarmModel.id == alarmID).first()
        # for real case, please use below one
        #  table_name = temp.alarm.devicenum + temp.component
        table_name = temp.alarm.devicenum + '_xdk_'+temp.component
        sql = "select * from {} where timestamp > '{}' and timestamp < '{}'".format(
            table_name, startTime, endTime)
        cursor = db.session.execute(sql)
        rows = cursor.fetchall()
        cols = rows[0]._fields
        data = []
        for row in rows:
            print(row._data)
            data_line = []
            for d in row._data:
                if type(d) == datetime.datetime:
                    data_line.append(d.strftime('%Y-%m-%d %H:%M:%S'))
                else:
                    data_line.append(d)
            data.append(data_line)
        return dict(cols=cols, data=data)
