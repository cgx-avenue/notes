'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-30 10:30:55
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-01 15:14:12
'''
from flask_restful import Resource
from common.file_helper import FileHelper

# 3.3.19



class AssetModel(Resource):
    def get(self, deviceNum):
        try:
            json_data = FileHelper.get_json_data_from_file('assetModel.json')
            device = []
            try:
                data = json_data[deviceNum]
            except Exception as e:
                return "deviceNum is not in assetModel"
            for key in data.keys():
                varList = []
                list = data[key]
                for item in list[0].items():
                    varDict = dict(variable=item[0], unit=item[1])
                    varList.append(varDict)
                aspectDict = dict(aspectName=key, variables=varList)
                device.append(aspectDict)
            body = dict(deviceNum=device)

        except Exception as e:
            return {'msg': str(e)}, 406
        return {'code': 200, 'status': 'OK', 'body': body}
