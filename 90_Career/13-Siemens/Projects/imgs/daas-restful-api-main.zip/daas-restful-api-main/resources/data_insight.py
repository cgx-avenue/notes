'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-26 13:55:25
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-08 14:49:57
'''
from flask_restful import Resource
from common.parser import Parser
from common.util import Util

# 3.3.8


class DataInsightDeviceNum(Resource):
    def get(self, deviceNum):
        try:
            data = Parser.parser_from_to_24h.parse_args(strict=True)
            dataList = Util.get_device_insight(
                deviceNum, data['from'], data['to'])
        except Exception as e:
            return {'msg': str(e)}, 401
        return {'dataList': dataList}
# 3.3.18


class DataInsightTS(Resource):
    def get(self, alarmID):
        try:
            data = Parser.parser_from_to_24h.parse_args(strict=True)
            result = Util.get_data_insight_ts(
                alarmID, data['from'], data['to'])
            # implement new database query code
        except Exception as e:
            return {'msg': str(e)}, 401
        return {'code': 200, 'message': 'OK', 'data': result}

# 3.3.24


class DataInsightDeviceFailure(Resource):
    def get(self, deviceNum):
        try:
            data = Util.failure_statistics(deviceNum)

        except Exception as e:
            return {'msg': str(e)}, 401
        return {'code': 200, 'message': 'OK', 'deviceFailures': data}
