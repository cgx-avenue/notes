'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-30 09:35:18
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-09 13:25:12
'''

from flask_restful import Resource
from common.util import Util
from common.parser import Parser
import datetime
from config import Config
from common.report.report import Report as RP
from flask import send_file
# 3.3.17
class Report(Resource):
    def get(self,alarmID,alertTime):
        try:
            data = Parser.parser_from_to_24h.parse_args(strict=True)
            alertTimestamp = datetime.datetime.strptime(alertTime,
                                                    "%Y-%m-%d %H:%M:%S")
            #2天前时间的string
            beforeStr = (alertTimestamp - datetime.timedelta(
                hours=Config.REPORT_TIMEDELTA_HOURS)).strftime("%Y-%m-%d %H:%M:%S")

            #从参数中获取初始时间和结束时间，并转换成云上所需的时间格式

            start_time = (
                datetime.datetime.strptime(data['from'], "%Y-%m-%d %H:%M:%S") -
                datetime.timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
            end_time = (datetime.datetime.strptime(data['to'], "%Y-%m-%d %H:%M:%S") -
                        datetime.timedelta(
                            hours=8, seconds=-1)).strftime("%Y-%m-%d %H:%M:%S")
            startTime = "%.23sZ" % str(start_time.replace(' ', 'T'))
            endTime = "%.23sZ" % str(end_time.replace(' ', 'T'))
            # print(endTime)
            #3.3.18拿数据
            TimeSeries = Util.get_data_insight_ts(alarmID, startTime,
                                                    endTime)
            #3.3.4拿数据
            data = Util.search_alarm_by_ID(alarmID)

            #3.3.6拿建议
            suggestions = Util.get_suggestion(alarmID)
            # print(suggestions)
            rp=RP()
            sio, reportName = rp.generate_report(data, suggestions, TimeSeries,
                                                    "CN")
            sio.seek(0)
            
        except Exception as e:
            return {'msg':str(e)},406
        return send_file(filename_or_fp=sio,
                         mimetype="application/pdf",
                         as_attachment=True,
                         attachment_filename=reportName)