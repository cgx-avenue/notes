'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-24 14:17:37
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-01 14:52:14
'''

from flask_restful import Resource
from models.alarm import AlarmModel
# from common.parser import parser_from_to_limit, parser_from_to_24h,parser_from_to_1m
from common.util import Util
from common.parser import Parser

# 3.2.2
class AlarmDeviceID(Resource):
    def get(self, deviceID):
        try:
            data = Parser.parser_from_to_limit.parse_args(strict=True)
            alarmList = AlarmModel.get_alarm_list(deviceID,
                                                  data['from'], data['to'], data['limit'],True)

        except Exception as e:
            return {'msg': str(e)}, 401
        return {'code': 200, 'message': 'OK', 'body': {'alarms': alarmList}}

# 3.2.1
class AlarmList(Resource):
    def get(self):
        try:
            data = Parser.parser_from_to_limit.parse_args(strict=True)
            alarmList = AlarmModel.get_alarm_list(None,
                                                  data['from'], data['to'], data['limit'],True)

        except Exception as e:
            return {'msg': str(e)}, 400
        return {'code': 200, 'message': 'OK', 'body': {'alarms': alarmList}}

#  3.3.3
class AlarmDeviceAreaLine(Resource):
    def get(self, areaName, lineName, priority):
        try:
            data = Parser.parser_from_to_24h.parse_args(strict=True)
            alarmList = Util.get_priority_alarm(
                areaName, lineName, priority, data['from'], data['to'])
        except Exception as e:
            return {'msg': str(e)}, 400
        return {'code': 200, 'message': 'OK', 'body': {'alarmList': alarmList}}

#  3.3.4
class AlarmIndicateAlarmID(Resource):
    def get(self, alarmID):
        try:
            alarms = Util.search_alarm_by_ID(alarmID)
        except Exception as e:
            return {'msg': str(e)}, 400
        return {'code': 200, 'message': 'OK', 'body': {'alarmIndicate': alarms}}

#  3.3.6
class AlarmSuggestion(Resource):
    def get(self, alarmID):
        try:
            suggestions = Util.get_suggestion(alarmID)
        except Exception as e:
            return {'msg': str(e)}, 400
        return {'code': 200, 'message': 'OK', 'body': {'suggestions': suggestions}}

# 3.3.16
class HistoryAlarm(Resource):
    def get(self, areaName, lineName, deviceNum):
        try:
            data = Parser.parser_from_to_1m.parse_args(strict=True)
            alarms = Util.get_history_alarms(
                areaName, lineName, deviceNum, data['from'], data['to'])
        except Exception as e:
            return {'msg': str(e)}, 406
        return {'code': 200, 'message': 'OK', 'body': {'alarmList': alarms}}
