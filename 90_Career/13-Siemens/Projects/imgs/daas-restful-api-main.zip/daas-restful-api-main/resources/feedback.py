'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-25 16:55:40
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-01 13:08:20
'''
from flask_restful import Resource
from flask import request
import json
from common.util import Util


# 3.3.7
class Feedback(Resource):
    def post(self,alarmID):
        if not request.data:
            return "no feedback, request.data is empty"
        data = request.data.decode("utf-8")
        dataJson = json.loads(data)
        Util.insert_feedback(alarmID, dataJson)
        return {"code":"200","message":"OK","body":dataJson}
