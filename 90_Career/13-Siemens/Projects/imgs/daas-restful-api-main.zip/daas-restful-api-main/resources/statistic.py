'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-24 15:18:07
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-01 11:07:12
'''
from flask_restful import Resource
from common.util import Util
from models.area import AreaModel

# 3.3.1
class Statistic(Resource):
    def get(self):
        try:
            statistics = []
            areas = AreaModel.get_area_all()

            for area in areas:
                area_info = Util.get_area_info(area.area)
                area_stat = dict(areaName=area.area,
                                 poritory=area_info[0],
                                 totalNum=area_info[1],
                                 highAlertNum=area_info[2],
                                 mediumAlertNum=area_info[3])
                statistics.append(area_stat)

        except Exception as e:
            return {'msg': str(e)}, 406
        return {'code': 200, 'message': 'OK', 'body': {'statistic': statistics}}

# 3.3.2
class StatisticArea(Resource):
    def get(self, areaName, timeWindow):
        try:
            area = AreaModel.get_area(areaName)
            if timeWindow == "week":
                list = Util.get_maintenance_record_by_week(areaName)
            elif timeWindow == "month":
                list = Util.get_maintenance_record_by_month(areaName)
            record = dict(areaName=areaName,
                        priority=Util.get_area_info(areaName)[0],
                        basicInfo=area.basic_info,
                        maintenanceRecord=list)

        except Exception as e:
            return {'msg':str(e)},406
        return {'code':200,'message':'OK','body':{'areaMaintenance':record}}
