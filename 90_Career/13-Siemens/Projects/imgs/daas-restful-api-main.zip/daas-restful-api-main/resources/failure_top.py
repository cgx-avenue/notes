'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-30 13:48:56
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-01 16:20:49
'''
from flask_restful import Resource
from common.util import Util

# 3.3.23
class FailureTop(Resource):
    def get(self,areaName):
        try:
            failures=Util.get_failure_top5(areaName)
            # raise Exception("eeeee")
        except Exception as e:
            return {'msg': str(e)}, 406
        return {'code': 200, 'message': 'OK', 'body': failures}
