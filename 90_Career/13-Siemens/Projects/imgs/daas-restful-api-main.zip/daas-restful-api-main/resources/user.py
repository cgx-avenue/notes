'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 10:29:32
LastEditors: Yang, Shao Peng
LastEditTime: 2021-11-23 15:23:24
'''
from flask_restful import Resource
from flask import request
from models.user import UserModel

class User(Resource):
    def get(self,username):
        user=UserModel.find_by_name(username)
        if not user:
            return {'msg':'user not found'},404
        return user.json()