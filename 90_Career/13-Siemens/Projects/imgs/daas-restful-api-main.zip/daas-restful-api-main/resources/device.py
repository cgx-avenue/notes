'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-24 10:18:19
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-01 16:19:06
'''
from flask_restful import Resource
from models.area import AreaModel
from models.component_info import ComponentInfoModel
from models.device import DeviceModel
from models.device_type import DeviceTypeModel
from models.line import LineModel
from common.util import Util
import datetime
import json
import os
import base64
import urllib
from flask import request,send_file


# This file constains 1. device, 2. deviceManagement, 3. device_type
# 3.3.9
class DeviceInfo(Resource):
    def get(self):
        try:
            deviceinfo = AreaModel.get_device_info()
            # raise Exception("eeeee")
        except Exception as e:
            return {'msg': str(e)}, 406
        return {'code': 200, 'message': 'OK', 'body': {'deviceinfo': deviceinfo}}

# 3.3.20
class DeviceType(Resource):
    def get(self):
        try:
            typeList = DeviceTypeModel.get_device_types()
            # raise Exception("eeeee")
        except Exception as e:
            return {'msg': str(e)}, 406
        return {'code': 200, 'message': 'OK', 'body':  typeList}

#  3.3.10


class DeviceManagementQuery(Resource):
    def get(self, areaName, lineName, deviceNum):
        try:
            devices = Util.get_devices_by_condition(
                areaName, lineName, deviceNum)
            deviceInfo = []
            for device in devices:
                deviceInfoDict = dict(
                    deviceID=device.id,
                    deviceNum=device.device_num,
                    line=device.line.line,
                    deviceType=device.device_type,
                    area=device.line.area.area,
                    updateTime=device.timestamp.strftime("%Y-%m-%d %H:%M:%S"))
                deviceInfo.append(deviceInfoDict)
        except Exception as e:
            return {'msg': str(e)}, 406
        return {'code': 200, 'message': 'OK', 'body': {'deviceInfo': deviceInfo}}

# 3.3.11


class DeviceManagementAdd(Resource):
    def post(self, lineName, deviceType, deviceNum):
        try:
            line = LineModel.get_line(lineName)
            if line == None:
                return "数据库中无此生产线！"
            device = DeviceModel.get_device_by_deviceNum(deviceNum)
            if device:
                return "数据库中设备已经存在！"
            device = DeviceModel(
                line_id=line.id,
                device_num=deviceNum,
                device_type=deviceType,
                description=None,
                timestamp=(
                    datetime.datetime.utcnow() +
                    datetime.timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S'))
            device.save_to_db()
            body = dict(
                deviceID=device.id,
                deviceNum=deviceNum,
                line=lineName,
                area=line.area.area,
                deviceType=deviceType,
                timestamp=device.timestamp.strftime('%Y-%m-%d %H:%M:%S'))
        except Exception as e:
            return {'msg': str(e)}, 406
        return {'code': 200, 'message': 'OK', 'body': body}

# 3.3.12


class DeviceManagementUpdate(Resource):
    def post(self, deviceID):
        try:
            data = json.loads(request.get_data().decode('utf-8'))
            line = LineModel.get_line(data.get('line'))
            if line == None:
                return "数据库中无此生产线！"
            device = DeviceModel.get_device_by_ID(deviceID)
            if device == None:
                return "数据库中无此设备！"
            device.line_id = line.id
            device.device_num = data.get('deviceNum')
            device.device_type = data.get('deviceType')
            device.timestamp = data.get('timestamp')
            device.update_to_db()
        except Exception as e:
            return {'msg': str(e)}, 406
        return {'code': 200, 'message': 'OK', 'body': {'status': 1}}

# 3.3.13
# why not use delete?


class DeviceManagementDelete(Resource):
    def post(self, deviceID):
        try:
            device = DeviceModel.get_device_by_ID(deviceID)
            if device == None:
                return "数据库中无此device"
            device.delete_device_by_ID()
        except Exception as e:
            return {'msg': str(e)}, 406
        return {'code': 200, 'message': 'OK', 'body': {'status': 1}}

# need to test with a file
# reconstructed, really cannot bear original code

# 3.3.14


class DeviceManagementUpdateComponent(Resource):
    def post(self, deviceType):
        try:
            f = request.files["file"]
            data = f.read()
            extension = os.path.splitext(f.filename)[1]
            if extension == ".csv":
                Util.update_component_csv(deviceType, data)
            elif extension == ".xlsx":
                Util.update_component_xlsx(deviceType, data)
            else:
                raise SyntaxError(
                    "file type error, only .csv and .xlsx is supported")
        except Exception as e:
            return {'msg': str(e)}, 406
        return {'code': 200, 'message': 'OK', 'body': {'status': 1}}

# 3.3.15
class DeviceManagementQueryComponent(Resource):
    def get(self, deviceType):
        try:
            components = ComponentInfoModel.get_components_all(deviceType)
            ret = list(map(lambda x: dict(component=x.component,
                                          spare_num=x.spare_num,
                                          number=x.number,
                                          vendor=x.vendor,
                                          timestamp=x.timestamp.strftime(
                                              '%Y-%m-%d %H:%M:%S')), components))
        except Exception as e:
            return {'msg': str(e)}, 406
        return {'code': 200, 'message': 'OK', 'body': ret}

# 3.3.21
class DeviceManagementBatchImport(Resource):
    def post(self):
        response = {}
        try:
            f = request.files["file"]
            data = f.read()
            extension = os.path.splitext(f.filename)[1]
            if extension == ".csv":
                status = Util.batch_import_csv(data)
            elif extension == ".xlsx":
                status = Util.batch_import_xlsx(data)
            else:
                status = "Component type error"
            if status:
                response = dict(invalidList=status)
            else:
                response = dict(status=1)
        except Exception as e:
            return {'message': 'Partial insertion failure', 'body': response}, 501
        return {'code': 200, 'message': 'OK', 'body': {'status': 1}}


# 3.3.22 changed the way how it passed the args, refer to postman file 
class DeviceManagementBatchExport(Resource):
    def get(self):
        try:
            devices=[]
            data = request.args.get("deviceIdList")
            if data=="*":
                devices=DeviceModel.get_device_all()
            else:
                import json
                json_data=json.loads(data)
                for deviceID in json_data:
                    device=DeviceModel.get_device_by_ID(deviceID)
                    if device==None:
                        continue
                    else:
                        devices.append(device)
            import xlwt
            workbook = xlwt.Workbook()
            worksheet = workbook.add_sheet('Sheet1')
            row0 = ['DeviceNumber', 'Area', 'Line', 'Type', 'Description']
            for i in range(0, len(row0)):
                worksheet.write(0, i, row0[i])
            rowcount = 1

            for device in devices:
                worksheet.write(rowcount, 0, device.device_num)
                worksheet.write(rowcount, 1, device.line.area.area)
                worksheet.write(rowcount, 2, device.line.line)
                worksheet.write(rowcount, 3, device.device_type)
                worksheet.write(rowcount, 4, device.description)
                rowcount += 1
            from io import BytesIO
            f = BytesIO()
            workbook.save(f)
            f.seek(0)

        except Exception as e:
            return {'msg': str(e)}, 406
        return  send_file(filename_or_fp=f,
                     mimetype="application/excel",
                     as_attachment=True,
                     attachment_filename="export_device.xls")
