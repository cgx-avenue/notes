'''
Description: This file maps the configuration info from .env (enabled by dotenv)
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 10:03:54
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-07 16:14:17
'''
from dotenv import load_dotenv
import os
load_dotenv(verbose=True, override=True)


class Config():
    DEBUG = True
    P_DB_URI = os.getenv("P_DB_URI")
    # iotlab.live
    P_DB_URI_2=os.getenv("P_DB_URI_2")
    WEEKS = 8
    MONTHS = 6
    ALARM_QUERY_SIZE = 500
    CALENDAR_WEEK_START_DAY = "01-01"
    REPORT_TIMEDELTA_HOURS = 48
    FAULT_TYPE = {
        "00": "Vibration anomaly",
        "01": "Temperature anomaly",
        "02": "Bearings roller wear",
        "03": "Bearing cage wear",
        "04": "Bearing outer race wear",
        "05": "Bearing inner race wear",
        "06": "Bearing skidding",
        "07": "Bearing inner race sliding on shaft",
        "08": "Bearing outer race loose in housing",
        "09": "Bearing electric corrosion",
        "10": "Abnormal peak in low frequency band",
        "11": "Device structure damage",
        "12": "Multiple bearings alarm",
        "20": "Left emergency stop in AGV",
        "21": "Right emergency stop in AGV",
        "22": "Front emergency stop in AGV",
        "23": "Behind emergency stop in AGV",
        "24": "Position emergency stop in AGV",
        "25": "Mobile panel emergency stop in AGV",
        "37": "AGV area emergency stop",
        "26": "AGV profinet failure",
        "27": "AGV profibus failure",
        "28": "AGV RS422 failure",
        "29": "AGV IO Link failure",
        "30": "AGV driver1 failure",
        "31": "AGV driver2 failure",
        "32": "AGV the first fuse damaged",
        "33": "AGV the second fuse damaged",
        "34": "AGV the third fuse damaged",
        "35": "AGV the fourth fuse damaged",
        "36": "AGV general fuse damaged",
        "38": "AGV communication failure",
        "50": "Vibration anomaly in motor",
        "51": "Temperature anomaly in motor",
        "52": "Abnormal peak in low frequency band",
        "53": "Motor stator eccentricity or soft foot",
        "54": "Loose motor stator windings",
        "55": "Motor rotor bow",
        "56": "Cracked or broken motor rotor bars",
        "57": "Loose motor rotor",
        "58": "Loose motor rotor bar",
        "59": "Loose connection"
    }
    FAILURE_STATISTIC_TIME = 90
    DEVICE_FAILURE_STATISTIC_TIME = 30
