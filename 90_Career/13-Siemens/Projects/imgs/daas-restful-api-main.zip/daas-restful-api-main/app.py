'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 09:47:28
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-09 10:41:44
'''
from config import Config
from db import db
from flask import Flask
from flask_restful import Api
from resources import user, feedback, device, alarm, statistic, data_insight, report, asset_model, failure_top


app = Flask(__name__)

# DB configuration and initial
app.config['SQLALCHEMY_DATABASE_URI'] = Config.P_DB_URI_2 #Config.P_DB_URI
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# put native Flask api code below


@app.route('/')
def hello():
    return "hello"


# put flask_restful api code below
api = Api(app)
# 3.2.1
api.add_resource(alarm.AlarmList, '/alarm/alarmList')
# 3.2.2
api.add_resource(alarm.AlarmDeviceID, '/alarm/deviceID/<string:deviceID>')
# 3.3.1
api.add_resource(statistic.Statistic, '/statistic')
# 3.3.2
api.add_resource(statistic.StatisticArea,
                 '/statistic/area/<string:areaName>/timeWindow/<any(month,week):timeWindow>')
# 3.3.3
api.add_resource(alarm.AlarmDeviceAreaLine,
                 '/alarm/deviceAlarm/area/<string:areaName>/line/<string:lineName>/priority/<any(high,medium):priority>')
# 3.3.4
api.add_resource(alarm.AlarmIndicateAlarmID,
                 '/alarm/indicate/alarmID/<int:alarmID>')
# 3.3.5 is lost
# /alarm/indicate/deviceNum/{deviceNum}

# 3.3.6
api.add_resource(alarm.AlarmSuggestion,
                 '/alarm/suggestion/alarmID/<int:alarmID>')
# 3.3.7 post
api.add_resource(feedback.Feedback, '/feedback/alarmID/<int:alarmID>')
# 3.3.8
api.add_resource(data_insight.DataInsightDeviceNum,
                 '/dataInsight/deviceNum/<string:deviceNum>')
# 3.3.9
api.add_resource(device.DeviceInfo, '/device')
# 3.3.10 this interface is strange and tricky
api.add_resource(device.DeviceManagementQuery,
                 '/deviceManagement/querydevice/area/<string:areaName>/productionline/<string:lineName>/device/<string:deviceNum>')
# 3.3.11 post
api.add_resource(device.DeviceManagementAdd,
                 '/deviceManagement/addDevice/productionline/<lineName>/type/<deviceType>/device/<deviceNum>')
# 3.3.12 post
api.add_resource(device.DeviceManagementUpdate,
                 '/deviceManagement/updateDevice/<string:deviceID>')
# 3.3.13 post
api.add_resource(device.DeviceManagementDelete,
                 '/deviceManagement/deleteDevice/<string:deviceID>')
# 3.3.14
api.add_resource(device.DeviceManagementUpdateComponent,
                 '/deviceManagement/updateComponent/<string:deviceType>')
# 3.3.15
api.add_resource(device.DeviceManagementQueryComponent,
                 '/deviceManagement/queryComponent/<string:deviceType>')
# 3.3.16
api.add_resource(alarm.HistoryAlarm,
                 '/alarm/deviceAlarm/area/<areaName>/line/<lineName>/device/<deviceNum>')
# 3.3.17, implement later, after time series data from MS changed to database
api.add_resource(
    report.Report, '/report/alarmID/<alarmID>/alertTime/<alertTime>')
# 3.3.18
api.add_resource(data_insight.DataInsightTS,
                 '/dataInsight/TS/alarmID/<int:alarmID>')
# 3.3.19
api.add_resource(asset_model.AssetModel,
                 '/assetModel/deviceNum/<string:deviceNum>')
# 3.3.20
api.add_resource(device.DeviceType, '/device/type')
# 3.3.21
api.add_resource(device.DeviceManagementBatchImport,
                 '/deviceManagement/batchImport')
# 3.3.22, modified the way to upload para
api.add_resource(device.DeviceManagementBatchExport,
                 '/deviceManagement/batchExport')
# 3.3.23
api.add_resource(failure_top.FailureTop, '/failureTop/area/<string:areaName>')
# 3.3.24
api.add_resource(data_insight.DataInsightDeviceFailure,
                 '/dataInsight/deviceFailure/deviceNum/<string:deviceNum>')
# 3.3.25 & 3.3.26 will not implement


api.add_resource(user.User, '/user', '/user/<string:username>')


if __name__ == '__main__':
    app.run(debug=True)
