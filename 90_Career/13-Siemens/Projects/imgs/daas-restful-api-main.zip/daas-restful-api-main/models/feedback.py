'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 13:19:48
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-01 13:13:22
'''
from db import db
class FeedbackModel(db.Model):
    __tablename__ = 'feedback'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    valid = db.Column(db.Integer)
    validQueue = db.Column(db.Integer)
    comments = db.Column(db.String(200))
    timestamp = db.Column(db.DateTime)
    other = db.Column(db.String(100))

    alarm_id = db.Column(db.Integer, db.ForeignKey('alarm.id'), nullable=False)
    alarm = db.relationship("AlarmModel", back_populates="feedbacks")

    def __init__(self, alarm_id, valid, validQueue, comments, timestamp):
        self.alarm_id = alarm_id
        self.valid = valid
        self.validQueue = validQueue
        self.comments = comments
        self.timestamp = timestamp

    def save_to_db(self):
        db.session.add(self)
        db.session.commit()

    def update_to_db(self):
        db.session.commit()

    @classmethod
    def get_feedback_by_alarmID(cls,alarmID):
        feedback = FeedbackModel.query.filter_by(alarm_id=alarmID).first()
        return feedback