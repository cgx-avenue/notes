'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 13:59:52
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-01 15:19:52
'''
from db import db

from models.component_info import ComponentInfoModel

class DeviceTypeModel(db.Model):
    __tablename__ = 'deviceType'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    typeName = db.Column(db.String(50), nullable=False, unique=True)
    updateTime = db.Column(db.DateTime)
    other = db.Column(db.String(100))
    devices = db.relationship('DeviceModel', back_populates='deviceType')
    componentInfo = db.relationship('ComponentInfoModel',
                                    back_populates='deviceType')

    def __init__(self, typeName, updateTime):
        self.typeName = typeName
        self.updateTime = updateTime

    @classmethod
    def get_device_types(cls):
        types=DeviceTypeModel.query.all()
        typeList = list(map(lambda x:x.typeName,types))
        return dict(typeList=typeList)