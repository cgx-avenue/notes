'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 10:21:58
LastEditors: Yang, Shao Peng
LastEditTime: 2021-11-26 15:46:10
'''
from db import db
import datetime


class UserModel(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, autoincrement=True,primary_key=True)
    email = db.Column(db.String(50))
    username = db.Column(db.String(50))
    password = db.Column(db.String(50))
    role = db.Column(db.String(100))
    updateTime = db.Column(db.DateTime, default=datetime.datetime.now)

    def __init__(self, username, email,password,role):
        self.username = username
        self.email = email
        # hash and salt should be added here
        self.password=password
        self.role=role


    def __repr__(self):
        return f"{self.username}:{self.email}"

    def to_json(self):
        return {
            'id': self.id,
            'name': self.username,
            'age': self.email
        }

    def save_to_db(self):
        db.session.add(self)
        db.session.commit()

    @classmethod
    def find_by_name(cls, username):
        return cls.query.filter_by(username=username).first()
