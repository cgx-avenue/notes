'''
Description: This table is not created?
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 11:22:44
LastEditors: Yang, Shao Peng
LastEditTime: 2021-11-23 15:08:22
'''
from db import db
class PlanMaintenanceModel(db.Model):
    __tablename__ = "planMaintenance"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    weekNum = db.Column(db.Integer, nullable=False)
    planCount = db.Column(db.Integer, nullable=False)
    updateTime = db.Column(db.DateTime)
    other = db.Column(db.String)

    def __init__(self, weekNum, planCount, updateTime):
        self.weekNum = weekNum
        self.planCount = planCount
        self.updateTime = updateTime
