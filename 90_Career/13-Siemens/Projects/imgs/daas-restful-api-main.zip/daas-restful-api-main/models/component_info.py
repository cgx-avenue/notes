'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 13:57:20
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-01 12:52:59
'''
from db import db
class ComponentInfoModel(db.Model):
    __tablename__ = 'componentinfo'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    component = db.Column(db.String(25), nullable=False)
    spare_num = db.Column(db.String(50))
    number = db.Column(db.Integer, nullable=False)
    vendor = db.Column(db.String(50))
    timestamp = db.Column(db.DateTime)
    other = db.Column(db.String(200))
    other1 = db.Column(db.String(200))

    device_type = db.Column(db.String(50),
                            db.ForeignKey('deviceType.typeName'),
                            nullable=False)

    deviceType = db.relationship(
        "DeviceTypeModel", back_populates="componentInfo")

    def __init__(self, device_type, component, spare_num, number, vendor,
                 timestamp):
        self.device_type = device_type
        self.component = component
        self.spare_num = spare_num
        self.number = number
        self.vendor = vendor
        self.timestamp = timestamp

    def save_to_db(self):
        db.session.add(self)
        db.session.commit()

    def update_to_db(self):
        db.session.commit()

    @classmethod
    def get_component_info_by_name(cls, componentName):
        component_info = ComponentInfoModel.query.filter_by(
            component=componentName).first()
        return component_info

    @classmethod
    def get_components_all(cls, deviceType):
        components = ComponentInfoModel.query.filter_by(
            device_type=deviceType).all()
        return components

    @classmethod
    def get_component_by_type_and_component(cls,device_type,component):
        component_info = ComponentInfoModel.query.filter_by(
                device_type=device_type, component=component).first()
        return component_info
