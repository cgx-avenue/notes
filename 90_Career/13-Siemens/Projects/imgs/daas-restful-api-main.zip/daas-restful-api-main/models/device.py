'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 13:56:23
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-01 16:05:15
'''
from db import db
from models.line import LineModel
from models.alarm import AlarmModel
from models.device_type import DeviceTypeModel

class DeviceModel(db.Model):
    __tablename__ = 'device'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    device_num = db.Column(db.String(25), nullable=False)
    device_type = db.Column(db.String(50),
                            db.ForeignKey('deviceType.typeName'),
                            nullable=False)
    description = db.Column(db.String(25))
    timestamp = db.Column(db.DateTime)
    other = db.Column(db.String(100))
    line_id = db.Column(db.Integer, db.ForeignKey('line.id'), nullable=False)

    line = db.relationship('LineModel', back_populates='devices')
    deviceType = db.relationship("DeviceTypeModel", back_populates="devices")

    alarms = db.relationship('AlarmModel',
                             back_populates='device',
                             cascade='all, delete-orphan')

    def __init__(self, line_id, device_num, device_type, description,
                 timestamp):
        self.line_id = line_id
        self.device_num = device_num
        self.device_type = device_type
        self.description = description
        self.timestamp = timestamp

    @classmethod
    def get_device_by_deviceNum(cls,deviceNum):
        device = cls.query.filter_by(device_num=deviceNum).first()
        return device
        
    @classmethod
    def get_device_by_ID(cls,deviceID):
        device=cls.query.filter_by(id=deviceID).first()
        return device

    @classmethod
    def get_device_all(cls):
        devices=cls.query.all()
        return devices
    
    def delete_device_by_ID(self):
        db.session.delete(self)
        db.session.commit()
    
    def save_to_db(self):
        db.session.add(self)
        db.session.commit()

    def update_to_db(self):
        db.session.commit()
