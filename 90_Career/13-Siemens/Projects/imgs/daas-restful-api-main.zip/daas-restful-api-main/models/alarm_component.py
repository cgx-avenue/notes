'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 11:18:58
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-09 09:28:37
'''
from db import db
class AlarmComponentModel(db.Model):
    __tablename__ = 'alarm_component'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    component = db.Column(db.String(25), nullable=False)
    priority = db.Column(db.String(25), nullable=False)
    other = db.Column(db.String(100), nullable=True)
    component_type = db.Column(db.String(25), nullable=False)
    check_time = db.Column(db.DateTime)
    
    alarm_id = db.Column(db.Integer, db.ForeignKey('alarm.id'), nullable=False)
    error_code = db.Column(db.String(10), nullable=True)

    alarm = db.relationship("AlarmModel", back_populates="components")

    def __init__(self, component, priority, component_type, error_code):
        self.component = component
        self.priority = priority
        self.component_type = component_type
        self.error_code = error_code