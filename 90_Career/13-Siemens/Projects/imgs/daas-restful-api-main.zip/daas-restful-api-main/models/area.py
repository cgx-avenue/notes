'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 13:27:10
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-01 13:37:25
'''
from db import db
import datetime


class AreaModel(db.Model):
    __tablename__ = 'area'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    area = db.Column(db.String(25), unique=True, nullable=False)
    basic_info = db.Column(db.String(200))
    timestamp = db.Column(db.DateTime)
    other = db.Column(db.String(100))

    lines = db.relationship("LineModel", back_populates="area")

    def __init__(self, area, basic_info, timestamp):
        self.area = area
        self.basic_info = basic_info
        self.timestamp = timestamp

    @classmethod
    def get_device_info(cls):
        deviceInfo = []
        areas_list = []
        areas = cls.get_area_all()
        for area in areas:
            line_list = []
            for line in area.lines:
                device_list=list(map(lambda x:x.device_num,line.devices))
                device_dict = dict(name=line.line, devices=device_list)
                line_list.append(device_dict)
            line_dict = dict(name=area.area, lines=line_list)
            areas_list.append(line_dict)
        areas_dict = dict(areas=areas_list)
        deviceInfo.append(areas_dict)
        return deviceInfo

    @classmethod
    def get_area(cls, areaName):
        area = cls.query.filter_by(area=areaName).first()
        return area

    @classmethod
    def get_area_all(cls):
        areas = AreaModel.query.all()
        return areas
