'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 12:47:15
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-08 09:57:18
'''
from db import db
from models.alarm_component import AlarmComponentModel
from models.suggestion import SuggestionModel
from models.feedback import FeedbackModel
from sqlalchemy import desc
import datetime

class AlarmModel(db.Model):
    __tablename__ = 'alarm'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    devicenum = db.Column(db.String(25),
                          db.ForeignKey('device.device_num'),
                          nullable=False)
    type = db.Column(db.String(50), nullable=True)
    alarm_type = db.Column(db.String(25), nullable=True)
    priority = db.Column(db.String(25), nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.Integer, nullable=False)
    completetime = db.Column(db.DateTime, nullable=True)
    other = db.Column(db.String(100), nullable=True,name='aspect')
    alarm_code = db.Column(db.String(10), nullable=True)

    components = db.relationship("AlarmComponentModel",
                                 back_populates="alarm",
                                 cascade="save-update, merge, delete")
    suggestions = db.relationship('SuggestionModel',
                                  back_populates='alarm',
                                  cascade="save-update, merge, delete")
    feedbacks = db.relationship('FeedbackModel',
                                back_populates='alarm',
                                cascade="save-update, merge, delete")

    device = db.relationship('DeviceModel', back_populates='alarms')

    def __init__(self, devicenum, type, priority, alarm_type, timestamp,
                 status, alarm_code):
        self.devicenum = devicenum
        self.type = type
        self.priority = priority
        self.alarm_type = alarm_type
        self.timestamp = timestamp
        self.status = status
        self.alarm_code = alarm_code

    def update_to_db(self):
        db.session.commit()

    def to_json(self):
        timestamp = datetime.datetime.strftime(self.timestamp,
                                               "%Y-%m-%d %H:%M:%S")
        component_list = list(map(lambda x: dict(pointName=x.component,
                                                 pointPriority=x.priority), self.components))
        suggestion_list = list(map(lambda x: dict(suggestion="Step{0}:{1}".format(x.queue,
                                                                                  x.suggestion)), self.suggestions))
        alarmDict = dict(alarmID=self.id,
                         areaName=self.device.line.area.area,
                         lineName=self.device.line.line,
                         deviceNum=self.devicenum,
                         priority=self.priority,
                         deviceType=self.type,
                         timestamp=timestamp,
                         status=self.status,
                         components=component_list,
                         suggestions=suggestion_list)
        return alarmDict

    @classmethod
    def get_alarm_list(cls, deviceNum, startTime, endTime, limit_size,jsonify=False):
        alarm_query = AlarmModel.query.order_by(desc(
            AlarmModel.timestamp))
        if deviceNum != None:
            alarm_query = alarm_query.filter(
                AlarmModel.devicenum == deviceNum)
        if startTime and endTime:
            alarm_query = alarm_query.filter(AlarmModel.timestamp >= startTime,
                                             AlarmModel.timestamp <= endTime)
        alarms = alarm_query.limit(limit_size).all()
        if jsonify:
            return list(map(lambda x: x.to_json(), alarms))
        else:
            return alarms

    @classmethod
    def get_alarm_or_404(cls,alarmID):
        alarm = AlarmModel.query.filter_by(id=alarmID).first_or_404()
        return alarm