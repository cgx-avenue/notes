'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 13:55:29
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-01 14:14:47
'''
from db import db
from models.area import AreaModel


class LineModel(db.Model):
    __tablename__ = 'line'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    line = db.Column(db.String(50), unique=True)
    info = db.Column(db.String(200))
    timestamp = db.Column(db.DateTime)
    other = db.Column(db.String(100))

    area_id = db.Column(db.Integer, db.ForeignKey('area.id'), nullable=False)

    devices = db.relationship("DeviceModel", back_populates="line")

    area = db.relationship('AreaModel', back_populates='lines')

    def __init__(self, line, info, timestamp):
        self.line = line
        self.info = info
        self.timestamp = timestamp

    @classmethod
    def get_line(cls, lineName):
        line = cls.query.filter_by(line=lineName).first()
        return line
