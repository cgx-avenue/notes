'''
Description: 
Version: 
Author: Yang, Shao Peng
Date: 2021-11-23 13:20:53
LastEditors: Yang, Shao Peng
LastEditTime: 2021-12-01 13:04:02
'''
from db import db
class SuggestionModel(db.Model):
    __tablename__ = 'suggestion'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    queue = db.Column(db.Integer, nullable=False)
    suggestion = db.Column(db.String(200))
    timestamp = db.Column(db.DateTime)
    other = db.Column(db.String(100))
    component = db.Column(db.String(25))
    sugCode = db.Column(db.String(10))
    requireSkill = db.Column(db.String(20))

    alarm_id = db.Column(db.Integer, db.ForeignKey('alarm.id'), nullable=False)
    alarm = db.relationship("AlarmModel", back_populates="suggestions")

    def __init__(self,component, queue,sugCode, suggestion,timestamp):
        self.component = component
        self.queue = queue
        self.suggestion = suggestion    
        self.sugCode = sugCode
        self.timestamp = timestamp

    @classmethod
    def get_suggestions_by_alarmID(cls,alarmID):
        suggestions = SuggestionModel.query.filter_by(alarm_id=alarmID).order_by(
            SuggestionModel.queue).order_by(SuggestionModel.component).all()
        return suggestions