<!--
 * @Description: 
 * @Version: 
 * @Author: Yang, Shao Peng
 * @Date: 2021-11-23 10:03:25
 * @LastEditors: Yang, Shao Peng
 * @LastEditTime: 2021-12-07 10:56:32
-->
# DaaS-restful-api

## Programming guideline
### 1 models and databse
#### 1.1 Use Flask-SQLAlchemy
    1. Use back_populates instead of backref to explictly display the relationship between models.
    2. Use plural like components showing there might be multiple instances. Use singular like component showing this is many-to-one relation.
    3. But, but, but!!! Please take care of mutual import, and import sequence between each model is really import! Otherwise will cause circular reference.

#### 1.2 PostgreSQL version
    Please use version 10.X, cause SQLAlchemy only support versions under 14.
    Note: TimescaleDB requires PostgreSQL 12, 13, or 14.
## modifications needed to better improvement
### 1. all response should not include response status code and text!!!
### 2. all response error message should be resconstructed
### 3. response error code changed from 401001 to 406(Not Acceptable)服务器无法根据客户端请求的内容特性完成请求
### 4. all limit para in request for alarms are set to 500
### 5. api 3.2.2 deviceID should be changed to devicenum
### 6. all methods in resources folder should use try...except... to return Exception http response and right http response
### 7. all query in sqlchemy should use filter_by

