import hmac
import uuid
from contextlib import contextmanager
from datetime import datetime
from flask import Flask
from flask_jwt_extended import JWTManager
from flask_sqlalchemy import SQLAlchemy as _SQLAlchemy, BaseQuery
from libs.error_code import NotFound
from sqlalchemy import Column, Integer, String, Boolean, Float, DateTime
from sqlalchemy.dialects.postgresql import UUID

app = Flask(__name__)

jwt = JWTManager(app)


class SQLAlchemy(_SQLAlchemy):
    @contextmanager
    def auto_commit(self):
        try:
            yield
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            raise e


class Query(BaseQuery):
    def filter_by(self, **kwargs):
        # if 'status' not in kwargs.keys():
        #     kwargs['status'] = 1
        return super(Query, self).filter_by(**kwargs)

    def get_or_404(self, ident):
        rv = self.get(ident)
        if not rv:
            raise NotFound()
        return rv

    def first_or_404(self):
        rv = self.first()
        if not rv:
            raise NotFound()
        return rv

    def all_or_404(self):
        rv = self.all()
        if not rv:
            raise NotFound()
        return rv


db = SQLAlchemy(query_class=Query)


class Base(db.Model):
    __abstract__ = True

    def __init__(self):
        self.create_time = datetime.now()

    def __getitem__(self, item):
        return getattr(self, item)

    def set_attrs(self, attrs_dict):
        for key, value in attrs_dict.items():
            # if hasattr(self, key) and key != 'id':
            if hasattr(self, key):
                setattr(self, key, value)

    def keys(self):
        return self.fields

    def hide(self, *keys):
        for key in keys:
            self.fields.remove(key)
        return self

    def append(self, *keys):
        for key in keys:
            self.fields.append(key)
        return self

    # 序列化class to dict
    def serialize(self):
        value = self.__dict__
        if value['_sa_instance_state']:
            del value['_sa_instance_state']
        return value


def generate_uuid():
    return str(uuid.uuid4())


def hmac_md5(s):
    key = "maintloop-password-key"
    return hmac.new(key.encode('utf-8'), s.encode('utf-8'), 'MD5').hexdigest()


class User(Base):
    id = db.Column(UUID, default=generate_uuid, primary_key=True)
    username = db.Column(db.Text, nullable=False, unique=True)
    password = db.Column(db.Text, nullable=False)
    role = db.Column(db.Text, nullable=False)
    expiration_date = db.Column(DateTime(timezone=False), nullable=True)

    def __init__(self, username, password, role, expiration_date):
        super(User, self).__init__()
        self.username = username
        self.password = hmac_md5(password)
        self.role = role
        self.expiration_date = expiration_date

    def check_password(self, _password):
        return self.password == hmac_md5(_password)


class Schema(Base):
    """ 组件 """
    __tablename__ = 'schema'
    id = db.Column(UUID, default=generate_uuid, primary_key=True)
    # 工位 + 传感器 + 安装部位(可为空)组成表名
    station = Column(String, nullable=False)  # 工位
    sensor = Column(String, nullable=False)  # 传感器
    component = Column(String, nullable=False)  # 安装部位
    description = Column(String, nullable=True)  # 描述
    protocol = Column(String, nullable=False)  # 传感器数据协议
    host = Column(String, nullable=True)  # host
    port = Column(Integer, nullable=True)  # 端口
    topic = Column(String, nullable=True)  # topic
    features = Column(String, nullable=False)  # 采集特征值以及采集协议对应的串
    enable_threshold = Column(Boolean, nullable=True, default=True)  # 开启阈值提醒
    dynamic_threshold = Column(Boolean, nullable=True, default=False)  # 自适应阈值
    algorithm = Column(String, nullable=True)  # 诊断算法
    accuracy = Column(Float, nullable=True)  # 诊断准确度
    middle_factor = Column(Float, nullable=False)  # 自动化阈值无样本时中级阈值调整基数
    high_factor = Column(Float, nullable=False)  # 自动化阈值无样本时高级阈值调整基数


class Code(Base):
    """ 故障代码 """
    __tablename__ = 'code'
    id = db.Column(UUID, default=generate_uuid, primary_key=True)
    code = Column(String, unique=True)  # 故障代码
    name = Column(String, nullable=False)  # 故障名称
    level = Column(String, nullable=False)  # 故障级别 warning, error
    description = Column(String, nullable=True)  # 描述
    suggestion = Column(String, nullable=True)  # 建议

    def __eq__(self, other):
        if isinstance(other, Code):
            return (self.code, self.name, self.level, self.description) == (
                other.code, other.name, other.level, other.description)


class Sample(Base):
    """ 故障明细 """
    __tablename__ = 'sample'
    id = db.Column(UUID, default=generate_uuid, primary_key=True)
    schema_id = Column(String, nullable=False)  # 工位id
    station = Column(String, nullable=False)  # 工位
    component = Column(String, nullable=False)  # 安装部位
    code = Column(String, nullable=False)  # 故障代码
    code_name = Column(String, nullable=True)  # 故障名称
    code_level = Column(String, nullable=True)  # 故障等级
    description = Column(String, nullable=True)  # 故障描述
    start_time = Column(DateTime(timezone=False), nullable=False)  # 开始时间
    end_time = Column(DateTime(timezone=False), nullable=False)  # 结束时间
    origin = Column(String, nullable=False)  # 来源(entry/Threshold/ML)
    state = Column(String, nullable=False)  # 状态(fault/sample/misjudgment/misjudgment_old)
    confirm_time = Column(DateTime(timezone=False), nullable=True)  # 点击确认故障的时间

    update_time = Column(DateTime(timezone=False), nullable=True)  # 新增/编辑样本的时间


class StationImage(Base):
    """ 设备图片存储 """
    __tablename__ = 'station_image'

    station_name = Column(String, primary_key=True)  # 设备名称
    image_data = Column(db.Text, nullable=False,)  # 图片存储路径
