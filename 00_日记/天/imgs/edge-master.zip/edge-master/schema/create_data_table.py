import json
import os
import joblib
import pandas as pd
import psycopg2
from log import logger
from jsonpath import jsonpath
from concurrent.futures import ThreadPoolExecutor
from config import CONFIG
from libs.result import is_not_blank
from models.model import Code

executor = ThreadPoolExecutor(max_workers=CONFIG['MAX_WORKERS'])

connection = psycopg2.connect(user=CONFIG["DATABASE"]["USER"],
                              password=CONFIG["DATABASE"]["PASSWORD"],
                              host=CONFIG["DATABASE"]["HOST"],
                              port=CONFIG["DATABASE"]["PORT"],
                              database=CONFIG["DATABASE"]["DATABASE"])


# 获取schema
def get_schemas(id):
    with connection:
        with connection.cursor():
            cursor = connection.cursor()
            sql = 'select station, sensor, component, features from schema'
            if id is not None:
                sql = sql + ' where id = ' + id
            cursor.execute(sql)
            res = cursor.fetchall()
            logger.debug('Get schemas from database')
            return [{'station': item[0], 'sensor': item[1], 'component': item[2], 'features': item[3]} for item in res]


def generate_sql(schema):
    logger.debug('Generate sql for {}'.format(schema))
    table_name = '{}_{}_{}'.format(schema['station'], schema['sensor'], schema['component'])
    features = json.loads(schema['features'])
    sql = 'create table if not exists ' + table_name + '(timestamp timestamp not null,'
    for feature in features:
        if str.lower(feature['feature']) == 'timestamp':
            continue
        else:
            sql = sql + feature['feature'] + ' double precision,'
    # 全部替换成小写
    return str.lower(sql + 'CONSTRAINT "timestamp_{}_key" UNIQUE ("timestamp") )'.format(table_name))


def create_table(sql):
    with connection:
        with connection.cursor():
            cursor = connection.cursor()
            cursor.execute(sql)


def start(id: str = None):
    try:
        schemas = get_schemas(id)
        for schema in schemas:
            sql = generate_sql(schema)
            create_table(sql)
            logger.debug('Table created for {}'.format(schema))
    except:
        logger.error('Create table error', exc_info=True)


def upload_data(table_name, table_info, table_values):
    try:
        data_to_db(table_name, table_info, table_values)
        executor.submit(fault_detect, table_name, table_info, table_values)
    except Exception as e:
        logger.error("add to thread pool error: ", exc_info=e)


def data_to_db(table_name, table_info, table_values):
    if len(table_values) == 0:
        return
    feature = jsonpath(table_info, "$..feature")
    with connection:
        with connection.cursor():
            cursor = connection.cursor()
            try:
                # 准备sql前半部分
                sql = "insert into " + str.lower(table_name) + " ("
                for field in feature:
                    sql = sql + str.lower(field) + ","
                sql = sql[:-1] + ") values "
                insert_values = ""
                for value in table_values:
                    sb = ""
                    for field in feature:
                        sb += "'{}',".format(value.get(str.lower(field)))
                    insert_values = insert_values + "(" + sb[:-1] + "),"
                sql = sql + insert_values[:-1] + ' ON CONFLICT ("timestamp") DO NOTHING'
                # 插入数据到表
                cursor.execute(sql)
                logger.info("batch insert sql {}".format(sql))
                logger.debug("insert data {}, value {}".format(table_name, table_values))
            except Exception as e:
                repr(e)
                logger.error("batch insert error, table: {}, value: {} : ".format(table_name, table_values), exc_info=e)


def fault_detect(table_name, table_info, values):
    if not table_info.get('enable_threshold'):
        return

    thresholds = {}

    for feature in table_info.get('features'):
        if all(is_not_blank(feature, k) for k in ['middle', 'middle_code', 'high', 'high_code']):
            lower_feature = str.lower(feature['feature'])
            thresholds[lower_feature] = {
                'middle': feature['middle'],
                'middle_code': feature['middle_code'],
                'high': feature['high'],
                'high_code': feature['high_code'],
                'threshold_buffer': 0,
                'threshold_starttime': 0,
                'threshold_endtime': 0,
                'threshold_code': '',
                'ml_buffer': 0,
                'ml_starttime': 0,
                'ml_endtime': 0,
                'ml_code': '',
            }

    if not thresholds:
        return

    code_map = get_code()
    path = './pkl/{}.pkl'.format(table_name)
    ml_solution = os.path.exists(path)

    for feature, threshold in thresholds.items():
        threshold_value = {}
        ml_value = {}
        for value in values:
            feature_data = float(value[feature]) if isinstance(value[feature], str) else value[feature]
            # 阈值判断
            if feature_data > float(threshold['high']):
                if threshold['threshold_buffer'] == 0:
                    threshold['threshold_starttime'] = value['timestamp']

                threshold['threshold_buffer'] += 1
                threshold['threshold_code'] = code_map[threshold['high_code']]

            elif feature_data > float(threshold['middle']):
                if threshold['threshold_buffer'] == 0:
                    threshold['threshold_starttime'] = value['timestamp']

                threshold['threshold_buffer'] += 1
                if threshold['threshold_code'] == '':
                    threshold['threshold_code'] = code_map[threshold['middle_code']]
            else:
                if threshold['threshold_buffer'] >= CONFIG['BUFFER_SIZE']:
                    threshold['threshold_endtime'] = value['timestamp']

                    threshold_value = {
                        "schema_id": table_info.get('id'),
                        "station": table_info.get('station'),
                        "component": table_info.get('component'),
                        "code": threshold['threshold_code']['code'],
                        "code_name": threshold['threshold_code']['name'],
                        "code_level": threshold['threshold_code']['level'],
                        "description": threshold['threshold_code']['description'],
                        "start_time": threshold['threshold_starttime'],
                        "end_time": threshold['threshold_endtime'],
                        "origin": 'Threshold',
                    }
                    process_sql(threshold_value)
                threshold_value.clear()
                threshold['threshold_buffer'] = 0
                threshold['threshold_code'] = ''


            # 模型预测, 当数据第一次导入，没有模型
            if ml_solution and feature == 'vibrms':
                pred_labels = predict_data(value, path)
                if pred_labels[0][:2] == '12':
                    if threshold['ml_buffer'] == 0:
                        threshold['ml_starttime'] = value['timestamp']
                    threshold['ml_buffer'] += 1
                    threshold['ml_code'] = code_map[threshold['high_code']]

                elif pred_labels[0][:2] == '11':
                    if threshold['ml_buffer'] == 0:
                        threshold['ml_starttime'] = value['timestamp']
                    threshold['ml_buffer'] += 1
                    if threshold['ml_code'] == '':
                        threshold['ml_code'] = code_map[threshold['middle_code']]
                else:
                    if threshold['ml_buffer'] >= CONFIG['BUFFER_SIZE']:
                        threshold['ml_endtime'] = value['timestamp']

                        ml_value = {
                            "schema_id": table_info.get('id'),
                            "station": table_info.get('station'),
                            "component": table_info.get('component'),
                            "code": threshold['ml_code']["code"],
                            "code_name": threshold['ml_code']['name'],
                            "code_level": threshold['ml_code']['level'],
                            "description": threshold['ml_code']['description'],
                            "start_time": threshold['ml_starttime'],
                            "end_time": threshold['ml_endtime'],
                            "origin": 'ML',
                        }
                        process_sql(ml_value)
                    ml_value.clear()
                    threshold['ml_buffer'] = 0
                    threshold['ml_code'] = ''

        if threshold_value.get('end_time'):
            process_sql(threshold_value)
        if ml_value.get('end_time'):
            process_sql(ml_value)



def predict_data(data, path):
    # 预测
    df = pd.DataFrame([data])
    X = df.drop(['timestamp'], axis=1).to_numpy()
    clf = joblib.load(path)
    pred_labels = clf.predict(X)
    return pred_labels


def process_sql(table_value):

    # 查询sample中同类记录的最近的一条，进行时间比对
    query_sql = "select id,start_time,end_time from sample where schema_id='{}' and code='{}' and origin='{}' and state='fault' " \
                "order by end_time desc limit 1".format(table_value['schema_id'], table_value['code'],
                                                        table_value['origin'])

    with connection:
        with connection.cursor():
            cursor = connection.cursor()
            cursor.execute(query_sql)
            result = cursor.fetchone()
            if result and table_value['start_time'].timestamp() - result[2].timestamp() <= CONFIG['BUFFER_TIMEOUT']:

                sql = "update sample set end_time='{}' where schema_id='{}' and code='{}' and start_time='{}' and origin='{}' and state='fault' ".format(
                    table_value['end_time'], table_value['schema_id'], table_value['code'], result[1],
                    table_value['origin']
                )

            else:
                sql = 'INSERT INTO sample ("id", "start_time", "end_time", "state", "schema_id", "station", "component", "code", ' \
                      '"code_name", "code_level", "description", "origin") VALUES ' \
                      "(uuid_generate_v4(),'{}','{}','fault','{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}')".format(
                    table_value['start_time'], table_value['end_time'],
                    table_value['schema_id'], table_value['station'], table_value['component'], table_value['code'],
                    table_value['code_name'], table_value['code_level'], table_value['description'],
                    table_value['origin'])

            cursor.execute(sql)


def get_code():
    data = Code.query.filter().order_by(Code.code).all()
    return {code.code: code.serialize() for code in data}

# if __name__ == '__main__':
#     start()
