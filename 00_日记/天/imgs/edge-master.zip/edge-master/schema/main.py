from flask import Flask
from models.model import db
from schedule.scheduler_factory import scheduler
from api import login, schema, fault, sample, code, report, health
from flask_cors import CORS
from config import CONFIG
from log import logger
from flask_jwt_extended import JWTManager
from api.login import save
from api.code import import_code

# import multiprocessing


class Config(object):
    """ db配置"""
    SQLALCHEMY_DATABASE_URI = "postgresql+psycopg2://{}:{}@{}:{}/{}?client_encoding=utf8".format(
        CONFIG['DATABASE']['USER'],
        CONFIG['DATABASE']['PASSWORD'],
        CONFIG['DATABASE']['HOST'],
        CONFIG['DATABASE']['PORT'],
        CONFIG['DATABASE']['DATABASE'],
    )
    # 设置是否跟踪数据库的修改情况，一般不跟踪
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # 数据库操作时是否显示原始SQL语句，一般都是打开的，因为我们后台要日志
    SQLALCHEMY_ECHO = True
    # 开启定时任务
    SCHEDULER_API_ENABLED = True


app = Flask(__name__)
localport = 8765
# Setup the Jwt secret and token expires in 12h
app.config["JWT_SECRET_KEY"] = "maintloop-jwt-secret"
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = 3600 * 12
jwt = JWTManager(app)


def activate_app():
    app.config.from_object(Config)
    CORS(app, supports_credentials=True)
    db.init_app(app)

    scheduler.init_app(app)
    import schedule.task
    scheduler.start()

    app.register_blueprint(login.bp, url_prefix='/login')
    app.register_blueprint(schema.bp, url_prefix='/schemas')
    app.register_blueprint(fault.bp, url_prefix='/faults')
    app.register_blueprint(sample.bp, url_prefix='/samples')
    app.register_blueprint(code.bp, url_prefix='/codes')
    app.register_blueprint(report.bp, url_prefix='/reports')
    app.register_blueprint(health.bp, url_prefix='/health')

    app.app_context().push()  # 在application外使用sqlachemy


def run_app():
    app.run(host="0.0.0.0", port=localport)


if __name__ == '__main__':
    # multiprocessing.freeze_support()
    logger.info('DaaS Web Config service started')
    # 启动应用，监听api接口
    activate_app()
    # 创建所有表
    db.create_all()
    # 创建admin用户
    save()
    # 导入code表数据
    import_code()
    # 开始监听
    run_app()
