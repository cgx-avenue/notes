import copy
import json
import os
from datetime import timedelta, datetime

import numpy as np
import pandas as pd
from api.report import get_vib_data, get_stats, get_vib_data_summary, get_threshold_count
from config import CONFIG
from dateutil.relativedelta import relativedelta
from log import logger
from models.model import db, Schema, Sample
from schedule.scheduler_factory import scheduler
from sklearn.cluster import KMeans
from yellowbrick.cluster import KElbowVisualizer


@scheduler.task('cron', hour=0, minute=5, id='health_score_cache_job')
def health_score_cache_job():
    with scheduler.app.app_context():
        data = Schema.query.order_by(Schema.station, Schema.sensor, Schema.component).all()
        # months = get_months(2)
        first_start, first_end = get_previous_days(30)
        second_start, _ = get_previous_days(60)
        result = {}
        for schema in data:
            table_name = str.lower('{}_{}_{}'.format(schema['station'], schema['sensor'], schema['component']))
            last_60 = get_vib_data_percentile(table_name, second_start, first_start)
            last_30 = get_vib_data_percentile(table_name, first_start, first_end)
            health_score = 1
            if last_30 == 0:
                health_score = 0
            elif last_60 == 0:
                # 计算当月分布中最高区间的比例
                health_score = 1 - distributed_score(table_name)
            elif last_30 > last_60:
                health_score = 1 - (last_30 - last_60) / last_60
            result[table_name] = round(health_score, 4)
        logger.info('health_score_cache data is {}'.format(result))
        cache_data('health_score_cache', result)


@scheduler.task('cron', hour=0, minute=15, id='health_correlation_cache_job')
def health_correlation_cache_job():
    with scheduler.app.app_context():
        data = Schema.query.order_by(Schema.station, Schema.sensor, Schema.component).all()
        # 计算前7天的数据
        start, end = get_previous_days(7)
        result = {}
        for schema in data:
            table_name = str.lower('{}_{}_{}'.format(schema['station'], schema['sensor'], schema['component']))
            # features = jsonpath(json.loads(schema.features), "$..feature")
            features = json.loads(schema.features)
            columns_without_timestamp = [feature['feature'] for feature in features if
                                         feature['feature'].lower() != 'timestamp']
            df = get_corr_data(table_name, start, end, ','.join(columns_without_timestamp))
            result[table_name] = df.to_dict()
        logger.info('health_correlation_cache data is {}'.format(result))
        cache_data('health_correlation_cache', result)


@scheduler.task('cron', hour=0, minute=40, id='health_critical_cache_job')
def health_critical_cache_job():
    with scheduler.app.app_context():
        data = Schema.query.order_by(Schema.station, Schema.sensor, Schema.component).all()
        # 计算前30天的数据
        start, end = get_previous_days(30)
        result = {}
        for schema in data:
            table_name = str.lower('{}_{}_{}'.format(schema['station'], schema['sensor'], schema['component']))
            vib_array = get_vib_array_data(table_name, start, end)
            if vib_array.size == 0:
                result[table_name] = 0
            else:
                vib_array = vib_array.reshape(-1, 1)
                model = KMeans(random_state=4, n_init='auto')
                visualizer = KElbowVisualizer(model, k=(2, 10))
                visualizer.fit(vib_array)  # Fit the data to the visualizer
                k = visualizer.elbow_value_

                kmeans = KMeans(n_clusters=k, n_init='auto')
                kmeans.fit(vib_array)  # 训练模型
                # 获取聚类中心和标签
                centers = pd.DataFrame(kmeans.cluster_centers_).sort_values(0)
                borders = centers.rolling(2).mean()
                borders.rename(columns={0: 'val'}, inplace=True)
                critical_val = round(borders.iloc[1]["val"], 5)
                result[table_name] = critical_val
        logger.info('health_critical_cache data is {}'.format(result))
        cache_data('health_critical_cache', result)


@scheduler.task('cron', hour=1, minute=5, id='health_distributed_cache_job')
def health_distributed_cache_job():
    with scheduler.app.app_context():
        data = Schema.query.order_by(Schema.station, Schema.sensor, Schema.component).all()
        # 计算前7天的数据
        start, end = get_previous_days(7)
        result = {}
        for schema in data:
            table_name = str.lower('{}_{}_{}'.format(schema['station'], schema['sensor'], schema['component']))
            dimensions = ['interval', table_name]
            source = {}
            frame = get_vib_data(table_name, start, end)
            frame = frame.where(frame.notnull(), None)
            # 柱状分布图8个间隔
            if frame.empty:
                bins = np.linspace(0, 8, num=9)
            else:
                bins = np.linspace(frame['vibrms'].min(), frame['vibrms'].max(), num=9)
            # 分析振动分布区间
            quartiles = pd.cut(frame['vibrms'], bins)
            grouped = frame['vibrms'].groupby(quartiles, observed=False)
            counts = grouped.apply(get_stats).unstack()
            # 整理报表数据结构
            for index, row in counts.iterrows():
                if str(index) not in source:
                    source[str(index)] = {'interval': str(index)}
                source[str(index)][table_name] = int(row['count'])

            result[table_name] = {'dimensions': dimensions, 'source': list(source.values()), 'total': len(frame)}
        logger.info('health_distributed_cache data is {}'.format(result))
        cache_data('health_distributed_cache', result)


@scheduler.task('cron', hour=1, minute=25, id='health_compare_cache_job')
def health_compare_cache_job():
    with scheduler.app.app_context():
        data = Schema.query.order_by(Schema.station, Schema.sensor, Schema.component).all()
        cycles = [{'cycle': 7}, {'cycle': 30}]
        result = {}
        for schema in data:
            table_name = str.lower('{}_{}_{}'.format(schema['station'], schema['sensor'], schema['component']))
            cycle_data = []
            for item in cycles:
                start, end = get_previous_days(item['cycle'])
                frame = get_vib_data_compare(table_name, start, end)
                frame = frame.where(frame.notnull(), 0)
                item['max'] = round(float(frame.at[0, 'max']), 3)
                item['min'] = round(float(frame.at[0, 'min']), 3)
                item['mean'] = round(float(frame.at[0, 'mean']), 3)
                item['median'] = round(float(frame.at[0, 'median']), 3)
                item['std'] = round(float(frame.at[0, 'std']), 3)
                item['q1'] = round(float(frame.at[0, 'q1']), 3)
                item['q3'] = round(float(frame.at[0, 'q3']), 3)
                new_item = copy.deepcopy(item)
                cycle_data.append(new_item)
            result[table_name] = cycle_data
        logger.info('health_compare_cache data is {}'.format(result))
        cache_data('health_compare_cache', result)


@scheduler.task('cron', hour=1, minute=40, id='health_trend_cache_job')
def health_trend_cache_job():
    with scheduler.app.app_context():
        data = Schema.query.order_by(Schema.station, Schema.sensor, Schema.component).all()
        months = get_months(3)
        result = {}
        for schema in data:
            table_name = str.lower('{}_{}_{}'.format(schema['station'], schema['sensor'], schema['component']))
            features = json.loads(schema['features'])
            rms_feature = next((f for f in features if f['feature'].lower() == 'vibrms'), {})
            threshold = rms_feature.get('high')
            totals = []
            maxs = []
            mins = []
            means = []
            medians = []
            stds = []
            q1s = []
            q3s = []
            thresholds = []

            for month in months:
                frame = get_vib_data_summary(table_name, month)
                frame = frame.where(frame.notnull(), 0)
                totals.append(round(float(frame.at[0, 'total']), 3))
                maxs.append(round(float(frame.at[0, 'max']), 3))
                mins.append(round(float(frame.at[0, 'min']), 3))
                means.append(round(float(frame.at[0, 'mean']), 3))
                medians.append(round(float(frame.at[0, 'median']), 3))
                stds.append(round(float(frame.at[0, 'std']), 3))
                q1s.append(round(float(frame.at[0, 'q1']), 3))
                q3s.append(round(float(frame.at[0, 'q3']), 3))
                # 没有设置阈值不统计超过阈值数量
                if threshold is not None:
                    frame2 = get_threshold_count(table_name, month, threshold)
                    frame2 = frame2.where(frame2.notnull(), 0)
                    thresholds.append(int(frame2.at[0, 'threshold']))
                else:
                    thresholds.append(False)

            result[table_name] = {
                'totals': totals,
                'maxs': maxs,
                'mins': mins,
                'means': means,
                'medians': medians,
                'stds': stds,
                'q1s': q1s,
                'q3s': q3s,
                'thresholds': thresholds
            }
        logger.info('health_trend_cache data is {}'.format(result))
        cache_data('health_trend_cache', result)


@scheduler.task('cron', hour=2, id='dynamic_threshold_job')
def dynamic_threshold_job():
    with scheduler.app.app_context():
        schemas = Schema.query.filter_by(dynamic_threshold=True).all()
        if len(schemas) == 0:
            return
        for schema in schemas:
            table_name = str.lower('{}_{}_{}'.format(schema.station, schema.sensor, schema.component))
            # 如果当前工位有确认的报警信息，退出
            samples = Sample.query.filter_by(schema_id=schema.id, state='fault').all()
            if len(samples) > 0:
                logger.error('Station: {}, have {} samples not marked'.format(schema.id, len(samples)))
                return
            # 如有误报，根据步长调整系数
            misjudgment_samples = Sample.query.filter_by(schema_id=schema.id, state='misjudgment', origin="Threshold") \
                .filter(Sample.code != '1000').all()
            if len(misjudgment_samples) > 0:
                schema.middle_factor += CONFIG['MISJUDGMENT_STEP']
                schema.high_factor += CONFIG['MISJUDGMENT_STEP']

            samples = Sample.query.filter_by(schema_id=schema.id, state='sample').filter(Sample.code != '1000').all()
            # 如果有已标记的故障样本, 取样本数据、最近一周数据取中间值
            if len(samples) > 0:
                normal_time_filters = ''
                fault_time_filters = ' and ('
                for sample in samples:
                    # start_time = (sample.start_time + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
                    # end_time = (sample.end_time + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')

                    start_time = sample.start_time.strftime('%Y-%m-%d %H:%M:%S')
                    end_time = sample.end_time.strftime('%Y-%m-%d %H:%M:%S')

                    normal_time_filters += " and (timestamp < to_timestamp('" + start_time + "', 'YYYY-MM-DD HH24:MI:SS') "
                    normal_time_filters += " or timestamp > to_timestamp('" + end_time + "', 'YYYY-MM-DD HH24:MI:SS')) "
                    fault_time_filters += " (timestamp >= to_timestamp('" + start_time + "', 'YYYY-MM-DD HH24:MI:SS') "
                    fault_time_filters += " and timestamp <= to_timestamp('" + end_time + "', 'YYYY-MM-DD HH24:MI:SS')) or "
                fault_time_filters = fault_time_filters[0:-3] + " ) "
                # 取最近一周故障样本时间范围之外的数据最大值
                normal_max = get_max(db.engine, table_name, normal_time_filters)
                # 取最近一周故障样本时间范围内的数据最大值
                fault_max = get_max(db.engine, table_name, fault_time_filters)
                if normal_max > fault_max:
                    logger.error('Station: {}, fault max lower normal max'.format(schema.id))
                    return
                middle = normal_max + (fault_max - normal_max) * 0.3
                high = normal_max + (fault_max - normal_max) * 0.5
                update_threshold(schema, middle, high)
            # 无样本/无故障，获取最近一周数据，取一周内数据的中位数+3倍方差+30%中级/50%高级
            else:
                ucl = get_means_3std(db.engine, table_name)
                if ucl and ucl > 0:
                    middle = ucl * (schema.middle_factor + 1)
                    high = ucl * (schema.high_factor + 1)
                    update_threshold(schema, middle, high)
                    # 将misjudgment数据状态改为misjudgment_old
                    update_misjudgment(misjudgment_samples)


# 取一周内数据的中位数+3倍方差
def get_means_3std(engine, table_name):
    health_critical_cache = {}
    json_path = './cache/health_critical_cache.json'
    if os.path.isfile(json_path):
        with open(json_path, 'r', encoding='utf-8') as json_file:
            health_critical_cache = json.load(json_file)
    threshold = health_critical_cache.get(table_name, 0)

    sql = """
            SELECT 
                percentile_disc(0.5) within group (order by vibrms) as median,
                stddev(vibrms) as std 
            FROM {table_name}
            WHERE timestamp > (now() - interval '1 week')  AND vibrms > %s
                  """.format(table_name=table_name)
    df = pd.read_sql_query(sql, con=engine, params=(threshold,))

    df = df.where(df.notnull(), 0)
    median = round(float(df.at[0, 'median']), 4)
    std = round(float(df.at[0, 'std']), 4)
    ucl = median + 3 * std

    return ucl


def get_max(engine, table_name, time_filters=None):
    sql = " select max(vibrms) " + \
          " from " + table_name + \
          " where timestamp > (now() - interval '1 week') "
    if time_filters:
        sql += time_filters
    return pd.read_sql_query(sql, con=engine).iloc[0, 0]


def update_misjudgment(misjudgment_samples):
    id_list = [sample["id"] for sample in misjudgment_samples]
    sample_list = Sample.query.filter(Sample.id.in_(id_list)).all()
    for sample in sample_list:
        sample.state = "misjudgment_old"
    db.session.commit()


def update_threshold(data, middle, high):
    schema = Schema.query.filter_by(id=data.id).first_or_404()
    string_to_list(schema)
    for feature in schema.features:
        if str.lower(feature['feature']) == 'vibrms':
            feature['middle'] = round(middle, 3)
            if not feature['middle_code']:
                feature['middle_code'] = '1100'
            feature['high'] = round(high, 3)
            if not feature['high_code']:
                feature['high_code'] = '1200'
    schema.features = json.dumps(schema.features)
    schema.middle_factor = data.middle_factor
    schema.high_factor = data.high_factor
    db.session.commit()
    logger.info('Update threshold, station: {}, middle: {}, high: {}'.format(id, middle, high))


def string_to_list(data):
    if isinstance(data, list):
        for item in data:
            item.features = json.loads(item.features)
    else:
        data.features = json.loads(data.features)


def get_vib_data_std(table_name, start_time, end_time):
    sql = """
            SELECT 
                stddev(vibrms) AS std 
            FROM {table_name} 
            WHERE timestamp >= %s AND timestamp <= %s
        """.format(table_name=table_name)

    frame = pd.read_sql_query(sql, con=db.engine, params=(start_time, end_time))
    std = frame.at[0, 'std']
    if not std:
        return 0
    return round(float(std), 6)


def get_vib_data_percentile(table_name, start_time, end_time):

    sql = """
            WITH ordered_data AS (
                SELECT percentile_disc(ARRAY[0.25, 0.75]) 
                WITHIN GROUP (ORDER BY vibrms) as percentiles
                FROM {table_name} 
                WHERE timestamp >= %s AND timestamp <= %s
            )
            SELECT (percentiles[2] - percentiles[1]) as iqr
            FROM ordered_data
        """.format(table_name=table_name)

    frame = pd.read_sql_query(sql, con=db.engine, params=(start_time, end_time))
    percentile_iqr = frame.at[0, 'iqr']
    if not percentile_iqr:
        return 0
    return round(float(percentile_iqr), 6)


def distributed_score(table_name):
    # 获取当前日期
    now = datetime.now()
    # 获取当月的第一天的0时0分0秒
    start = now.replace(day=1, hour=0, minute=0, second=0)
    # 获取下个月的第一天的0时0分0秒
    end = (start + relativedelta(months=1)).strftime('%Y-%m-%d %H:%M:%S')

    frame = get_vib_data(table_name, start.strftime('%Y-%m-%d %H:%M:%S'), end)
    frame = frame.where(frame.notnull(), None)
    # 拆分8个区间
    intervals = np.linspace(frame['vibrms'].min(), frame['vibrms'].max(), num=9)
    max_interval = intervals[-2:]  # 取最后两个值作为最大区间的边界
    # 获取在最大区间内的值
    values_in_max_interval = frame[(frame['vibrms'] >= max_interval[0]) & (frame['vibrms'] < max_interval[1])]
    # 计算在最大区间内的分布比例
    return round(len(values_in_max_interval) / len(frame), 6)


def get_months(num):
    now = datetime.now()
    # 获取含当前月在内的最近num个月
    months = [(now + relativedelta(months=-i)).strftime('%Y-%m') for i in range(num - 1, -1, -1)]
    return months


def get_previous_days(days):
    today = datetime.now()
    # 前一天的最后一秒
    yesterday_end = (datetime(today.year, today.month, today.day) - timedelta(seconds=1)).strftime('%Y-%m-%d %H:%M:%S')
    # n天前的开始时间
    days_ago_start = (datetime(today.year, today.month, today.day) - timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')

    return days_ago_start, yesterday_end


def get_vib_data_compare(table_name, start_time, end_time):
    sql = """
            SELECT 
                count(vibrms) AS total, 
                max(vibrms) AS max, 
                min(vibrms) AS min, 
                avg(vibrms) AS mean, 
                stddev(vibrms) AS std, 
                percentile_disc(0.25) WITHIN GROUP (ORDER BY vibrms) AS q1, 
                percentile_disc(0.5) WITHIN GROUP (ORDER BY vibrms) AS median, 
                percentile_disc(0.75) WITHIN GROUP (ORDER BY vibrms) AS q3 
            FROM {table_name} 
            WHERE timestamp >= %s AND timestamp <= %s
        """.format(table_name=table_name)

    return pd.read_sql_query(sql, con=db.engine, params=(start_time, end_time))


def cache_data(file_name, result):
    json_path = './cache/{}.json'.format(file_name)
    with open(json_path, 'w', encoding='utf-8') as json_file:
        json.dump(result, json_file, ensure_ascii=False, indent=4)


def get_corr_data(table_name, start_time, end_time, select_columns):
    sql = """
             SELECT {select_columns}
             FROM {table_name} WHERE timestamp >= %s AND timestamp <= %s ORDER BY timestamp
          """.format(select_columns=select_columns, table_name=table_name)

    frame = pd.read_sql_query(sql, con=db.engine, params=(start_time, end_time)).corr()
    # 处理相关性为 NaN 的情况，如果该列为常数列（如全为 0），将相关性设置为 0
    # for col in frame.columns:
    #     if df[col].std() == 0:  # 如果该列的标准差为 0，表示它是常数列
    #         frame[col] = 0  # 将相关性矩阵中该列的相关性设置为 0
    return frame.replace({np.nan: None})


def get_vib_array_data(table_name, start_time, end_time, column='vibrms'):
    sql = """
    SELECT {column} 
    FROM {table_name} 
    WHERE timestamp >= %s AND timestamp <= %s 
    ORDER BY timestamp
    """.format(column=column, table_name=table_name)
    df = pd.read_sql_query(sql, con=db.engine, params=(start_time, end_time))
    if df.empty:
        return np.array([])  # 返回空列表

    # 转换为列表并返回
    return df[column].to_numpy()
