import pandas as pd
import numpy as np
from collections import Counter
from sklearn import tree, svm, naive_bayes, neighbors, preprocessing
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.ensemble import BaggingClassifier, AdaBoostClassifier, RandomForestClassifier, GradientBoostingClassifier
import joblib
from datetime import timedelta
from scipy.signal import find_peaks_cwt, peak_widths

CLF_OPTIONS = [
    {'value': 'svm', 'label': '支持向量机'},
    {'value': 'decision_tree', 'label': '决策树'},
    {'value': 'naive_gaussian', 'label': '高斯朴素贝叶斯'},
    {'value': 'naive_mul', 'label': '朴素贝叶斯'},
    {'value': 'K_neighbor', 'label': 'K近邻法'},
    {'value': 'bagging_knn', 'label': '集成K近邻法'},
    {'value': 'bagging_tree', 'label': '集成决策树'},
    {'value': 'random_forest', 'label': '随机森林'},
    {'value': 'adaboost', 'label': '自适应增强'},
    {'value': 'gradient_boost', 'label': '梯度提升'},
]

CLFS = {
    'svm': svm.SVC(),
    'decision_tree': tree.DecisionTreeClassifier(),
    'naive_gaussian': naive_bayes.GaussianNB(),
    'naive_mul': naive_bayes.MultinomialNB(),
    'K_neighbor': neighbors.KNeighborsClassifier(),
    'bagging_knn': BaggingClassifier(neighbors.KNeighborsClassifier(), max_samples=0.5, max_features=0.5),
    'bagging_tree': BaggingClassifier(tree.DecisionTreeClassifier(), max_samples=0.5, max_features=0.5),
    'random_forest': RandomForestClassifier(n_estimators=50),
    'adaboost': AdaBoostClassifier(n_estimators=50),
    'gradient_boost': GradientBoostingClassifier(n_estimators=50, learning_rate=1.0, max_depth=1, random_state=0)
}


def diagnose(engine, table_name, features, samples, algorithm):
    select_columns = ''
    for feature in features:
        select_columns = select_columns + ', ' + feature
    df = pd.DataFrame()
    for sample in samples:
        code = sample.code
        # 时区修改
        # start_time = (sample.start_time + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
        # end_time = (sample.end_time + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
        start_time = sample.start_time.strftime('%Y-%m-%d %H:%M:%S')
        end_time = sample.end_time.strftime('%Y-%m-%d %H:%M:%S')
        data = get_vib_data(engine, table_name, start_time, end_time, select_columns)
        del data['timestamp']
        data['code'] = code
        df = pd.concat([df, data], axis=0, ignore_index=True)
        # mark_static(data)
        #
        # moving = False
        # item = pd.Series([[] for _ in range(len(features))], index=features)
        # for index, row in data.iterrows():
        #     if row['move'] and not moving:
        #         item = pd.Series([[] for _ in range(len(features))], index=features)
        #         moving = True
        #     if not row['move'] and moving:
        #         item['code'] = code
        #         df = df.append(item, ignore_index=True)
        #         moving = False
        #     if row['move']:
        #         for feature in features:
        #             item[feature].append(row[feature])

    # # 三维数组转二维数组
    # for index, row in df.iterrows():
    #     # 获取vibrms最高值index，获取前5后5条数据
    #     rms_list = row['vibrms']
    #     start, end = 0, 0
    #     max_index = rms_list.index(max(rms_list))
    #     if max_index < 5:
    #         start, end = 0, 10
    #     elif max_index > len(rms_list) - 5:
    #         start, end = len(rms_list) - 10, len(rms_list)
    #     else:
    #         start, end = max_index - 5, max_index + 5
    #     for feature in features:
    #         row[feature] = row[feature][start:end]

    # y = df['code'].to_numpy()
    # del df['code']
    # X = df.to_numpy()
    # X_shape = X.shape
    # X = np.array(X.tolist())
    # X = X.reshape([X_shape[0], X_shape[1] * 10])

    y = df['code'].to_numpy()
    del df['code']
    X = df.to_numpy()

    # neg_indices = np.where(X < 0)
    # neg_values = X[neg_indices]
    # print(neg_indices, neg_values)

    if algorithm == 'naive_mul':
        min_max_scaler = preprocessing.MinMaxScaler()
        X = min_max_scaler.fit_transform(X)

    # 切分训练/测试数据
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)

    clf = CLFS[algorithm]  # 引入训练方法
    clf.fit(X_train, y_train)  # 进行填充测试数据进行训练
    # 保存模型文件
    joblib.dump(clf, './pkl/{}.pkl'.format(table_name))
    # 预测准确度，保留4位小数
    # clf2 = joblib.load('{}.pkl'.format(table_name))
    pred_labels = clf.predict(X_test)
    accuracy = accuracy_score(y_test, pred_labels)
    return round(accuracy, 4)


def get_vib_data(engine, table_name, start_time, end_time, select_columns=', vibrms'):
    sql = """
             SELECT to_char(timestamp, 'YYYY-MM-DD HH24:MI:SS') AS timestamp  {select_columns}
             FROM {table_name} WHERE timestamp >= %s AND timestamp <= %s ORDER BY timestamp
          """.format(select_columns=select_columns, table_name=table_name)
    return pd.read_sql_query(sql, con=engine, params=(start_time, end_time))


def sliding_window(data):
    data['move'] = False
    window_size = 15
    peaks = find_peaks_cwt(vector=data['vibrms'].to_numpy(), widths=[window_size], window_size=window_size)
    widths = peak_widths(data['vibrms'].to_numpy(), peaks, rel_height=1)
    for i in range(len(peaks)):
        peak = peaks[i]
        width = widths[0][i]
        start = int(peak - window_size / 2)
        end = int(peak + window_size / 2)
        if start < 0:
            continue
        data['move'][start:end] = True


def mark_static(data):
    # 如果最大值最小值差距在10%，说明一直是静态
    rms_max = data['vibrms'].max()
    rms_min = data['vibrms'].min()
    if abs(rms_max - rms_min) / rms_min < 0.1:
        data['move'] = False
        return
    # 计算静止状态阈值
    counter = Counter(data['vibrms'].tolist())
    threshold = counter.most_common()[0][0]

    start = -1
    end = -1
    data['move'] = True
    # 遍历数据，如果当前数值在静态阈值5%范围内，认为是静态
    for i in range(len(data)):
        rms = data['vibrms'][i]
        # 如果还没开始
        if start < 0:
            if is_static(rms, threshold):
                start = i
            else:
                continue
        # 正在积累中
        else:
            if is_static(rms, threshold):
                # 最后一组
                if i == (len(data) - 1) and start > 0:
                    data['move'][start:i + 1] = False
                else:
                    continue
            else:
                data['move'][start:i] = False
                start = -1

    # 移除静止状态的零星运动
    move_count = 0
    for i in range(len(data)):
        if data['move'][i]:
            move_count += 1
        else:
            if move_count < 15:
                for j in range(move_count):
                    data['move'][i - j - 1] = False
            move_count = 0


def is_static(rms, threshold):
    return abs(rms - threshold) < rms * 0.1


def mark_movement(data):
    # 如果最大值最小值差距在10%，说明一直是静态
    rms_max = data['vibrms'].max()
    rms_min = data['vibrms'].min()
    if abs(rms_max - rms_min) / rms_min < 0.1:
        data['move'] = False
        return
    # 计算静止状态阈值
    counter = Counter(data['vibrms'].tolist())
    static_threshold = 0
    static_count = 0
    static_list = []
    for item in counter.most_common():
        rms = item[0]
        count = item[1]

        static_count += count
        static_list.append(rms)
        std = np.array(static_list).std()
        if std > 5 or static_count / len(data) > 0.7:
            break

        if rms > static_threshold:
            static_threshold = rms

    # 高于该值为机械运动状态RMS
    data['move'] = data['vibrms'] > static_threshold

    # 遍历，过滤掉静止状态高值
    for i in range(2, len(data) - 2):
        if not data['move'][i]:
            pass
        if data['move'][i - 2] or data['move'][i - 1] or data['move'][i + 1] or data['move'][i + 2]:
            continue
        else:
            data['move'][i] = False

    # 移除运动状态的零星静止
    static_count = 0
    for i in range(len(data)):
        if not data['move'][i]:
            static_count += 1
        else:
            if static_count < 8:
                for j in range(static_count):
                    data['move'][i - j - 1] = True
            static_count = 0
    # 移除静止状态的零星运动
    move_count = 0
    for i in range(len(data)):
        if data['move'][i]:
            move_count += 1
        else:
            if move_count < 15:
                for j in range(move_count):
                    data['move'][i - j - 1] = False
            move_count = 0
