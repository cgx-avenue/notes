import json

from flask import Blueprint, request
from models.model import db, Code
from libs.result import is_blank, is_not_blank, success, failure, result
from flask_jwt_extended import jwt_required
from sqlalchemy.exc import IntegrityError
from libs.result import success_saved, success_removed
from models.model import Sample

bp = Blueprint('code', __name__)


@bp.route('', methods=['GET'])
@jwt_required
def get_all():
    code = request.args.get('code')
    if code is not None and code:
        data = Code.query.filter_by(code=code).order_by(Code.code).all()
    else:
        data = Code.query.filter().order_by(Code.code).all()
    return success(data=data)


@bp.route('/<code>', methods=['GET'])
@jwt_required
def get_by_code(code):
    data = Code.query.filter_by(code=code).first()
    return success(data=data)


@bp.route('', methods=['POST'])
@jwt_required
def save():
    body = request.json
    data = Code()
    data.set_attrs(body)
    try:
        # 有id更新记录, 无id新建
        if 'id' in body and body['id'] is not None:
            code = Code.query.get(body['id'])
            # 重写eq方法后，比较除了suggestion属性外其余属性是否相同
            if data != code:
                sample = Sample.query.filter_by(code=code.code).first()
                if sample:
                    return failure(msg="该故障代码已被引用，只能更改故障建议")
            code.set_attrs(body)
        else:
            db.session.add(data)
        db.session.commit()
    except IntegrityError as e:
        return failure(msg="该故障代码已存在，不可重复创建")

    return success_saved()


@bp.route('/<code>', methods=['DELETE'])
@jwt_required
def remove(code):
    sample = Sample.query.filter_by(code=code).first()
    if sample:
        return failure(msg="该故障代码已被引用，不能删除")
    data = Code.query.filter_by(code=code).first_or_404()
    db.session.delete(data)
    db.session.commit()
    return success_removed()


def import_code():
    code_list = Code.query.all()
    if not code_list:
        with open("code.json", 'r', encoding='utf-8') as f:
            data = json.load(f)
            cl = []
            for item in data["RECORDS"]:
                c = Code()
                c.set_attrs(item)
                cl.append(c)
            db.session.add_all(cl)
            db.session.commit()
