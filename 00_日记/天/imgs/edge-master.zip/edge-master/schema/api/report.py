import json
import os
from datetime import timedelta, datetime

import pandas as pd
from config import CONFIG
from dateutil.relativedelta import relativedelta
from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from libs.result import success
from models.model import db, Sample
from sqlalchemy import or_

bp = Blueprint('report', __name__)


@bp.route('/scatter', methods=['POST'])
@jwt_required
def draw_scatter():
    body = request.json
    start = datetime.strptime(body['start'], '%Y-%m-%dT%H:%M:%S.%fZ')
    end = datetime.strptime(body['end'], '%Y-%m-%dT%H:%M:%S.%fZ')
    # 转换为北京时间
    start = (start + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
    end = (end + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')

    results = []
    for schema in body['schemas']:
        station_name = schema['name']
        table_name = str.lower('{}_{}_{}'.format(schema['station'], schema['sensor'], schema['component']))
        select_columns = ''
        for feature in schema['checkedList']:
            select_columns = select_columns + ', ' + feature

        frame = get_vib_data(table_name, start, end, select_columns)
        frame = frame.where(frame.notnull(), None)
        for feature in schema['checkedList']:
            # 是否进行归一化展示
            if body['normalize']:
                frame[str.lower(feature)] = normalize_series(frame[str.lower(feature)])
            data = frame[['timestamp', str.lower(feature)]].values.tolist()
            results.append({
                'legend': station_name + " " + feature,
                'data': data
            })
    return success(data=results)


@bp.route('/distributed', methods=['POST'])
@jwt_required
def draw_distributed():
    body = request.json
    start = datetime.strptime(body['start'], '%Y-%m-%dT%H:%M:%S.%fZ')
    end = datetime.strptime(body['end'], '%Y-%m-%dT%H:%M:%S.%fZ')
    # 转换为北京时间
    start = (start + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
    end = (end + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
    # 柱状分布图间隔
    bins = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 150, 200, 300, 400, 500, 1000, 5000]
    dimensions = ['interval']
    source = {}
    for schema in body['schemas']:
        # 获取振动数据
        table_name = str.lower('{}_{}_{}'.format(schema['station'], schema['sensor'], schema['component']))
        legend = '{} {}'.format(schema['station'], schema['component'])
        frame = get_vib_data(table_name, start, end)
        frame = frame.where(frame.notnull(), None)
        # 分析振动分布区间
        quartiles = pd.cut(frame['vibrms'], bins)
        grouped = frame['vibrms'].groupby(quartiles, observed=False)
        counts = grouped.apply(get_stats).unstack()
        # 整理报表数据结构
        dimensions.append(legend)
        for index, row in counts.iterrows():
            if str(index) not in source:
                source[str(index)] = {'interval': str(index)}
            source[str(index)][legend] = int(row['count'])
    data = {'dimensions': dimensions, 'source': list(source.values())}
    return success(data=data)


@bp.route('/trend', methods=['POST'])
@jwt_required
def draw_trend():
    body = request.json
    schema = body['schema']
    months = body['months']
    threshold = body['threshold']

    totals = []
    maxs = []
    mins = []
    means = []
    medians = []
    stds = []
    q1s = []
    q3s = []
    thresholds = []
    # flux = False

    for month in months:
        table_name = str.lower('{}_{}_{}'.format(schema['station'], schema['sensor'], schema['component']))
        frame = get_vib_data_summary(table_name, month)
        frame = frame.where(frame.notnull(), 0)
        totals.append(round(float(frame.at[0, 'total']), 3))
        maxs.append(round(float(frame.at[0, 'max']), 3))
        mins.append(round(float(frame.at[0, 'min']), 3))
        means.append(round(float(frame.at[0, 'mean']), 3))
        medians.append(round(float(frame.at[0, 'median']), 3))
        stds.append(round(float(frame.at[0, 'std']), 3))
        q1s.append(round(float(frame.at[0, 'q1']), 3))
        q3s.append(round(float(frame.at[0, 'q3']), 3))
        # 没有设置阈值不统计超过阈值数量
        if threshold is not None:
            frame2 = get_threshold_count(table_name, month, threshold)
            frame2 = frame2.where(frame2.notnull(), 0)
            thresholds.append(int(frame2.at[0, 'threshold']))
        else:
            thresholds.append(0)

    # 根据中位数和标准差判断波动情况
    # if len(months) >= 6:
    #     flux = analysis_flux(medians, stds)

    result = {
        'totals': totals,
        'maxs': maxs,
        'mins': mins,
        'means': means,
        'medians': medians,
        'stds': stds,
        'q1s': q1s,
        'q3s': q3s,
        'thresholds': thresholds
        # 'flux': flux
    }
    return success(data=result)


@bp.route('/detect', methods=['POST'])
@jwt_required
def detect_report():
    body = request.json
    schema = body['schema']

    # 计算六个月前的日期
    six_months_ago = datetime.now() - relativedelta(months=6)
    # 获取六个月前的月份的第一天
    first_day_of_six_months_ago = datetime(six_months_ago.year, six_months_ago.month, 1)

    samples_all = Sample.query.filter(Sample.schema_id == schema['id'],
                                      or_(Sample.state == 'sample',
                                          Sample.state == 'fault'
                                          )).order_by(Sample.start_time.desc()).all()
    # 总样本数
    sample_list = [sample for sample in samples_all if sample.state == 'sample']
    # 当前报警数
    fault_list = [sample for sample in samples_all if sample.state == 'fault']

    result = {'warning': 0, 'danger': 0, 'last6month_warning': 0, 'last6month_danger': 0,
              'sample_count': len(sample_list)}

    if len(fault_list) > 0:
        for sample in fault_list:
            if sample.code_level == 'warning':
                result['warning'] += 1
            elif sample.code_level == 'danger':
                result['danger'] += 1

    if len(sample_list) > 0:
        for sample in sample_list:
            if sample.confirm_time and sample.confirm_time >= first_day_of_six_months_ago:
                if sample.code_level == 'warning':
                    result['last6month_warning'] += 1
                elif sample.code_level == 'danger':
                    result['last6month_danger'] += 1

    return success(data=result)


# 根据中位数和标准差判断波动情况
def analysis_flux(medians, stds):
    k_medians = (medians[5] - medians[0]) / 5
    k_stds = (stds[5] - stds[0]) / 5

    if k_medians >= 0 and k_stds >= 0:
        if k_medians > CONFIG['FLUX_ROOF'] or k_stds > CONFIG['FLUX_ROOF']:
            return True
    elif k_medians <= 0 and k_stds <= 0:
        if k_medians < CONFIG['FLUX_FLOOR'] or k_stds < CONFIG['FLUX_FLOOR']:
            return True
    else:
        return True

    return False


def get_vib_data(table_name, start_time, end_time, select_columns=', vibrms'):
    sql = """
             SELECT to_char(timestamp, 'YYYY-MM-DD HH24:MI:SS') AS timestamp  {select_columns}
             FROM {table_name} WHERE timestamp >= %s AND timestamp <= %s ORDER BY timestamp
          """.format(select_columns=select_columns, table_name=table_name)

    frame = pd.read_sql_query(sql, con=db.engine, params=(start_time, end_time))
    return frame


def get_vib_data_summary(table_name, month):
    start_time, end_time = get_month_start_end(month)

    health_critical_cache = {}
    json_path = './cache/health_critical_cache.json'
    if os.path.isfile(json_path):
        with open(json_path, 'r', encoding='utf-8') as json_file:
            health_critical_cache = json.load(json_file)
    threshold = health_critical_cache.get(table_name, 0)

    sql = """
              SELECT 
                count(*) as total,
                max(vibrms) as max, 
                min(vibrms) as min, 
                avg(vibrms) FILTER (WHERE vibrms > %s) as mean, 
                stddev(vibrms) FILTER (WHERE vibrms > %s) as std, 
                percentile_disc(0.25) within group (order by vibrms) FILTER (WHERE vibrms > %s)  as q1, 
                percentile_disc(0.5) within group (order by vibrms) FILTER (WHERE vibrms > %s) as median, 
                percentile_disc(0.75) within group (order by vibrms) FILTER (WHERE vibrms > %s) as q3 
            FROM {table_name}
            WHERE timestamp >= %s AND timestamp <= %s
              """.format(table_name=table_name)

    return pd.read_sql_query(sql, con=db.engine,
                             params=(threshold, threshold, threshold, threshold, threshold, start_time, end_time))


def get_threshold_count(table_name, month, threshold):
    start_time, end_time = get_month_start_end(month)

    sql = """
              SELECT 
                  count(vibrms) as threshold 
              FROM {table_name}
              WHERE timestamp >= %s AND timestamp <= %s
              AND vibrms >= %s
              """.format(table_name=table_name)

    return pd.read_sql_query(sql, con=db.engine, params=(start_time, end_time, threshold))


# 定义聚合函数
def get_stats(group):
    return {'count': group.count()}


# 将 Pandas Series 归一化到 [0, 1] 范围内
def normalize_series(feature):
    min_val = feature.min()
    max_val = feature.max()
    normalize = 0
    if max_val - min_val != 0:
        normalize = (feature - min_val) / (max_val - min_val)
    return normalize


# 获取一个月的初始时间和结尾时间
def get_month_start_end(month):
    start_time = f"{month}-01 00:00:00"
    end_time = (
            pd.to_datetime(start_time) +
            pd.offsets.MonthEnd(0)
    ).strftime('%Y-%m-%d 23:59:59.999')
    return start_time, end_time
