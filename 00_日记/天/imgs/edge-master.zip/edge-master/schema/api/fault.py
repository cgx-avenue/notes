from datetime import datetime
from flask import Blueprint, request
from models.model import db, Sample, Schema
from libs.result import is_blank, success, success_saved, success_removed, failure, result
from flask_jwt_extended import jwt_required


bp = Blueprint('fault', __name__)


@bp.route('', methods=['GET'])
@jwt_required
def get_all():
    data = Sample.query.filter_by(state='fault').order_by(Sample.start_time.desc()).all()
    return success(data=data)


@bp.route('/<id>/confirm', methods=['POST'])
@jwt_required
def confirm(id):
    data = Sample.query.filter_by(id=id).first_or_404()
    if data.state != 'fault':
        return failure(msg='不是故障数据')
    data.state = 'sample'
    data.confirm_time = data.update_time = datetime.now()
    db.session.commit()
    return success()


@bp.route('/<id>/misjudgment', methods=['POST'])
@jwt_required
def misjudgment(id):
    data = Sample.query.filter_by(id=id).first_or_404()
    if data.state != 'fault':
        return failure(msg='不是故障数据')
    data.state = 'misjudgment'
    db.session.commit()
    return success()


