import json
import re
from flask import Blueprint, request
from models.model import db, Schema, Sample
from libs.result import is_blank, is_not_blank, success, success_saved, success_removed, failure, result
import create_data_table
from flask_jwt_extended import jwt_required
import pandas as pd

bp = Blueprint('schema', __name__)


@bp.route('/upload', methods=['POST'])
@jwt_required
def upload_data():
    data = request.form.get('data')
    if not data:
        return failure(msg='缺少表信息')
    table_info = json.loads(data)
    table_name = '{}_{}_{}'.format(table_info['station'], table_info['sensor'], table_info['component']).lower()
    fileList = request.files.getlist('files')
    df = pd.DataFrame()
    for f in fileList:
        excel_data = pd.read_excel(f, dtype=object)
        f_df = pd.DataFrame(excel_data)
        df = pd.concat([f_df, df])
    df.columns = df.columns.str.lower()
    df.sort_values(by='timestamp')
    table_values = df.to_dict(orient='records')

    create_data_table.upload_data(table_name, table_info, table_values)

    return success(msg="数据导入成功")


@bp.route('', methods=['GET'])
@jwt_required
def get_all():
    request.args.get('')
    data = Schema.query.order_by(Schema.station, Schema.sensor, Schema.component).all()
    string_to_list(data)
    return success(data=data)


@bp.route('/<id>', methods=['GET'])
@jwt_required
def get_by_id(id):
    data = Schema.query.filter_by(id=id).first_or_404()
    string_to_list(data)
    return success(data=data)


@bp.route('', methods=['POST'])
@jwt_required
def save():
    body = request.json
    # 表单校验
    if is_blank(body, 'station'):
        return failure(msg='工位不能为空')
    if is_blank(body, 'sensor'):
        return failure(msg='传感器不能为空')
    if is_blank(body, 'component'):
        return failure(msg='组件不能为空')
    if is_blank(body, 'protocol'):
        return failure(msg='传输协议不能为空')
    if is_blank(body, 'host'):
        return failure(msg='Host不能为空')
    if is_blank(body, 'port'):
        return failure(msg='端口不能为空')

    # 针对北石顶驱项目自动生成mqtt的topic
    # if body['protocol'] in ['MQTT', 'OPCUA'] and is_blank(body, 'topic'):
    #     return failure(msg='MQTT/OPCUA协议Topic不能为空')
    if body['protocol'] in ['MQTT', 'OPCUA']:
        body['topic'] = str.lower('{}_{}_{}'.format(body['station'], body['sensor'], body['component']))
    else:
        body['topic'] = ""

    if is_blank(body, 'features') or len(body['features']) == 0:
        return failure(msg='特征不能为空')
    for item in body['features']:
        if not item:
            return failure(msg='特征不能为空')
    list_to_json(body)
    # 校验feature不能为特殊字符
    pattern = '^\w+$'
    contains_rms = False
    contains_time = False
    for feature in json.loads(body['features']):
        if not re.match(pattern, feature['feature']):
            return failure(msg='特征只能包含字母、数字和下划线')
        # vibrms是必选特征
        if str.lower(feature['feature']) == 'vibrms':
            contains_rms = True
        # timestamp是必选特征
        if str.lower(feature['feature']) == 'timestamp':
            contains_time = True
        # 校验阈值是否完整
        if is_blank(feature, 'middle') and is_blank(feature, 'middle_code') and is_blank(feature, 'high') and is_blank(
                feature, 'high_code'):
            continue
        elif is_not_blank(feature, 'middle') and is_not_blank(feature, 'middle_code') and is_not_blank(feature,
                                                                                                       'high') and is_not_blank(
            feature, 'high_code'):
            continue
        else:
            return failure(msg='特征阈值或代码填写不完整，请补充')

    if not contains_rms:
        return failure(msg='必须包含vibRms特征')
    if not contains_time:
        return failure(msg='必须包含timestamp时间戳')

    # 有id更新记录, 无id新建
    if 'id' in body and body['id'] is not None:
        Schema.query.filter_by(id=body['id']).update(body)
    else:
        # 新建之前检查是否重复
        q = Schema.query \
            .filter(Schema.station == body['station']) \
            .filter(Schema.sensor == body['sensor']) \
            .filter(Schema.component == body['component'])
        old_data = q.first()
        if old_data:
            return failure(msg='Data point duplicated, please check.')
        body['middle_factor'] = 0.3
        body['high_factor'] = 0.5
        data = Schema()
        data.set_attrs(body)
        db.session.add(data)
    db.session.commit()
    return success_saved()


@bp.route('/<id>', methods=['DELETE'])
@jwt_required
def remove(id):
    data = Schema.query.filter_by(id=id).first_or_404()
    db.session.delete(data)
    Sample.query.filter_by(schema_id=id).delete()
    db.session.commit()
    return success_removed()


@bp.route('/createTables', methods=['POST'])
@jwt_required
def create_table():
    id = request.args.get('id')
    create_data_table.start(id)
    return success(msg='建表成功')


def string_to_list(data):
    if isinstance(data, list):
        for item in data:
            item.features = json.loads(item.features)
    else:
        data.features = json.loads(data.features)


def list_to_json(data):
    data['features'] = json.dumps(data['features'])
