import json
from datetime import datetime
from flask import Blueprint, request
import diagnosis
from models.model import db, Sample, Schema
from libs.result import is_blank, success, success_saved, success_removed, failure, result
from flask_jwt_extended import jwt_required

bp = Blueprint('sample', __name__)


@bp.route('', methods=['GET'])
@jwt_required
def get_all():
    data = Sample.query.filter_by(state='sample').order_by(Sample.update_time.desc()).all()
    return success(data=data)


@bp.route('/<id>', methods=['GET'])
@jwt_required
def get_by_id(id):
    data = Sample.query.filter_by(id=id).first_or_404()
    return success(data=data)


@bp.route('', methods=['POST'])
@jwt_required
def save():
    body = request.json
    # 表单校验
    body['update_time'] = datetime.now()
    # 有id更新记录, 无id新建
    if 'id' in body and body['id'] is not None:
        Sample.query.filter_by(id=body['id']).update(body)
    else:
        data = Sample()
        data.set_attrs(body)
        data.origin = 'entry'
        data.state = 'sample'
        db.session.add(data)
    db.session.commit()
    return success_saved()


@bp.route('/<id>', methods=['DELETE'])
@jwt_required
def remove(id):
    data = Sample.query.filter_by(id=id).first_or_404()
    db.session.delete(data)
    db.session.commit()
    return success_removed()


@bp.route('/<id>/rms', methods=['GET'])
@jwt_required
def get_rms(id):
    sample = Sample.query.filter_by(id=id).first_or_404()
    schema = Schema.query.filter_by(id=sample.schema_id).first_or_404()
    table_name = str.lower('{}_{}_{}'.format(schema.station, schema.sensor, schema.component))
    # 时区问题
    # start_time = (sample.start_time + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
    # end_time = (sample.end_time + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
    start_time = sample.start_time.strftime('%Y-%m-%d %H:%M:%S')
    end_time = sample.end_time.strftime('%Y-%m-%d %H:%M:%S')
    data = diagnosis.get_vib_data(db.engine, table_name, start_time, end_time)
    diagnosis.mark_static(data)
    return success(data=data.values.tolist())


@bp.route('/view/rms', methods=['POST'])
@jwt_required
def view_rms():
    body = request.json
    start_time = body['start_time']
    end_time = body['end_time']
    schema_id = body['schema_id']
    schema = Schema.query.filter_by(id=schema_id).first_or_404()
    table_name = str.lower('{}_{}_{}'.format(schema.station, schema.sensor, schema.component))
    data = diagnosis.get_vib_data(db.engine, table_name, start_time, end_time)
    diagnosis.mark_static(data)
    return success(data=data.values.tolist())


@bp.route('/algorithms', methods=['GET'])
@jwt_required
def get_train_algorithms():
    return success(data=diagnosis.CLF_OPTIONS)


@bp.route('/<schema_id>/train', methods=['GET'])
@jwt_required
def train(schema_id):
    samples = Sample.query.filter_by(schema_id=schema_id, state='sample').order_by(Sample.start_time.desc()).all()
    if len(samples) == 0:
        return failure(msg='样本为空，请在样本管理添加故障/健康数据')
    # 遍历样本，是否同时包含故障/健康数据
    error, healthy = False, False
    for sample in samples:
        if error and healthy:
            break
        if sample.code_level == 'success':
            healthy = True
        elif sample.code_level in ('warning', 'danger'):
            error = True
    if not error:
        return failure(msg='没有故障样本，请添加')
    if not healthy:
        return failure(msg='没有健康样本，请添加')
    schema = Schema.query.filter_by(id=schema_id).first_or_404()
    if schema.algorithm is None or is_blank(diagnosis.CLFS, schema.algorithm):
        return failure(msg='请先选择诊断算法')
    # 样本表，采样特征
    table_name = str.lower('{}_{}_{}'.format(schema.station, schema.sensor, schema.component))
    features = [str.lower(feature['feature']) for feature in json.loads(schema['features']) if
                feature['feature'] != 'timestamp']
    # 使用分类算法诊断样本，计算准确度
    accuracy = diagnosis.diagnose(db.engine, table_name, features, samples, schema.algorithm)
    # 更新数据
    schema.accuracy = accuracy
    db.session.commit()
    return success(msg="已生成预测模型")
