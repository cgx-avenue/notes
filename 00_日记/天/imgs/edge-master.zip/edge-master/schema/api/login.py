from flask import Blueprint, request
from models.model import db, User
from libs.result import is_blank, is_not_blank, success, failure, result
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
import psutil
from datetime import datetime, timedelta
from log import logger

bp = Blueprint('login', __name__)


@bp.route('', methods=['POST'])
def login():
    body = request.json
    username = body['username']
    password = body['password']
    user = User.query.filter_by(username=username).one_or_none()
    # # 是否移机安装
    # if user.expiration_date:
    #     mac = get_mac_address()
    #     file_path = './secret_key.txt'
    #     if (os.path.exists(file_path)):
    #         with open(file_path, 'r', encoding='utf-8') as file:
    #             content = file.read()
    #             if content != hmac_md5(mac):
    #                 return failure("End of probationary period"), 403
    #     else:
    #         secret_key = hmac_md5(mac)
    #         with open(file_path, 'w', encoding='utf-8') as file:
    #             file.write(secret_key)
    # if user not found or password not correct
    if not user or not user.check_password(password):
        return failure("Wrong username or password"), 403
    # 试用期是否超时
    if user.expiration_date and user.expiration_date <= datetime.now():
        return failure("End of probationary period"), 402
    # create access token
    user_claims = {"role": user.role}
    access_token = create_access_token(identity=username, user_claims=user_claims)
    return success(msg="Login success",
                   data={"username": username, "role": user.role, "expiration_date": user.expiration_date}) \
        , 200, [("Authorization", "Bearer " + access_token)]


# @bp.route('', methods=['POST'])
def save():
    u = User.query.first()
    if not u:
        data = User(username='admin', password='admin', role='admin', expiration_date=get_expiration_date())
        db.session.add(data)
        db.session.commit()


def get_mac_address():
    try:
        # 获取所有网络接口信息
        network_interfaces = psutil.net_if_addrs()
        # 遍历网络接口，找到以太网接口并获取其 MAC 地址
        for interface, addresses in network_interfaces.items():
            for address in addresses:
                if address.family == psutil.AF_LINK:
                    return address.address
    except Exception as e:
        logger.error('Get mac_address error', repr(e))


def get_expiration_date():
    current_date = datetime.now()
    # 增加90天
    three_months_later = current_date + timedelta(days=90)
    expiration_date = three_months_later.replace(hour=0, minute=0, second=0, microsecond=0)
    return expiration_date
