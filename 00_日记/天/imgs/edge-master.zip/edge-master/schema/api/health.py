import base64
import json
import os
from collections import defaultdict
from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from libs.result import success, failure
from models.model import db, Schema, StationImage, Sample, Code
bp = Blueprint('health', __name__)


@bp.route('/all', methods=['GET'])
@jwt_required
def get_all_health():
    data = Schema.query.order_by(Schema.station, Schema.sensor, Schema.component).all()
    health_score_cache = {}
    json_path = './cache/health_score_cache.json'
    if os.path.isfile(json_path):
        with open(json_path, 'r', encoding='utf-8') as json_file:
            health_score_cache = json.load(json_file)

    code_list = Code.query.filter().order_by(Code.code).all()
    code_suggestion_map = {code.code: code.suggestion for code in code_list}

    station_image_list = StationImage.query.filter().all()
    station_image_map = {station_image.station_name: station_image.image_data for station_image in station_image_list}

    sample_list = Sample.query.filter_by(state='fault').all()
    # 使用 defaultdict 来创建 schema_id 到sample列表的映射
    schema_samples_map = defaultdict(list)
    for sample in sample_list:
        schema_samples_map[sample.schema_id].append(sample)

    result = {}
    for schema in data:
        table_name = str.lower('{}_{}_{}'.format(schema['station'], schema['sensor'], schema['component']))
        health_score = health_score_cache.get(table_name, 0)
        alarm_code = 1000

        # 根据health_score判断alarm_code
        if health_score == 0:
            alarm_code = 0
        elif health_score < 0.7:
            alarm_code = 1200
        elif health_score < 0.8:
            alarm_code = 1100

        station_name, _, component_name = schema.station.partition('_')
        if station_name not in result:
            result[station_name] = {
                "station_name": station_name,
                "components": [],
                "image_data": station_image_map.get(station_name) if station_image_map.get(station_name) else ''
            }

        has_fault = False
        samples = schema_samples_map.get(schema["id"])
        if samples:
            max_sample = max(samples, key=lambda s: s.code)
            alarm_code = max(alarm_code, int(max_sample.code))
            has_fault = True

        result[station_name]["components"].append({
            "id": schema["id"],
            "component_name": component_name,
            "table_name": str.lower('{}_{}_{}'.format(schema['station'], schema['sensor'], schema['component'])),
            "health_score": health_score * 100,
            "has_fault": has_fault,
            "alarm_code": alarm_code,
            "alarm_suggestion": code_suggestion_map.get(str(alarm_code))
        })

    result = list(result.values())
    return success(data=result)


@bp.route('/upload', methods=['POST'])
@jwt_required
def upload_image():
    station_name = request.form.get('station_name')
    if not station_name:
        return failure(msg='缺少设备信息')
    file = request.files['file']
    # 读取文件
    image_data = base64.b64encode(file.read()).decode('utf-8')
    data = StationImage.query.filter_by(station_name=station_name).first()
    if not data:
        data = StationImage()
        data.station_name = station_name
        data.image_data = image_data
        db.session.add(data)
    else:
        data.image_data = image_data
    db.session.commit()
    return success(data=image_data, msg="图片上传成功")


@bp.route('/correlation', methods=['POST'])
@jwt_required
def health_correlation():
    body = request.json
    table_name = body['table_name']

    health_correlation_cache = {}
    json_path = './cache/health_correlation_cache.json'
    if os.path.isfile(json_path):
        with open(json_path, 'r', encoding='utf-8') as json_file:
            health_correlation_cache = json.load(json_file)

    default_data = {}
    data = health_correlation_cache.get(table_name, default_data)
    return success(data=data)

@bp.route('/distributed', methods=['POST'])
@jwt_required
def health_distributed():
    body = request.json
    table_name = body['table_name']

    health_distributed_cache = {}
    json_path = './cache/health_distributed_cache.json'
    if os.path.isfile(json_path):
        with open(json_path, 'r', encoding='utf-8') as json_file:
            health_distributed_cache = json.load(json_file)

    default_data = {'dimensions': ['interval'], 'source': [], 'total': 0}
    data = health_distributed_cache.get(table_name, default_data)
    return success(data=data)


@bp.route('/compare', methods=['POST'])
@jwt_required
def health_compare():
    body = request.json
    table_name = body['table_name']
    health_compare_cache = {}
    json_path = './cache/health_compare_cache.json'
    if os.path.isfile(json_path):
        with open(json_path, 'r', encoding='utf-8') as json_file:
            health_compare_cache = json.load(json_file)

    default_data = [{'cycle': 7}, {'cycle': 30}]
    result = health_compare_cache.get(table_name, default_data)
    return success(data=result)


@bp.route('/trend', methods=['POST'])
@jwt_required
def health_trend():
    body = request.json
    table_name = body['table_name']
    health_trend_cache = {}
    json_path = './cache/health_trend_cache.json'
    if os.path.isfile(json_path):
        with open(json_path, 'r', encoding='utf-8') as json_file:
            health_trend_cache = json.load(json_file)
    default_data = {
        'totals': 0,
        'maxs': 0,
        'mins': 0,
        'means': 0,
        'medians': 0,
        'stds': 0,
        'q1s': 0,
        'q3s': 0,
        'thresholds': False
    }
    result = health_trend_cache.get(table_name, default_data)
    return success(data=result)


@bp.route('/<station_name>', methods=['GET'])
@jwt_required
def get_image_by_station(station_name):
    data = StationImage.query.filter_by(station_name=station_name).first()
    if not data:
        return success(msg='未上传图片')
    return success(data=data.image_data)




