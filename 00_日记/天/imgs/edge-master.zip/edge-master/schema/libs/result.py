from models.model import Base


def is_blank(_dict: dict, _key):
    return _key not in _dict.keys() or _dict[_key] is None or (isinstance(_dict[_key], str) and str.strip(_dict[_key]) == '')


def is_not_blank(_dict: dict, _key):
    return not is_blank(_dict, _key)


def success_saved(data=None):
    return success(data=data, msg='保存成功')


def success_removed(data=None):
    return success(data=data, msg='删除成功')


def success(msg='Success', data=None):
    return {'success': True, 'msg': msg, 'data': result(data)}


def failure(msg='Failure', data=None):
    return {'success': False, 'msg': msg, 'data': result(data)}


def result(data=None):
    if not data:
        return None
    if isinstance(data, list):
        return [item.serialize() if isinstance(item, Base) else item for item in data ]
    else:
        if isinstance(data, Base):
            return data.serialize()
        else:
            return data
