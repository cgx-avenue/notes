# shellcheck disable=SC2164
# shellcheck disable=SC2103
docker-compose down
docker image prune -f

docker load -i web-config.tar
docker load -i schema.tar
docker load -i data2db.tar
docker load -i gateway.tar
docker load -i fault-detect.tar

docker-compose up -d

