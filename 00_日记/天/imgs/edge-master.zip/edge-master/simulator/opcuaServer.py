# pylint: disable=import-error
import sys, os
import json
from opcua import ua, Server
import time
import random

cfgpath = 'opcuaSimulator.cfg'
def jsonReader(configFilePath):

    if not os.path.exists(configFilePath): 
        print('ERROR: Configure file %s does not exist' % configFilePath)            

    with open(configFilePath,'r') as load_f:
        load_dict = json.load(load_f)
        return load_dict

def process():

    serverInfo = jsonReader('config.json')['OPCUA_SIMULATOR']
    endPonit = "opc.tcp://" + serverInfo["url"] + ":" + serverInfo["port"] + serverInfo["params"]
    print(endPonit)

    server = Server()
    server.set_endpoint(endPonit)

    objects = server.get_objects_node()
    folder = objects.add_folder("ns=2;s=Object","Object")

    file_object = open(cfgpath , "r")
    nodelist = file_object.readlines()
    length = len(nodelist)
    # print(nodelist)

    varList = [0] * length
    count = 0

    for node in nodelist:
        tmp = node.split('.')
        tag = tmp[-1]

        var_str = "ns=2;s=" + node
        print(var_str)
        varList[count] = folder.add_variable(var_str,tag,float(random.randint(10,50)))
        varList[count].set_writable()
        count += 1

    server.start()
    
    try:
        while True:
            time.sleep(1)
            for i in range(length):
                varList[i].set_value(random.randint(10,50))

    finally:
        #close connection, remove subcsriptions, etc
        server.stop()

# if __name__ == '__main__':
#     process()