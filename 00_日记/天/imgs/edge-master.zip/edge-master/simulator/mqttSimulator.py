import paho.mqtt.client as mqtt
import time
import json
import random
import sys, os
from datetime import datetime
import threading


def jsonReader(configFilePath):
    if not os.path.exists(configFilePath):
        print('ERROR: Configure file %s does not exist' % configFilePath)

    with open(configFilePath, 'r') as load_f:
        load_dict = json.load(load_f)
        return load_dict


def get_currenttime():
    currenttime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    return currenttime


def getPayload(featureList):
    body = {}
    body["_time"] = get_currenttime()

    for feature in featureList:
        body[feature] = random.randint(13, 60)

    return body


def getTopicList(topicHeader, parmaList, componentList):
    topicList = []
    for parama in parmaList:
        for component in componentList:
            topicList.append(topicHeader + str(parama) + '/' + str(component))

    return topicList


class mqttThread(threading.Thread):
    def __init__(self, client, topic, featureList):
        threading.Thread.__init__(self)
        self.client = client
        self.topic = topic
        self.featureList = featureList

    def run(self):
        client = self.client
        topic = self.topic
        featureList = self.featureList

        while True:
            try:
                # 发布MQTT信息
                payload = getPayload(featureList)
                client.publish(topic=topic, payload=str(payload))
                time.sleep(2)
                print(topic + "     published!")
            except Exception as e:
                print(e)
                client.disconnect()
                sys.exit(0)

def process():
    jsonContent = jsonReader('config.json')['MQTT_SIMULATOR']
    host = jsonContent["mqttHost"]
    port = jsonContent["mqttPort"]
    topicHeader = jsonContent["topicHeader"]
    workStationList = jsonContent["workStationList"]
    componentList = jsonContent["componentList"]
    featurelist = jsonContent['featurelist']
    topicList = getTopicList(topicHeader, workStationList, componentList)

    client = mqtt.Client()
    client.connect(host=host, port=port, keepalive=60)

    # topic = topicHeader + workStationList[0]

    threads = []

    for topic in topicList:
        t = mqttThread(client, topic, featurelist)
        threads.append(t)

    for thr in threads:
        thr.start()


if __name__ == '__main__':
    process()
