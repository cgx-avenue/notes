from multiprocessing import Pool
import modbusServer
import mqttSimulator
import opcuaServer

if __name__ == '__main__':
    p = Pool(3)
    p.apply_async(func=modbusServer.process, args=())
    p.apply_async(func=mqttSimulator.process, args=())
    p.apply_async(func=opcuaServer.process, args=())
    print('Waiting for all subprocesses done...')
    p.close()
    p.join()
    print('All subprocesses done.')