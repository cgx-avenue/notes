import time
import modbus_tk
import modbus_tk.defines as cst
import modbus_tk.modbus_tcp as modbus_tcp
from numpy import arange
import os
import struct
import json

LOGGER = modbus_tk.utils.create_logger(name="console", record_format="%(message)s")
cfgpath = 'modbus2db.cfg'
def get_errorinfolist(cfgpath):
      datalist = []
      with open(cfgpath,"r") as file:
            nodelist = file.readlines()
            datalist = list(map(lambda x: (x[0],x[1],x[2],x[3]),map(lambda x: x.strip("\n").split("|"),nodelist)));
      return datalist


def get_address():
      dbdatainfo = get_errorinfolist(cfgpath)
      features= list(map(lambda x: x[3] , dbdatainfo))
      return features


def jsonReader(configFilePath):
    if not os.path.exists(configFilePath): 
        print('ERROR: Configure file %s does not exist' % configFilePath)            

    with open(configFilePath,'r') as load_f:
        load_dict = json.load(load_f)
        return load_dict


def float_to_bytes(f):
    bs = struct.pack("f",f)
    return (bs[3],bs[2],bs[1],bs[0])


def process():
      modbus_server = jsonReader('config.json')['MODBUS_SIMULATOR']
      host = modbus_server["url"]
      port = int(modbus_server["port"])
      SERVER = modbus_tcp.TcpServer(address=host, port=port)
      LOGGER.info("modbus simulator is running...")
      LOGGER.info("enter 'quit' for closing the server")
      # 服务启动
      SERVER.start()
      # 建立第一个从机
      SLAVE1 = SERVER.add_slave(1)
      SLAVE1.add_block('A', cst.ANALOG_INPUTS, 0, 30)  
      addresses =get_address()
      while True:           
            for address in addresses:
                  for i in arange(0.01,10):
                        SLAVE1.set_values('A', eval(address)['startAddress'], float_to_bytes(i))  # 改变在地址0处的寄存器的值
                        time.sleep(0.1)


# if __name__ == "__main__":
#     process()