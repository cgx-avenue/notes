import time
from datetime import datetime
import paho.mqtt.client as mqtt
import json
import os

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("连接成功")
        print("Connected with result code " + str(rc)+"|时间："+datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f'))

def on_message(client, userdata, msg):
    print(msg.topic + " " + str(msg.payload))

def jsonReader(configFilePath):
    if not os.path.exists(configFilePath): 
        print('ERROR: Configure file %s does not exist' % configFilePath)            

    with open(configFilePath,'r') as load_f:
        load_dict = json.load(load_f)
        return load_dict

def getTopicList(topicHeader,parmaList):
    topicList = []
    for parama in parmaList:
        topicList.append((topicHeader + str(parama),0))
    
    return topicList


if __name__ == '__main__':

    cfgPath = 'mqtt_config.json'
    jsonContent = jsonReader(cfgPath)

    host = jsonContent["mqttHost"]
    port = jsonContent["mqttPort"]
    topicHeader = jsonContent["topicHeader"]
    workStationList = jsonContent["workStationList"]

    topicList = getTopicList(topicHeader,workStationList)

    client = mqtt.Client(protocol=3)
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect("192.168.3.7", 1883,  keepalive=60)  # 订阅频道
    client.subscribe(topicList)
    client.loop_forever()
    # client.loop_start()













