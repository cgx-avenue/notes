import requests
import datetime
import json
from log import logger

WEBSERVERURL = 'http://192.168.2.211:1056'
HEADER = {'content-type': "application/json"}


def get_alarmlist(assetname, timedelay):
    endtime = datetime.datetime.now()
    starttime = endtime - datetime.timedelta(seconds=timedelay)
    str_starttime = starttime.strftime('%Y-%m-%d %H:%M:%S')
    str_endtime = endtime.strftime('%Y-%m-%d %H:%M:%S')
    url = WEBSERVERURL + "/alarm/deviceID/" + assetname + "?from=" + str_starttime + "&to=" + str_endtime
    headers = {'content-type': "application/json"}
    response = requests.get(url=url)

    jsonData = json.loads(response.text)
    res = jsonData["body"]
    alarmlist = res["alarms"]

    return alarmlist


def insertalarm(body, assetname, devicetype):
    url = ""
    # if devicetype == 'HighSpeedLifter':
    #     url =  WEBSERVERURL + "/insertAlarm/asset/"+ assetname +"/aspect/LifterAlarm"
    # elif devicetype == 'XDK110':
    #     url =  WEBSERVERURL + "/insertAlarm/asset/"+ assetname +"/aspect/XDK110"
    # else:
    #     log().logger.error("Device type is wrong!  Maybe there is something wrong in Config.json")

    url = WEBSERVERURL + "/insertAlarm/asset/" + assetname + "/aspect/" + devicetype

    postdata(url, [body])


def insertdata(body, assetname, aspectName):
    url = WEBSERVERURL + "/insertData/asset/" + assetname + "/aspect/" + aspectName
    postdata(url, [body])


def postdata(url, body, headers=HEADER):
    try:
        response = requests.post(url, data=json.dumps(body), headers=headers)
        # log().logger.debug('url:' + url + ' response:' + response.text)
    except Exception as e:
        logger.error(e)
