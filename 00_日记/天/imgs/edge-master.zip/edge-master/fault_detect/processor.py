import json
import os
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

import joblib
import pandas as pd

from config import CONFIG
from log import logger
from postgres import db

executor = ThreadPoolExecutor(CONFIG['MAX_WORKERS'])
THRESHOLD_MAP = {}
CODE_MAP = {}


def is_not_blank(_dict: dict, _key):
    return _key in _dict.keys() and _dict[_key] is not None and _dict[_key] != ""


# 读取schema，获取需要阈值判断的参数
def get_threshold_features():
    global THRESHOLD_MAP
    global CODE_MAP

    code_sql = 'select code, name, level, description from code order by code'
    code_list = db.query_all(code_sql)
    for code in code_list:
        CODE_MAP[code[0]] = [code[0], code[1], code[2], code[3]]

    sql = 'select station, sensor, component, features, id from schema where enable_threshold = true'
    schemas = db.query_all(sql)
    for schema in schemas:
        table_name = '{}_{}_{}'.format(schema[0], schema[1], schema[2])
        table_name = str.lower(table_name)
        if table_name not in THRESHOLD_MAP:
            THRESHOLD_MAP[table_name] = {}
        thresholds = THRESHOLD_MAP[table_name]
        for feature in json.loads(schema[3]):
            if all(is_not_blank(feature, k) for k in ['middle', 'middle_code', 'high', 'high_code']):
                if feature['feature'] in thresholds:
                    thresholds[feature['feature']]['middle']=feature['middle']
                    thresholds[feature['feature']]['middle_code'] = feature['middle_code']
                    thresholds[feature['feature']]['high'] = feature['high']
                    thresholds[feature['feature']]['high_code'] = feature['high_code']
                else:
                    thresholds[feature['feature']] = {
                        'middle': feature['middle'],
                        'middle_code': feature['middle_code'],
                        'high': feature['high'],
                        'high_code': feature['high_code'],
                        'schema_id': schema[4],
                        'station': schema[0],
                        'component': schema[2],
                        'threshold_buffer': 0,
                        'threshold_starttime': 0,
                        'threshold_endtime': 0,
                        'threshold_code': '',
                        'ml_buffer': 0,
                        'ml_starttime': 0,
                        'ml_endtime': 0,
                        'ml_code': '',
                    }
            else:
                if feature['feature'] in thresholds:
                    del thresholds[feature['feature']]


    # 移除空数组
    for table_name in list(THRESHOLD_MAP.keys()):
        if len(THRESHOLD_MAP[table_name]) == 0:
            del THRESHOLD_MAP[table_name]


def process(table_name, payload):
    # # 校验缓存中是否有超时的数据
    # check_timeout_q()

    data = json.loads(payload)
    date_format = datetime.strptime(data['timestamp'], '%Y-%m-%d %H:%M:%S')
    # 判断该数据是否为旧数据
    if datetime.now().timestamp() - date_format.timestamp() > CONFIG['FAULT_TIMEOUT']:
        return

    get_threshold_features()
    if table_name not in THRESHOLD_MAP:
        return

    path = './pkl/{}.pkl'.format(table_name)
    ml_solution = os.path.exists(path)

    for feature, threshold in THRESHOLD_MAP[table_name].items():

        feature_data = float(data[feature])

        # 阈值判断
        if feature_data > float(threshold['high']):
            if threshold['threshold_buffer'] == 0:
                threshold['threshold_starttime'] = date_format

            threshold['threshold_buffer'] += 1
            threshold['threshold_code'] = CODE_MAP[threshold['high_code']]

        elif feature_data > float(threshold['middle']):
            if threshold['threshold_buffer'] == 0:
                threshold['threshold_starttime'] = date_format

            threshold['threshold_buffer'] += 1
            if threshold['threshold_code'] == '':
                threshold['threshold_code'] = CODE_MAP[threshold['middle_code']]
        else:
            if threshold['threshold_buffer'] >= CONFIG['BUFFER_SIZE']:
                threshold['threshold_endtime'] = date_format

                table_value = {
                    "schema_id": threshold['schema_id'],
                    "station": threshold['station'],
                    "component": threshold['component'],
                    "code": threshold['threshold_code'][0],
                    "code_name": threshold['threshold_code'][1],
                    "code_level": threshold['threshold_code'][2],
                    "description": threshold['threshold_code'][3],
                    "start_time": threshold['threshold_starttime'],
                    "end_time": threshold['threshold_endtime'],
                    "origin": 'Threshold',
                }

                process_sql(table_value)
            threshold['threshold_buffer'] = 0

        # 模型预测, 当数据第一次导入，没有模型
        if ml_solution and feature == 'vibRms':
            pred_labels = predict_data(data, path)

            if pred_labels[0][:2] == '12':
                if threshold['ml_buffer'] == 0:
                    threshold['ml_starttime'] = date_format
                threshold['ml_buffer'] += 1
                threshold['ml_code'] = CODE_MAP[threshold['high_code']]

            elif pred_labels[0][:2] == '11':
                if threshold['ml_buffer'] == 0:
                    threshold['ml_starttime'] = date_format
                threshold['ml_buffer'] += 1
                if threshold['ml_code'] == '':
                    threshold['ml_code'] = CODE_MAP[threshold['middle_code']]
            else:
                if threshold['ml_buffer'] >= CONFIG['BUFFER_SIZE']:
                    threshold['ml_endtime'] = date_format

                    table_value = {
                        "schema_id": threshold['schema_id'],
                        "station": threshold['station'],
                        "component": threshold['component'],
                        "code": threshold['ml_code'][0],
                        "code_name": threshold['ml_code'][1],
                        "code_level": threshold['ml_code'][2],
                        "description": threshold['ml_code'][3],
                        "start_time": threshold['ml_starttime'],
                        "end_time": threshold['ml_endtime'],
                        "origin": 'ML',
                    }
                    process_sql(table_value)
                threshold['ml_buffer'] = 0


def predict_data(data, path):
    # 预测
    df = pd.DataFrame([data])
    X = df.drop(['timestamp'], axis=1).to_numpy()
    # clf = joblib.load('C:/Liu/Business/edge/schema/pkl/{}.pkl'.format(table_name))
    clf = joblib.load(path)
    pred_labels = clf.predict(X)
    return pred_labels


def process_sql(table_value):
    # 查询sample中同类记录的最近的一条，进行时间比对
    query_sql = "select id,start_time,end_time from sample where schema_id='{}' and code='{}' and origin='{}' and state='fault' " \
                "order by end_time desc limit 1".format(table_value['schema_id'], table_value['code'],
                                                        table_value['origin'])

    result = db.query_one(query_sql)

    if result and table_value['start_time'].timestamp() - result[2].timestamp() <= CONFIG['BUFFER_TIMEOUT']:

        sql = "update sample set end_time='{}' where schema_id='{}' and code='{}' and start_time='{}' and origin='{}' and state='fault' ".format(
            table_value['end_time'], table_value['schema_id'], table_value['code'], result[1],
            table_value['origin']
        )

    else:
        sql = 'INSERT INTO sample ("id", "start_time", "end_time", "state", "schema_id", "station", "component", "code", ' \
              '"code_name", "code_level", "description", "origin") VALUES ' \
              "(uuid_generate_v4(),'{}','{}','fault','{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}')".format(
            table_value['start_time'], table_value['end_time'],
            table_value['schema_id'], table_value['station'], table_value['component'], table_value['code'],
            table_value['code_name'], table_value['code_level'], table_value['description'], table_value['origin'])

    executor.submit(data_insert, sql)


def data_insert(sql, retry=0):
    # 最多重试3次
    if retry > CONFIG['RETRY_TIMES']:
        logger.error("insert failed after tried for {} times, sql: {}, ".format(retry - 1, sql))
        return
        # 重试的时候
    if retry != 0:
        time.sleep(CONFIG['RETRY_DELAY'])
        logger.info("retry batch insert data  for {} times".format(retry))
    try:
        db.exec(sql)
        # 插入数据到表
        logger.info("insert data for the {}rd time".format(retry))
        logger.debug("insert sql  {}".format(sql))
    except Exception as e:
        logger.error("data insert error, sql: {} : ".format(sql), exc_info=e)
        data_insert(sql, retry + 1)


# def check_timeout_q():
#     now = int(time.time())
#     global last_check_time
#     if last_check_time == 0:
#         last_check_time = now
#         return
#     # 比如配置的超时时间是20s，那么最多10s检查一次是否超时
#     if (now - last_check_time) < CONFIG['TIMEOUT'] / 2:
#         return
#     # 设置最后检查时间为当前时间
#     last_check_time = now
#
#     if timeout + CONFIG['TIMEOUT'] > now:
#         empty_queue(predict_queue.qsize())


# def empty_queue(size):
#     table_values = []
#     for i in range(size):
#         table_values.append(predict_queue.get())
#     try:
#         executor.submit(data_insert, table_values)
#         timeout = int(time.time())
#     except Exception as e:
#         logger.error("add to thread pool error: ", exc_info=e)

def alarm(table_name, code, feature, feature_data):
    pass
    # {'_time': '2021-03-03 13:32:00.850', 'Chain': 1200, 'Device': 1200}, PA01, XDK110
    # alarm_body = {"_time": gettime(), self.componentid: code, "Device": code}
    # httpClient.insertalarm(alarm_body, self.assetname, self.devicetype)

    # {'_time': '2021-03-03 13:32:00.850', feature: feature_data}, PA01, XDK110
    # data_body = {"_time": gettime(), feature: feature_data}
    # httpClient.insertdata(data_body, self.assetname, aspectname)
