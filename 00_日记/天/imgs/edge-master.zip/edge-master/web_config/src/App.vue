<template>
    <el-config-provider :locale="locale">
        <el-menu :default-active="$route.path" class="el-menu-demo" mode="horizontal" router>
            <el-menu-item index="/">
                <!-- <span style="font-size: large; font-weight: bold">DaaS</span>
              <el-divider direction="vertical"></el-divider> -->
                <el-image style="line-height: 1px; width: 100px" :src="require('./assets/images/siemens-logo.png')"></el-image>
            </el-menu-item>
            <el-menu-item v-if="username != null" index="/schemas">
                <i class="iconfont icon-station"></i>
                {{ $t('stationManagement') }}
            </el-menu-item>
            <el-menu-item v-if="username != null" index="/faults"> <i class="iconfont icon-fault"></i> {{ $t('faultManagement') }} </el-menu-item>
            <el-menu-item v-if="username != null" index="/samples"> <i class="iconfont icon-sample"></i> {{ $t('sampleManagement') }} </el-menu-item>
            <el-menu-item v-if="username != null" index="/diagnosis">
                <i class="iconfont icon-machine-learning"></i>
                <span class="menu-item-text">
                    {{ $t('diagnosticAlgorithm') }}
                </span>
            </el-menu-item>
            <el-menu-item v-if="username != null" index="/codes"> <i class="iconfont icon-code"></i> {{ $t('faultCodes') }} </el-menu-item>
            <el-menu-item v-if="username != null" index="/reports"> <i class="iconfont icon-report"></i> {{ $t('graphicalReports') }} </el-menu-item>
            <el-menu-item v-if="username != null" index="/health"><el-icon><List /></el-icon> 健康报告</el-menu-item>
            <el-menu-item v-if="username != null">
                <i class="el-icon-search" @click="showSearchBox = true" v-show="!showSearchBox && ($route.path === '/samples' || $route.path === '/codes' || $route.path === '/schemas')"></i>
                <div v-show="showSearchBox">
                    <el-input v-model="searchInput" style="max-width: 110px" @blur="searchInput.trim() === '' ? (showSearchBox = false) : ''"> </el-input>
                </div>
            </el-menu-item>

            <el-menu-item style="float: right">
                <el-link type="primary" href="/login" v-if="username == null">{{ $t('login') }}</el-link>
                <el-dropdown v-if="username != null">
                    <span class="el-dropdown-link">
                        <el-avatar>{{ username }}</el-avatar>
                        <el-icon class="el-icon--right">
                            <arrow-down />
                        </el-icon>
                    </span>
                    <template #dropdown>
                        <el-dropdown-menu>
                            <el-dropdown-item @click="logout()">{{ $t('logout') }}</el-dropdown-item>
                        </el-dropdown-menu>
                    </template>
                </el-dropdown>
            </el-menu-item>
            <el-menu-item style="float: right">
                <el-dropdown>
                    <span>
                        <img :src="require('./assets/images/translate.svg')" alt="Language Icon" class="custom-icon" />
                        {{ currentLanguageLabel }}
                    </span>
                    <template #dropdown>
                        <el-dropdown-menu>
                            <el-dropdown-item @click="toggleLanguage('zh-cn')">中文</el-dropdown-item>
                            <el-dropdown-item @click="toggleLanguage('en')">English</el-dropdown-item>
                        </el-dropdown-menu>
                    </template>
                </el-dropdown>
            </el-menu-item>
            <el-menu-item v-if="expiration_date && username" style="float: right; max-width: 250px">
                <div style="display: inline-flex; align-items: center">
                    <el-tag type="warning" round size="large">
                        <el-popover placement="left" :width="160" trigger="hover">
                            <template #reference>
                                <el-icon>
                                    <Calendar />
                                </el-icon>
                            </template>
                            <span style="font-size: 13px">{{ $t('trialExpiration') }}: {{ dateFormatter(expiration_date) }}</span>
                        </el-popover>
                        &nbsp;
                        <span style="font-weight: bolder; font-size: 13px"> {{ $t('trialRemaining') }}: {{ remainDay(expiration_date) }}&nbsp;{{ $t('days') }} </span>
                    </el-tag>
                </div>
            </el-menu-item>
        </el-menu>
        <div class="line" style="margin-bottom: 10px"></div>
        <router-view />
    </el-config-provider>
</template>

<script>
import utils from '@/plugins/utils'
import dayjs from 'dayjs'
import moment from 'moment'
import { mapGetters, mapActions } from 'vuex'
import { updateDocumentTitle } from './router'

export default {
    name: 'App',
    data() {
        return {
            showSearchBox: false,
            searchInput: ''
        }
    },
    computed: {
        ...mapGetters(['username', 'expiration_date']),
        currentLanguageLabel() {
            switch (this.$i18n.locale) {
                case 'zh-cn':
                    return '中文'
                case 'en':
                    return 'English'
                // case 'de':
                //     return 'Deutsch' // 德语
                // case 'es':
                //     return 'Español' // 西班牙语
                default:
                    return 'Language' // 默认返回
            }
        }
    },
    mounted() {
        utils.sendThis(this)
    },
    watch: {
        '$route.path': function () {
            this.showSearchBox = false
            this.searchInput = ''
        }
    },
    methods: {
        ...mapActions(['UserLoginOut']),
        toggleLanguage(language) {
            this.$i18n.locale = language // 更新 i18n 语言
            this.$store.dispatch('UpdateLanguage', language)

            // 手动更新当前页面标题
            updateDocumentTitle(this.$t, this.$route)
        },
        logout() {
            this.UserLoginOut()
            this.$router.push('/login')
        },
        remainDay(date_time) {
            let remainDay = dayjs(date_time).diff(dayjs(), 'day')
            return remainDay < 0 ? 0 : remainDay
        },
        dateFormatter(date_time) {
            if (date_time === undefined) {
                return ''
            }
            return moment(date_time).utcOffset(0).format('YYYY-MM-DD')
        }
    }
}
</script>

<style>
.custom-icon {
    width: 27px;
    height: 27px;
}
</style>
