import axios from "axios";
import VueAxios from "vue-axios";
import router from "@/router";
import store from "@/store";
import utils from "@/plugins/utils";

// Full config:  https://github.com/axios/axios#request-config
// axios.defaults.baseURL = process.env.baseURL || process.env.apiUrl || '';
// axios.defaults.headers.common['Authorization'] = AUTH_TOKEN;
// axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';

let config = {
  // baseURL: process.env.baseURL || process.env.apiUrl || ""
  // timeout: 60 * 1000, // Timeout
  // withCredentials: true, // Check cross-site Access-Control
};

const _axios = axios.create(config);

axios.interceptors.request.use(
  function (config) {
    // Do something before request is sent
    if (store.getters.token) {
      config.headers.Authorization = store.state.token;
    }
    return config;
  },
  function (error) {
    // Do something with request error
    return Promise.reject(error);
  }
);

// Add a response interceptor
axios.interceptors.response.use(
  function (response) {
    // add token into store when login
    if (
      response.config.url === "/api/login" &&
      response.headers.authorization
    ) {
      let _token = response.headers.authorization;
      let _username = response.data.data.username;
      let _role = response.data.data.role;
      let _expiration_date = response.data.data.expiration_date;
      store.commit("LOGIN", {
        token: _token,
        username: _username,
        role: _role,
        expiration_date: _expiration_date
      });
    }
    return response;
  },
  function (error) {
    if (error.response.status === 401) {
      utils.errorMsg("loginExpired");
      router.push("/login");
    } else if (error.response.status === 402){
      utils.errorMsg("trialInfo");
      router.push("/login");
    } else if (error.response.status === 403) {
      utils.errorMsg("loginInfo");
      router.push("/login");
    } else if (error.response.status === 403) {
      utils.errorMsg("用户名或密码错误");
      router.push("/login");
    }
    store.dispatch('UserLoginOut')
    return Promise.reject(error);
  }
);

export default app => {
  app.use(VueAxios, _axios);
};
