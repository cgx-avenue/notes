export default (app, t) => {
  const message = app.config.globalProperties.$message
  app.config.globalProperties.$success = (msg) => message({message: t(msg), type: 'success'})
  app.config.globalProperties.$warning = (msg) => message({ message: t(msg), type: 'warning'})
  app.config.globalProperties.$error = (msg) => message({ message: t(msg), type: 'error'})
}
