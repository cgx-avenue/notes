let vm = null;

const sendThis = _this => {
  vm = _this;
};

export default {
  sendThis,
  successMsg(msg) {
    vm.$success(msg);
  },
  warningMsg(msg) {
    vm.$warning(msg);
  },
  errorMsg(msg) {
    vm.$error(vm.$t(msg));
  },
  containsString(obj, str) {
    if (!str) {
      return true;
    }
    // id/level/time属性不参与比较
    for (let key in obj) {
      if (!Object.prototype.hasOwnProperty.call(obj, key)) {
        continue;
      }
      if (key.includes("id") || key.includes("level") || key.includes("time")) {
        continue;
      }
      let value = obj[key];
      if (typeof value === 'string' && value.toLowerCase().includes(str.toLowerCase())) {
        return true;
      }
    }
    return false;
  },
  containsStation(obj, str) {
    if (!str) {
      return true;
    }
    // id/level/time属性不参与比较
    for (let key in obj) {

      if (!key.includes("station")) {
        continue;
      }
      let value = obj[key];
      if (typeof value === 'string' && value.toLowerCase().includes(str.toLowerCase())) {
        return true;
      }
    }
    return false;
  },
};
