export default {
    stationManagement: 'Stationsverwaltung',
    faultManagement: 'Fehlermanagement',
    sampleManagement: 'Probenmanagement',
    diagnosticAlgorithm: 'Diagnosealgorithmus',
    faultCodes: 'Fehlercodes',
    graphicalReports: 'Grafische Berichte',
    searchPlaceholder: 'Bitte geben Sie Suchinhalt ein',
    login: 'Einloggen',
    logout: 'Abmelden',
    trialExpiration: 'Testablauf',
    trialRemaining: 'Verbleibende Testversion',
    days: 'Tage',
    switchLanguage: 'Sprache wechseln',
    userName: 'Benutzername',
    password: 'Passwort',
    loginSuccess: "Anmeldung erfolgreich"
}; 