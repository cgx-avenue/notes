import {apiService} from './ApiService'

export const getSamples = () => apiService({
  url: '/samples',
})

export const getSampleById = (id) => apiService({
  url: '/samples/' + id,
})

export const saveSample = (data) => apiService({
  method: 'post',
  url: '/samples',
  data: data
})

export const removeSample = (id) => apiService({
  method: 'delete',
  url: '/samples/' + id,
})

export const getSampleRmsById = (id) => apiService({
  url: '/samples/' + id + '/rms',
})

export const viewSampleRms = (data) => apiService({
  url: '/samples/view/rms',
  method: 'post',
  data: data
})

export const getSampleAlgorithms = () => apiService({
  url: '/samples/algorithms',
})

export const trainSamples = (schema_id) => apiService({
  url: '/samples/' + schema_id + '/train',
})

