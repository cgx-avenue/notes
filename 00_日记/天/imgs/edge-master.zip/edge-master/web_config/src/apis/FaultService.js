import {apiService} from './ApiService'

export const getFaults = () => apiService({
  url: '/faults',
})

export const confirmFault = (id) => apiService({
  method: 'post',
  url: '/faults/' + id + '/confirm',
})

export const misjudgmentFault = (id) => apiService({
  method: 'post',
  url: '/faults/' + id + '/misjudgment',
})


