import {apiService} from './ApiService'

export const scatterReport = (normalize,start, end, schemas) => apiService({
  method: 'post',
  url: '/reports/scatter',
  data: {
    normalize: normalize,
    start: start,
    end: end,
    schemas: schemas
  }
})

export const distributedReport = (start, end, schemas) => apiService({
  method: 'post',
  url: '/reports/distributed',
  data: {
    start: start,
    end: end,
    schemas: schemas
  }
})

export const trendReport = (schema, months, threshold) => apiService({
  method: 'post',
  url: '/reports/trend',
  data: {
    schema: schema,
    months: months,
    threshold: threshold
  }
})
