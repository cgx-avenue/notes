import {apiService} from './ApiService'

export const uploadData = (form) => apiService({
    method: 'post',
    url: '/schemas/upload',
    headers: { "Content-Type": "multipart/form-data" },
    data: form
})

export const getSchemas = () => apiService({
    url: '/schemas',
})

export const getSchemaById = (id) => apiService({
    url: '/schemas/' + id,
})

export const saveSchema = (data) => apiService({
    method: 'post',
    url: '/schemas',
    data: data
})

export const removeSchema = (id) => apiService({
    method: 'delete',
    url: '/schemas/' + id,
})

export const createTables = (id) => apiService({
    method: 'post',
    url: '/schemas/createTables',
    params: {id: id}
})

export const getComponentOptions = () => {
    return [{
        value: 'chain',
        label: '链条',
        icon: 'icon-liantiao'
    }, {
        value: 'motor',
        label: '电机',
        icon: 'icon-dianji'
    }, {
        value: 'axle',
        label: '轴',
        icon: 'icon-zhou'
    }, {
        value: 'bearing',
        label: '轴承',
        icon: 'icon-zhoucheng'
    }, {
        value: 'connectrod',
        label: '连接杆',
        icon: 'icon-locationfuzhi'
    }, {
        value: 'gearbox',
        label: '齿轮箱',
        icon: 'icon-gearbox'
    }, {
        value: 'pump',
        label: '泵',
        icon: 'icon-zhenkongbeng'
    }, {
        value: 'driverWheel',
        label: '驱动轮',
        icon: 'icon-qudonglunsongliao'
    }]
}

export const fmtComponent = (component) => {
    if (component) {
        return getComponentOptions().find(item => item.value === component).label
    }
}

export const getComponentIcon = (component) => {
    if (component) {
        return 'iconfont ' + getComponentOptions().find(item => item.value === component).icon
    }
}

export const getSensorOptions = () => {
    return [{
        value: 'mqtt',
        label: 'MQTT',
        color: 'danger',
        protocol: 'MQTT'
    }, {
        value: 'modbustcp',
        label: 'MODBUSTCP',
        color: 'warning',
        protocol: 'MODBUSTCP'
    }, {
        value: 'opcua',
        label: 'OPCUA',
        color: 'primary',
        protocol: 'OPCUA'
    }, {
        value: 's7',
        label: 'S7',
        color: 'primary',
        protocol: 'S7'
    }]
}

