// 公共的axios文件
import axios from 'axios'
//import { message } from '@/utils'

export function apiService(options) {
  let config = {
    method: options.method || 'get',
    url: '/api' + options.url,
    params: options.params || {},
    data: options.data || {},
    headers: options.headers || {},
  }
  return axios(config).catch(e => {
    // message({
    //   message: e.response.status + ': ' + e.response.data.message,
    //   type: 'error'
    // })
    console.log(e.response.status, 'error----', e.response.data.message)
  })
}
