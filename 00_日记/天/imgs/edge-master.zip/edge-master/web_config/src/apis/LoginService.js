import {apiService} from './ApiService'

export const login = (username, password) => apiService({
  method: 'post',
  url: '/login',
  data: {username: username, password: password}
})

