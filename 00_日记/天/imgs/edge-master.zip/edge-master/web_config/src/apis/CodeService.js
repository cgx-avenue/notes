import {apiService} from './ApiService'

export const getCodes = (code) => apiService({
  url: '/codes',
  params: {code: code}
})

export const getCodeByCode = (code) => apiService({
  url: '/codes/' + code,
})

export const saveCode = (data) => apiService({
  method: 'post',
  url: '/codes',
  data: data
})

export const removeCode = (code) => apiService({
  method: 'delete',
  url: '/codes/' + code,
})
