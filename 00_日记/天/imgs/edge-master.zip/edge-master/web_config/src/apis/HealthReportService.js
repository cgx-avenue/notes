import { apiService } from './ApiService'


export const getAllHealth = () => apiService({
    url: '/health/all',
})

export const uploadImage = (form) => apiService({
    method: 'post',
    url: '/health/upload',
    headers: { "Content-Type": "multipart/form-data" },
    data: form
})

export const getStationImage = (station_name) => apiService({
    url: '/health/' + station_name,
})

export const healthTrend = (tableName, threshold) => apiService({
    method: 'post',
    url: '/health/trend',
    data: {
        table_name: tableName,
        threshold: threshold
    }
})

export const healthDistributed = (tableName) => apiService({
    method: 'post',
    url: '/health/distributed',
    data: {
        table_name: tableName,
    }
})


export const healthCompare = (tableName) => apiService({
    method: 'post',
    url: '/health/compare',
    data: {
        table_name: tableName
    }
})

export const healthCorrelation = (tableName) => apiService({
    method: 'post',
    url: '/health/correlation',
    data: {
        table_name: tableName
    }
})

