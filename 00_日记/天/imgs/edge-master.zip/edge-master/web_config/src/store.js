import { createStore } from 'vuex'

const store = createStore({

  state: {
    token: localStorage.getItem('token') || null,
    username: localStorage.getItem('username') || null,
    role: localStorage.getItem('role') || null,
    expiration_date: localStorage.getItem('expiration_date') || null,
    language: localStorage.getItem('language') || 'zh-cn'
  },
  getters: {
    token(state) {
      return state.token
    },
    username(state) {
      return state.username
    },
    role(state) {
      return state.role
    },
    expiration_date(state) {
      return state.expiration_date
    },
    language: (state) => state.language
  },
  mutations: {
    LOGIN: (state, data) => {
      state.token = data.token
      state.username = data.username
      state.role = data.role
      state.expiration_date = data.expiration_date
      localStorage.setItem('token', data.token)
      localStorage.setItem('username', data.username)
      localStorage.setItem('role', data.role)
      localStorage.setItem('expiration_date', data.expiration_date)
    },
    LOGOUT: (state) => {
      state.token = null
      state.username = null
      state.role = null
      state.expiration_date = null
      localStorage.removeItem('token')
      localStorage.removeItem('username')
      localStorage.removeItem('role')
      localStorage.removeItem('expiration_date')
    },
    setLanguage(state, language) {
      state.language = language;
      localStorage.setItem('language', language);
    }
  },
  actions: {
    UserLogin({ commit }, data) {
      commit('LOGIN', data)
    },
    UserLoginOut({ commit }, data) {
      commit('LOGOUT', data)
    },
    UpdateLanguage({ commit }, language) {
      commit('setLanguage', language);
    }
  },
})

export default store
