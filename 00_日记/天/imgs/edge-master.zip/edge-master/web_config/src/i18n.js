import { createI18n } from 'vue-i18n'
import enMessages from './locales/en.js'
import zhCnMessages from './locales/zh-cn.js'

// 获取当前语言，默认从 localStorage 取，没有的话使用 'zh-cn'
const language = localStorage.getItem('language') || 'zh-cn';

const messages = {
    'en': enMessages,
    'zh-cn': zhCnMessages,
}

const i18n = createI18n({
    locale: language, // 设置默认语言
    fallbackLocale: 'en',
    messages
})

export default i18n
