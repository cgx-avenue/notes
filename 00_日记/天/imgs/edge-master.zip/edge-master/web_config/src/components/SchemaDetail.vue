<template>
    <el-page-header @back="this.$router.go(-1)" :content="$t('schemaDetail')" style="margin: 20px"> </el-page-header>
    <el-form ref="form" :model="formData" :rules="rules" size="medium" class="schema-detail-form" inline>
        <el-form-item :label="$t('station')" prop="station">
            <el-input v-model="formData.station"></el-input>
        </el-form-item>
        <el-form-item label="Host" prop="host">
            <el-input v-model="formData.host"></el-input>
        </el-form-item>
        <el-form-item :label="$t('component')" prop="component">
            <el-select v-model="formData.component" :placeholder="$t('select')">
                <el-option v-for="item in componentOptions" :key="item.value" :label="$t(item.value)" :value="item.value"> </el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="Port" prop="port">
            <el-input v-model="formData.port"></el-input>
        </el-form-item>
        <el-form-item :label="$t('sensor')" prop="sensor">
            <el-col>
                <el-select v-model="formData.sensor" :placeholder="$t('select')" :change="handleSelectSensor()">
                    <el-option v-for="item in sensorOptions" :key="item.value" :label="item.label" :value="item.value"> </el-option>
                </el-select>
            </el-col>
            <el-col class="line" :span="2">&nbsp;</el-col>
            <!-- <el-col>
        <el-input v-model="formData.protocol" disabled></el-input>
      </el-col> -->
        </el-form-item>
        <el-form-item label="Topic">
            <el-input v-model="formData.topic" disabled></el-input>
        </el-form-item>
        <el-form-item :label="$t('adaptive_thresholds')">
            <template #label>
                <el-tooltip placement="top">
                    <template #content> {{ $t('adaptive_thresholds_info') }} </template>
                    <span>
                        {{ $t('adaptive_thresholds') }}
                        <i class="el-icon-question" style="color: #0cc"></i>
                    </span>
                </el-tooltip>
            </template>
            <el-switch v-model="formData.dynamic_threshold"></el-switch>
        </el-form-item>
        <el-divider></el-divider>
        <div class="feature-block">
            <el-row class="feature-block-header">
                <el-col :span="4">{{ $t('feature') }}</el-col>
                <el-col :span="5">{{ $t('address') }}</el-col>
                <el-col :span="3">{{ $t('middle_threshold') }}</el-col>
                <el-col :span="4">{{ $t('middle_warning_code') }}</el-col>
                <el-col :span="3">{{ $t('high_threshold') }}</el-col>
                <el-col :span="4">{{ $t('high_warning_code') }}</el-col>
                <el-col :span="1">
                    <el-button @click="addFeature" type="primary" size="small">{{ $t('add') }}</el-button>
                </el-col>
            </el-row>
            <el-row v-for="(feature, index) in formData.features" v-bind:key="index">
                <el-col :span="4">
                    <el-input :placeholder="$t('feature')" v-model="feature.feature"></el-input>
                </el-col>
                <el-col :span="5">
                    <el-input :placeholder="$t('address')" v-model="feature.address"></el-input>
                </el-col>
                <el-col :span="3">
                    <el-input :placeholder="$t('middle_threshold')" v-model="feature.middle" :disabled="formData.dynamic_threshold" type="number" class="no-number"> </el-input>
                </el-col>
                <el-col :span="4">
                    <el-autocomplete class="error-select-warning" value-key="code" v-model="feature.middle_code" :fetch-suggestions="searchMiddleCode" :placeholder="$t('code_tip')">
                        <template #default="scope">
                            <span style="float: left; color: #e6a23c" v-if="scope.item.level === 'warning'">
                                {{ scope.item.code }}
                            </span>
                            <span style="float: left; color: #f56c6c" v-if="scope.item.level === 'danger'">
                                {{ scope.item.code }}
                            </span>
                            <span style="float: right; color: #8492a6; font-size: 10px">{{ scope.item.name }}</span>
                        </template>
                    </el-autocomplete>
                </el-col>
                <el-col :span="3">
                    <el-input :placeholder="$t('high_threshold')" v-model="feature.high" :disabled="formData.dynamic_threshold" type="number" class="no-number"> </el-input>
                </el-col>
                <el-col :span="4">
                    <el-autocomplete class="error-select-danger" value-key="code" v-model="feature.high_code" :fetch-suggestions="searchHighCode" :placeholder="$t('code_tip')">
                        <template #default="scope">
                            <span style="float: left; color: #e6a23c" v-if="scope.item.level === 'warning'">
                                {{ scope.item.code }}
                            </span>
                            <span style="float: left; color: #f56c6c" v-if="scope.item.level === 'danger'">
                                {{ scope.item.code }}
                            </span>
                            <span style="float: right; color: #8492a6; font-size: 10px">{{ scope.item.name }}</span>
                        </template>
                    </el-autocomplete>
                </el-col>
                <el-col :span="1">
                    <el-button type="danger" size="small" @click="formData.features.splice(index, 1)"> {{ $t('delete') }} </el-button>
                </el-col>
            </el-row>
            <el-form-item size="large">
                <el-button type="primary" @click="submitForm('form')">{{ $t('save') }}</el-button>
                <el-button @click="this.$router.go(-1)">{{ $t('back') }}</el-button>
            </el-form-item>
        </div>
    </el-form>
</template>

<script>
import { getSchemaById, saveSchema, getCodes, getComponentOptions, getSensorOptions } from '@/apis'
import { ref } from 'vue'

export default {
    name: 'SchemaDetail',
    data() {
        return {
            formData: {},
            schemas: ref([]),
            codes: [],
            componentOptions: getComponentOptions(),
            sensorOptions: getSensorOptions(),
            rules: {
                station: [{ required: true, message: this.$t('require_station'), trigger: 'blur' }],
                component: [{ required: true, message: this.$t('require_component'), trigger: 'blur' }],
                sensor: [{ required: true, message: this.$t('require_sensor'), trigger: 'change' }],
                host: [{ required: true, message: this.$t('require_host'), trigger: 'blur' }],
                port: [{ required: true, message: this.$t('require_port'), trigger: 'blur' }]
            }
        }
    },
    computed: {},
    methods: {
        fetchData() {
            this.formData.id = this.$route.params.id
            let copyMode = this.formData.id.startsWith('copy_')
            if (copyMode) {
                this.formData.id = this.formData.id.substring(5)
            }
            if (this.formData.id !== 'new') {
                getSchemaById(this.formData.id).then(res => {
                    if (res.data.success) {
                        this.formData = res.data.data
                        if (copyMode) {
                            this.formData.id = null
                            this.formData.topic = null
                            this.formData.accuracy = null
                            this.formData.algorithm = null
                        }
                    } else {
                        this.$error(res.data.msg)
                    }
                })
            } else {
                this.formData.id = null
                this.formData.features = [{ feature: 'timestamp' }, { feature: 'vibRms' }]
            }
        },
        submitForm(formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.saveData()
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        },
        saveData() {
            saveSchema(this.formData).then(res => {
                if (res.data.success) {
                    this.$success(res.data.msg)
                    this.$router.push('/schemas')
                } else {
                    this.$error(res.data.msg)
                }
            })
        },
        addFeature() {
            this.formData.features.push({})
        },
        loadCodes() {
            getCodes().then(res => {
                if (res.data.success) {
                    this.codes = res.data.data
                } else {
                    this.$error(res.data.msg)
                }
            })
        },
        searchCode(queryString, cb, level) {
            let results = this.codes
            if (level) {
                results = results.filter(result => result.level.toLowerCase() === level.toLowerCase())
            }
            if (queryString) {
                results = results.filter(result => result.code.toLowerCase().includes(queryString.toLowerCase()))
            }
            cb(results)
        },
        searchMiddleCode(queryString, cb) {
            this.searchCode(queryString, cb, 'warning')
        },
        searchHighCode(queryString, cb) {
            this.searchCode(queryString, cb, 'danger')
        },
        handleSelectSensor() {
            let sensors = getSensorOptions()
            if (sensors) {
                let sensor = sensors.find(item => item.value === this.formData.sensor)
                if (sensor) {
                    this.formData.protocol = sensor.protocol
                }
            }
        }
    },
    created() {
        this.fetchData()
        this.loadCodes()
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
.error-select-warning input {
    color: #e6a23c;
}

.error-select-danger input {
    color: #f56c6c;
}

.schema-detail-form label {
    width: 120px;
    color: #99a9bf;
}

.schema-detail-form .el-form-item {
    width: 45%;
}

.schema-detail-form .el-form-item__content {
    width: 75%;
}

.feature-block {
    margin: 10px;
}

.feature-block .el-input {
    width: 90%;
    padding-bottom: 10px;
}

.feature-block-header {
    color: #99a9bf;
    line-height: 36px;
    font-size: 14px;
    padding-bottom: 12px;
}

.el-autocomplete {
    width: 100%;
}
</style>
