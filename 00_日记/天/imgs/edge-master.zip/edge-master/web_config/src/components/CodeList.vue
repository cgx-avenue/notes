<template>
    <el-table :data="tableData" stripe border size="small" v-loading="loading" style="width: 100%">
        <el-table-column type="expand">
            <template #default="props">
                <p v-html="props.row.suggestion"></p>
            </template>
        </el-table-column>
        <el-table-column :label="$t('code')" :filters="codeFilters" :filter-method="codeFilter">
            <template #default="scope">
                <el-tag disable-transitions :type="scope.row.level">{{ scope.row.code }}</el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="name" :label="$t('name')"></el-table-column>
        <el-table-column prop="description" :label="$t('description')"></el-table-column>
        <el-table-column min-width="60%">
            <template #header>
                <el-button type="primary" size="mini" @click="this.$router.push({ path: '/codes/new' })">{{$t('add')}}</el-button>
            </template>
            <template #default="scope">
                <el-button size="mini" @click="this.$router.push({ path: '/codes/' + scope.row.code })">{{$t('edit')}}</el-button>
                <el-popconfirm :confirm-button-text="$t('confirm')" :cancel-button-text="$t('cancel')" :title="$t('confirmDelete')" @confirm="removeData(scope.row.code)">
                    <template #reference>
                        <el-button size="mini" type="danger">{{$t('delete')}}</el-button>
                    </template>
                </el-popconfirm>
            </template>
        </el-table-column>
    </el-table>
</template>

<script>
import { getCodes, removeCode } from '@/apis'
import utils from '@/plugins/utils'

export default {
    name: 'CodeList',
    props: {},
    data() {
        return {
            tempData: [],
            timer: null,
            tableData: [],
            loading: true,
        }
    },
    watch: {
        '$root.searchInput': function (newValue) {
            clearTimeout(this.timer) //清除延迟执行
            this.timer = setTimeout(() => {
                //设置延迟执行
                this.tableData = this.tempData.filter(item => utils.containsString(item, newValue))
            }, 500)
        }
    },
    computed: {
        codeFilters() {
            // 在这里定义你的过滤器数组
            return [
                { text: this.$t('health'), value: 'success' },
                { text: this.$t('middle_fault'), value: 'warning' },
                { text: this.$t('high_fault'), value: 'danger' }
            ]
        }
    },
    methods: {
        removeData(code) {
            removeCode(code).then(res => {
                if (res.data.success) {
                    this.$success(res.data.msg)
                    this.fetchData()
                } else {
                    this.$error(res.data.msg)
                }
            })
        },
        fetchData() {
            this.loading = true
            getCodes(this.$route.query.code).then(res => {
                if (res.data.success) {
                    this.tempData = res.data.data
                    this.tableData = this.tempData
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },
        codeFilter(value, row) {
            return row.level === value
        }
    },
    created() {
        this.fetchData()
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style></style>
