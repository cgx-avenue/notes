<template>
    <el-page-header @back="this.$router.go(-1)" :content="$t('faultDetail')" style="margin: 20px"> </el-page-header>
    <el-form ref="form" :model="formData" :rules="rules" size="medium" class="code-detail-form">
        <el-form-item :label="$t('faultLevel')" prop="level">
            <el-select v-model="formData.level" :placeholder="$t('select')" @change="handleSelectCodeLevel">
                <el-option v-for="item in levelOptions" :key="item.pre" :label="$t(item.value)" :value="item.value"> </el-option>
            </el-select>
        </el-form-item>
        <el-form-item :label="$t('faultCode')" prop="last_code" inline v-bind:class="errorSelectClass">
            <el-col>
                <el-input v-model="formData.pre_code" disabled></el-input>
            </el-col>
            <el-col class="line" :span="2">&nbsp;</el-col>
            <el-col>
                <el-input v-model="formData.last_code" :placeholder="$t('last2Code')" maxlength="2"></el-input>
            </el-col>
        </el-form-item>
        <el-form-item :label="$t('faultName')" prop="name">
            <el-input v-model="formData.name" maxlength="100" :placeholder="$t('enterCodeName')"></el-input>
        </el-form-item>
        <el-form-item :label="$t('faultDescription')" prop="description">
            <el-input type="textarea" :rows="3" v-model="formData.description" :placeholder="$t('enterCodeDescription')"></el-input>
        </el-form-item>
        <el-form-item :label="$t('faultSuggestion')" prop="suggestion" style="height: 200px">
            <div style="width: 100%; height: 75%">
                <QuillEditor theme="snow" :content="formData.suggestion ? formData.suggestion : ''" contentType="html" toolbar="essential" @update:content="setContent" />
            </div>
        </el-form-item>
        <el-form-item size="large" style="margin-left: 80px">
            <el-button type="primary" @click="submitForm('form')">{{ $t('save') }}</el-button>
            <el-button @click="this.$router.go(-1)">{{ $t('back') }}</el-button>
        </el-form-item>
    </el-form>
</template>

<script>
import { getCodeByCode, saveCode } from '@/apis'

export default {
    name: 'CodeDetail',

    data() {
        const validateLastCode = (rule, value, callback) => {
            if (/^\d{2}$/.test(value)) {
                validateUnique(rule, value, callback)
            } else {
                callback(new Error(this.$t('input2Digits')))
            }
        }
        const validateUnique = (rule, value, callback) => {
            if (this.formData.code == this.$route.params.code) {
                callback()
            } else {
                getCodeByCode(this.formData.code).then(res => {
                    if (res.data.success && res.data.data) {
                        callback(new Error(this.$t('codeDuplication')))
                    } else {
                        callback()
                    }
                })
            }
        }
        return {
            formData: {},
            codes: [],
            levelOptions: [
                { value: 'success', label: '健康', pre: '10' },
                { value: 'warning', label: '中级故障', pre: '11' },
                { value: 'danger', label: '高级故障', pre: '12' }
            ],
            rules: {
                level: [{ required: true, message: this.$t('selectFaultLevel'), trigger: 'change' }],
                last_code: [{ validator: validateLastCode, required: true, trigger: 'blur' }],
                name: [{ required: true, message: this.$t('inputFaultName'), trigger: 'blur' }],
                description: [{ required: true, message: this.$t('inputFaultDescription'), trigger: 'blur' }]
            }
        }
    },
    watch: {
        'formData.last_code'(val, oldVal) {
            if (val != oldVal) {
                this.formData.code = this.formData.pre_code + val
            }
        },
        immediate: true
    },
    computed: {
        errorSelectClass() {
            return 'error-select-' + this.formData.level
        }
    },
    methods: {
        setContent(content) {
            this.formData.suggestion = content
        },
        handleSelectCodeLevel(value) {
            if (value) {
                this.formData.pre_code = this.levelOptions.find(item => item.value === value).pre
            }
        },
        fetchData() {
            let code = this.$route.params.code

            if (code !== 'new') {
                getCodeByCode(code).then(res => {
                    if (res.data.success) {
                        this.formData = res.data.data
                        this.formData.pre_code = this.formData.code.substr(0, 2)
                        this.formData.last_code = this.formData.code.substr(-2)
                    } else {
                        this.$error(res.data.msg)
                    }
                })
            } else {
                this.formData.code = null
            }
        },
        submitForm(formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.saveData()
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        },
        saveData() {
            let code_reg = {
                id: this.formData.id,
                code: this.formData.code,
                name: this.formData.name,
                level: this.formData.level,
                description: this.formData.description,
                suggestion: this.formData.suggestion
            }
            saveCode(code_reg).then(res => {
                if (res && res.data.success) {
                    this.$success(res.data.msg)
                    this.$router.push('/codes')
                } else {
                    this.$error(res.data.msg)
                }
            })
        },
        searchCode(queryString, cb, level) {
            let results = this.codes
            if (level) {
                results = results.filter(result => result.level.toLowerCase() === level.toLowerCase())
            }
            if (queryString) {
                results = results.filter(result => result.code.toLowerCase().includes(queryString.toLowerCase()))
            }
            cb(results)
        },
        searchMiddleCode(queryString, cb) {
            this.searchCode(queryString, cb, 'warning')
        },
        searchHighCode(queryString, cb) {
            this.searchCode(queryString, cb, 'danger')
        }
    },
    created() {
        this.fetchData()
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
.error-select-success input {
    color: #67c23a;
}

.error-select-warning input {
    color: #e6a23c;
}

.error-select-danger input {
    color: #f56c6c;
}

.code-detail-form label {
    width: 120px;
    color: #99a9bf;
}

.code-detail-form .el-form-item {
    width: 45%;
}
</style>
