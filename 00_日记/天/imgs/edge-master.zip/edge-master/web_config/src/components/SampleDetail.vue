<template>
    <el-page-header @back="this.$router.go(-1)" :content="$t('sampleDetail')" style="margin: 20px"> </el-page-header>
    <el-form ref="form" v-loading="loading" :model="formData" :rules="rules" size="median" class="sample-detail-form">
        <!--    <el-form-item label="id" prop="id">-->
        <!--      {{ formData.id }}-->
        <!--    </el-form-item>-->
        <el-form-item :label="$t('station')" prop="station">
            <el-col>
                <el-autocomplete class="inline-input" value-key="value" v-model="formData.station" :fetch-suggestions="searchSchema" :placeholder="$t('require_station')" @select="handleSelectSchema">
                    <template #default="scope">
                        <span style="float: left">{{ scope.item.station }}</span>
                        <span style="float: right; color: #8492a6; font-size: 13px">{{ $t(scope.item.component) }}</span>
                    </template>
                </el-autocomplete>
            </el-col>
            <el-col class="line" :span="2">&nbsp;</el-col>
            <el-col>
                <el-input :value="$t(formData.component == null ? '' : formData.component)" disabled></el-input>
            </el-col>
        </el-form-item>
        <el-form-item :label="$t('sampleLevel')" prop="code_level">
            <el-select v-model="formData.code_level" :placeholder="$t('requireSampleLevel')" @change="handleSelectCodeLevel">
                <el-option v-for="item in codeLevelOptions" :key="item.value" :label="$t(item.value)" :value="item.value"> </el-option>
            </el-select>
        </el-form-item>
        <el-form-item :label="$t('sampleCode')" prop="code">
            <el-col>
                <el-select style="width: 95%" value-key="value" v-model="formData.code" filterable :placeholder="$t('requireCode')" @change="handleSelectCode">
                    <el-option v-for="item in codes" :key="item.code" :label="item.code" :value="item.code">
                        <span style="float: left; color: #67c23a" v-if="item.level === 'success'">
                            {{ item.code }}
                        </span>
                        <span style="float: left; color: #e6a23c" v-if="item.level === 'warning'">
                            {{ item.code }}
                        </span>
                        <span style="float: left; color: #f56c6c" v-if="item.level === 'danger'">
                            {{ item.code }}
                        </span>
                        <span style="float: right; color: #8492a6; font-size: 10px">{{ item.name }}</span>
                    </el-option>
                </el-select>
            </el-col>
            <el-col class="line" :span="2">&nbsp;</el-col>
            <el-col>
                <el-input v-model="formData.code_name" disabled></el-input>
            </el-col>
        </el-form-item>
        <el-form-item :label="$t('sampleTime')" prop="timeRange">
            <el-date-picker v-model="formData.timeRange" @change="pickTimeRange()" type="datetimerange" :range-separator="$t('to')" :start-placeholder="$t('startTime')" :end-placeholder="$t('endTime')"> </el-date-picker>
        </el-form-item>
        <el-form-item :label="$t('description')" prop="description">
            <el-input type="textarea" :rows="3" :placeholder="$t('enterDesription')" v-model="formData.description"> </el-input>
        </el-form-item>
        <el-form-item size="large" style="margin-left: 80px">
            <el-button type="primary" @click="openDialog" plain>{{ $t('previewView') }}</el-button>
            <el-button type="primary" @click="submitForm('form')">{{ $t('save') }}</el-button>
            <el-button @click="this.$router.go(-1)">{{ $t('back') }}</el-button>
        </el-form-item>
    </el-form>
    <VibViewDialog :title="dialog.title" :id="dialog.id" :schemaId="dialog.schemaId" v-model:visible="dialog.visible" :startTime="dialog.startTime" :endTime="dialog.endTime" @changeDatetime="handleDatetime"> </VibViewDialog>
</template>

<script>
import { getSampleById, saveSample, getSchemas, getCodes } from '@/apis'
import { ref } from 'vue'
import VibViewDialog from '@c/VibViewDialog'

export default {
    name: 'SampleDetail',
    components: { VibViewDialog },
    data() {
        return {
            formData: {},
            schemas: ref([]),
            codes: [],
            // timeRange: [],
            codeLevelOptions: [
                {
                    value: 'success',
                    label: '健康'
                },
                {
                    value: 'warning',
                    label: '中级故障'
                },
                {
                    value: 'danger',
                    label: '高级故障'
                }
            ],
            rules: {
                station: [{ required: true, message: this.$t('selectStation'), trigger: 'change' }],
                code: [{ required: true, message: this.$t('selectCode'), trigger: 'change' }],
                timeRange: [{ required: true, message: this.$t('selectSampleTime'), trigger: 'change' }]
            },
            loading: false,
            dialog: {}
        }
    },
    computed: {
        // componentFormatted() {
        //     return this.formData.component
        // },
        errorSelectClass() {
            return 'error-select-' + this.formData.code_level
        }
    },
    methods: {
        handleDatetime(value) {
            if (value.length > 0) {
                this.formData.timeRange = value
                this.pickTimeRange()
            }
        },
        formatBackTime(time) {
            const format_time = new Date(time)
            format_time.setTime(format_time.getTime() - 8 * 60 * 60 * 1000)

            return format_time
        },
        formatPostTime(time) {
            const format_time = new Date(time)
            format_time.setTime(format_time.getTime() + 8 * 60 * 60 * 1000)

            return format_time
        },
        fetchData() {
            this.formData.id = this.$route.params.id
            if (this.formData.id !== 'new') {
                getSampleById(this.formData.id).then(res => {
                    if (res.data.success) {
                        this.formData = res.data.data
                        this.formData.start_time = this.formatBackTime(this.formData.start_time)
                        this.formData.end_time = this.formatBackTime(this.formData.end_time)
                        this.formData.timeRange = [this.formData.start_time, this.formData.end_time]
                    } else {
                        this.$error(res.data.msg)
                    }
                })
            } else {
                this.formData.id = null
            }
        },
        loadSchemas() {
            getSchemas().then(res => {
                if (res.data.success) {
                    this.schemas = res.data.data
                } else {
                    this.$error(res.data.msg)
                }
            })
        },
        loadCodes() {
            getCodes().then(res => {
                if (res.data.success) {
                    this.codes = res.data.data
                } else {
                    this.$error(res.data.msg)
                }
            })
        },
        searchSchema(queryString, cb) {
            let results = this.schemas
            if (queryString) {
                results = results.filter(result => result.station.toLowerCase().indexOf(queryString.toLowerCase()) >= 0)
            }
            cb(results)
        },
        searchCode(queryString, cb) {
            let results = this.codes
            if (this.formData.code_level) {
                results = results.filter(result => result.level.toLowerCase() === this.formData.code_level.toLowerCase())
            }
            if (queryString) {
                results = results.filter(result => result.code.toLowerCase().includes(queryString.toLowerCase()))
            }
            cb(results)
        },
        submitForm(formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.saveData(true)
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        },
        saveData(goBack) {
            let dataToSave = { ...this.formData }
            dataToSave.start_time = this.formatPostTime(dataToSave.start_time)
            dataToSave.end_time = this.formatPostTime(dataToSave.end_time)
            delete dataToSave.timeRange
            saveSample(dataToSave).then(res => {
                if (res.data.success) {
                    this.$success(res.data.msg)
                    if (goBack) {
                        this.$router.push('/samples')
                    }
                } else {
                    this.$error(res.data.msg)
                }
            })
        },
        handleSelectSchema(item) {
            this.formData.station = item.station
            this.formData.component = item.component
            this.formData.schema_id = item.id
        },
        handleSelectCode(value) {
            let item = this.codes.find(item => item.code === value)
            this.formData.code = item.code
            this.formData.code_name = item.name
            this.formData.code_level = item.level
            console.log(item, this.formData)
        },
        handleSelectCodeLevel(level) {
            if (this.formData.code) {
                let code = this.codes.find(item => item.code === this.formData.code)
                if (!code) {
                    this.formData.code = null
                } else if (code.level !== level) {
                    this.formData.code = null
                }
            }
        },
        pickTimeRange() {
            this.formData.start_time = this.formData.timeRange[0]
            this.formData.end_time = this.formData.timeRange[1]
        },
        openDialog() {
            this.$refs['form'].validate(valid => {
                if (valid) {
                    this.dialog.schemaId = this.formData.schema_id
                    this.dialog.title = this.formData.station + ' ' + this.$t(this.formData.component) + ' - ' + this.formData.code + ' ' + this.formData.code_name
                    this.dialog.startTime = this.formatPostTime(this.formData.start_time)
                    this.dialog.endTime = this.formatPostTime(this.formData.end_time)
                    this.dialog.visible = true
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        }
    },
    created() {
        this.fetchData()
        this.loadSchemas()
        this.loadCodes()
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
.error-select-success input {
    color: #67c23a;
}

.error-select-warning input {
    color: #e6a23c;
}

.error-select-danger input {
    color: #f56c6c;
}

.el-autocomplete-suggestion li {
    padding: 0 10px !important;
}

.sample-detail-form label {
    width: 120px;
    color: #99a9bf;
}

.sample-detail-form .el-form-item {
    width: 45%;
}

.sample-detail-form .el-form-item__content {
    width: 90%;
}

.sample-detail-form .el-textarea {
    width: 81%;
}

.sample-detail-form .el-select {
    width: 36%;
}
</style>
