<template>
    <div class="login-block">
        <el-form ref="ruleFormRef" :model="formData" status-icon :rules="rules" label-width="120px" class="demo-ruleForm">
            <el-form-item>
                <el-image :src="require('../assets/images/logo-transparent.png')"></el-image>
            </el-form-item>
            <el-form-item :label="$t('userName')" prop="username">
                <el-input v-model="formData.username" />
            </el-form-item>
            <el-form-item :label="$t('password')" prop="password">
                <el-input v-model="formData.password" type="password" @keyup.enter="login()" autocomplete="off" />
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="login()">{{ $t('login') }}</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>
import { login } from '@/apis'
export default {
    name: 'Login',
    props: {},
    data() {
        return {
            formData: {
                username: '',
                password: ''
            },
            rules: {
                username: [{ required: true, message: this.$t('inputUser'), trigger: 'blur' }],
                password: [{ required: true, message: this.$t('inputPassword'), trigger: 'blur' }]
            }
        }
    },
    watch: {},
    methods: {
        login() {
            this.$refs.ruleFormRef.validate(valid => {
                if (valid) {
                    login(this.formData.username, this.formData.password).then(res => {
                        if (res.data.success) {
                            this.$success(this.$t('loginSuccess'))
                            this.$router.push('/schemas')
                        } else {
                            this.$error(res.data.msg)
                        }
                    })
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        }
    },
    created() {}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
.login-block {
    width: 450px;
    margin: 0 auto;
}
</style>
