<template>
    <el-table :data="tableData" stripe border v-loading="loading" style="width: 100%">
        <el-table-column prop="station" :label="$t('station')"></el-table-column>
        <el-table-column prop="component" :label="$t('component')">
            <template #default="scope">
                <i v-bind:class="getComponentIcon(scope.row.component)"></i>
                {{ $t(scope.row.component) }}
            </template>
        </el-table-column>
        <el-table-column prop="sensor" :label="$t('sensor')">
            <template #default="scope">
                <el-tag disable-transitions :type="getSensorColor(scope.row.sensor)">{{ fmtSensor(scope.row.sensor) }}</el-tag>
            </template>
        </el-table-column>
        <!--    <el-table-column prop="enable_threshold" label="开启阈值报警">-->
        <!--      <template #default="scope">-->
        <!--        <el-checkbox v-model="scope.row.enable_threshold" disabled></el-checkbox>-->
        <!--      </template>-->
        <!--    </el-table-column>-->
        <el-table-column prop="algorithm" :label="$t('algorithm')">
            <template #default="scope">
                <el-select v-model="scope.row.algorithm" placeholder="请选择" clearable="true" @change="handleSelectAlgorithm(scope.row)">
                    <el-option v-for="item in algorithmOptions" :key="item.value" :label="$t(item.value)" :value="item.value"> </el-option>
                </el-select>
            </template>
        </el-table-column>
        <el-table-column prop="accuracy">
            <template #header>
                <el-tooltip placement="top">
                    <template #content>
                        {{ $t('accuracyInfo') }}
                    </template>
                    <span>{{ $t('accuracy') }} <i class="el-icon-question" style="color: #0cc"></i></span>
                </el-tooltip>
            </template>
            <template #default="scope">
                {{
                    this.$math
                        .chain(scope.row.accuracy == null ? 0 : scope.row.accuracy)
                        .multiply(this.$math.bignumber(100))
                        .round(2)
                        .done()
                }}%
                <el-button size="mini" type="primary" @click="trainSamples(scope.row.id)">{{ $t('recalculate') }}</el-button>
            </template>
        </el-table-column>
    </el-table>
</template>

<script>
import { getSchemas, getComponentIcon, getSensorOptions, saveSchema, getSampleAlgorithms, trainSamples } from '@/apis'

export default {
    name: 'DiagnosisList',
    props: {},
    data() {
        return {
            tableData: [],
            loading: true,
            algorithmOptions: []
        }
    },
    computed: {},
    methods: {
        fetchData() {
            this.loading = true
            getSchemas().then(res => {
                if (res.data.success) {
                    this.tableData = res.data.data
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },
        getOptions() {
            getSampleAlgorithms().then(res => {
                if (res.data.success) {
                    this.algorithmOptions = res.data.data
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },
        trainSamples(schemaId) {
            this.loading = true
            trainSamples(schemaId).then(res => {
                if (res.data.success) {
                    this.$success(res.data.msg)
                    this.fetchData()
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },

        getComponentIcon(cellValue) {
            return getComponentIcon(cellValue)
        },
        getSensorColor(value) {
            if (value) {
                return getSensorOptions().find(item => item.value === value).color
            }
        },
        fmtSensor(value) {
            if (value) {
                return getSensorOptions().find(item => item.value === value).label
            }
        },
        handleSelectAlgorithm(item) {
            saveSchema(item).then(res => {
                if (res.data.success) {
                    this.$success(res.data.msg)
                    this.fetchData()
                } else {
                    this.$error(res.data.msg)
                }
            })
        }
    },
    created() {
        this.fetchData()
        this.getOptions()
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style></style>
