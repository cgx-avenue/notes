<template>
    <el-table :data="devices" :show-header="false" stripe border v-loading="loading" style="width: 100%"
        :default-expand-all="true">
        <el-table-column type="expand">
            <template #default="props">
                <el-table :data="props.row.components" style="width: 100%" :show-header="false">
                    <el-table-column max-width="35%" prop="component_name"></el-table-column>
                    <el-table-column max-width="35%" prop="alarm_code">
                        <template #default="scope">
                            <el-tag :type="getComponentStatus(scope.row.alarm_code)">{{
                                fmtComponentHealth(scope.row.alarm_code) }}</el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column prop="health_score">
                        <template #default="scope">
                            <div v-if="scope.row.has_fault">
                                <el-tag type="danger">存在未处理的报警</el-tag>
                            </div>
                            <span :style="{ color: getHealthScoreColor(scope.row.alarm_code) }"> {{
                                fmtComponentScore(scope.row) }}% </span>
                        </template>
                    </el-table-column>
                </el-table>
            </template>
        </el-table-column>
        <el-table-column prop="station_name" min-width="145%">
            <template #default="scope">
                <span>监测设备：{{ scope.row.station_name }}</span>
                <span v-if="scope.row.image_data" @click="openImageDialog(scope.row)">
                    <el-icon class="icon-class">
                        <PictureFilled />
                    </el-icon></span>
                <span v-else @click="openImageDialog(scope.row)">
                    <el-icon class="icon-class">
                        <Picture />
                    </el-icon></span>
            </template>
        </el-table-column>
        <el-table-column>
            <template #default="scope">
                <el-tag size="large" :type="getDeviceStatus(scope.row.components)">{{
                    fmtDeviceHealth(scope.row.components) }}</el-tag>
                <span @click="openReportDialog(scope.row)">
                    <el-icon class="icon-class">
                        <Document />
                    </el-icon>
                </span>
            </template>
        </el-table-column>
    </el-table>
    <ImageUploadDialog :stationName="dialog.stationName" :imgData="dialog.imgData" v-model:visible="dialog.visible"
        @uploadComplete="fetchData"> </ImageUploadDialog>

    <el-dialog v-model="reportVisible" width="70%" :destroy-on-close="true" :show-header="false">
        <div style="width: 100%">
            <!-- 自定义页头 -->
            <div class="custom-header">
                <el-image style="line-height: 1px; width: 100px"
                    :src="require('../assets/images/siemens-logo.png')"></el-image>
                <span style="margin-right: 60px; font-size: 18px; font-weight: bolder">设备状态监测报告</span>
            </div>
            <el-divider style="margin-top: 15px" />

            <el-form ref="form" :model="deviceForm" size="median" class="device-detail-form">
                <el-form-item label="检测设备：">
                    <span>{{ deviceForm.station_name }}</span>
                </el-form-item>
                <el-form-item label="设备状态：">
                    <el-tag size="large" :type="getDeviceStatus(deviceForm.components)">{{
                        fmtDeviceHealth(deviceForm.components) }}</el-tag>
                    <!-- <span>{{ fmtDeviceHealth(deviceForm.components) }}</span> -->
                </el-form-item>
                <el-form-item label="报告日期：">
                    <span>{{ getNow() }}</span>
                </el-form-item>
                <el-form-item class="whole-node" label="设备图片：">
                    <el-image v-if="deviceForm.image_data" style="width: 80%" :src="formatImage(deviceForm.image_data)"
                        :zoom-rate="1.2" :max-scale="7" :min-scale="0.2"
                        :preview-src-list="[formatImage(deviceForm.image_data)]" :initial-index="4" fit="cover" />
                    <span v-else>【暂未上传图片】</span>
                </el-form-item>
            </el-form>
            <div class="whole-node data-analysis-div">
                <el-icon class="icon-class">
                    <DataAnalysis />
                </el-icon>
                <span style="margin-left: 15px" class="form-title">设备数据分析</span>
            </div>
            <div class="data-analysis-div" v-for="(component, index) in deviceForm.components" :key="index">
                <el-row class="whole-node data-analysis-title" :class="getHealthBackColor(component.alarm_code)">
                    <el-col :span="6">
                        <span class="title-component">{{ component.component_name }}</span>
                    </el-col>
                    <el-col :span="10">
                        <span class="title-component">{{ fmtComponentHealth(component.alarm_code) }}</span>
                    </el-col>
                    <el-col :span="8">
                        <el-tag v-if="component.has_fault" type="danger">存在未处理的报警</el-tag>&nbsp;
                        <span class="title-component">{{ fmtComponentScore(component) }}%</span>
                    </el-col>
                </el-row>
                <HealthDistribute class="whole-node" :tableName="component.table_name"></HealthDistribute>
                <HealthTrendCompare class="whole-node" :tableName="component.table_name"></HealthTrendCompare>
                <HealthCorrelation class="whole-node" :tableName="component.table_name" style=""></HealthCorrelation>
                <HealthTrend class="whole-node" :tableName="component.table_name"></HealthTrend>
                <div class="whole-node" v-if="component.alarm_code > 1000" style="width: 100%">
                    <el-row class="echart-title">
                        <el-col :span="6">
                            <el-icon @click="isEdit = !isEdit" style="transform: scale(1.5)">
                                <EditPen />
                            </el-icon>
                            <span class="title-detail">维修建议</span>
                        </el-col>
                    </el-row>
                    <el-row style="margin-top: 10px">
                        <el-col :span="20" :offset="2">
                            <span v-if="!isEdit" v-html="component.alarm_suggestion"></span>
                            <div v-else style="width: 100%; height: 70%">
                                <QuillEditor theme="snow"
                                    :content="component.alarm_suggestion ? component.alarm_suggestion : ''"
                                    contentType="html" toolbar="essential" @update:content="
                                        content => {
                                            component.alarm_suggestion = content
                                        }
                                    " />
                            </div>
                        </el-col>
                    </el-row>
                </div>
            </div>
        </div>
        <template #footer>
            <div style="text-align: right">
                <el-button @click="generatePDF" size="large" type="primary">导出PDF</el-button>
                <el-button @click="reportVisible = false" size="large">关闭</el-button>
            </div>
        </template>
    </el-dialog>
</template>

<script>
import { getAllHealth } from '@/apis'
import ImageUploadDialog from '@c/ImageUploadDialog'
import HealthTrend from '@c/HealthTrend'
import HealthDistribute from '@c/HealthDistribute'
import HealthTrendCompare from '@c/HealthTrendCompare'
import HealthCorrelation from '@c/HealthCorrelation'
import moment from 'moment'
import { jsPDF } from 'jspdf'
import html2canvas from 'html2canvas'

export default {
    name: 'HealthReport',
    props: {},
    components: { ImageUploadDialog, HealthTrend, HealthDistribute, HealthTrendCompare, HealthCorrelation },
    data() {
        return {
            devices: [],
            dialog: {},
            loading: false,
            reportVisible: false,
            deviceForm: '',
            isEdit: false
        }
    },
    watch: {},
    computed: {},
    methods: {
        generatePDF() {
            /**
             * A4 纸尺寸
             */
            const A4_WIDTH = 592.28
            const A4_HEIGHT = 841.89
            // 获取需要截取节点的 dom
            const domElement = document.querySelector('.el-dialog__body')

            // // 获取目标元素的高度(去除滚动条时高度)
            // const domScrollHeight = domElement.scrollHeight
            // const domScrollWidth = domElement.scrollWidth

            // 根据 A4 的宽高等比计算 dom 页面对应的高度
            const pageWidth = domElement.offsetWidth
            const pageHeight = (pageWidth / A4_WIDTH) * A4_HEIGHT

            // 将所有不允许被截断的子元素进行处理
            const wholeNodes = domElement.querySelectorAll('.whole-node')

            //不允许被截断元素之间的间隔高度
            let intervalHeight = 65
            // 插入空白块的总高度
            // let allEmptyNodeHeight = 0

            for (let i = 0; i < wholeNodes.length; i++) {
                // 判断当前的不可分页元素是否在两页显示
                const topPageNum = Math.ceil(wholeNodes[i].offsetTop / pageHeight)
                const bottomPageNum = Math.ceil((wholeNodes[i].offsetTop + wholeNodes[i].offsetHeight) / pageHeight)

                // 说明该 dom 会被截断
                if (topPageNum !== bottomPageNum) {
                    // 创建空白块
                    const newBlock = document.createElement('div')
                    newBlock.className = 'empty-node'
                    newBlock.style.background = '#fff'

                    // 计算空白块的高度，可以适当留出空间使得内容不会太靠边，根据自己需求而定
                    const _H = pageHeight * topPageNum - wholeNodes[i].offsetTop + intervalHeight
                    newBlock.style.height = _H + 'px'

                    // 插入空白块
                    wholeNodes[i].parentNode.insertBefore(newBlock, wholeNodes[i])

                    // 更新插入空白块的总高度
                    // allEmptyNodeHeight = allEmptyNodeHeight + _H + intervalHeight
                }
            }

            // 设置打印区域的高度 (目标元素的高度 + 添加的空白块的高度)
            // domElement.setAttribute('style', `height: ${domScrollHeight + allEmptyNodeHeight}px; width: ${domScrollWidth}px;`)

            /**
             * 以上完成 dom 层面的分页，可以转为图片进一步处理了
             * options
             *  - useCORS：是否尝试使用 CORS 从服务器加载图像
             *  - scale：用于渲染的比例，默认为浏览器设备像素比
             *  - ignoreElements：忽略的元素
             */
            html2canvas(domElement, {
                width: domElement.offsetWidth,
                height: domElement.offsetHeight,
                useCORS: true,
                scale: 1.5,
                ignoreElements: element => element.tagName === 'BUTTON'
            }).then(canvas => {
                // dom 已经转换为 canvas 对象，可以将插入的空白块删除了
                const emptyNodes = domElement.querySelectorAll('.empty-node')

                for (let i = 0; i < emptyNodes.length; i++) {
                    emptyNodes[i].style.height = 0
                    emptyNodes[i].parentNode.removeChild(emptyNodes[i])
                }

                const canvasWidth = canvas.width
                const canvasHeight = canvas.height

                // html 页面实际高度
                let htmlHeight = canvasHeight

                // 页面偏移量
                let position = 0

                // 根据 A4 的宽高等比计算 pdf 页面对应的高度
                const pageHeight = (canvasWidth / A4_WIDTH) * A4_HEIGHT

                // html 页面生成的 canvas 在 pdf 中图片的宽高
                const imgWidth = A4_WIDTH
                const imgHeight = (A4_WIDTH / canvasWidth) * canvasHeight

                // 将图片转为 base64 格式
                const imageData = canvas.toDataURL('image/jpeg', 1.0)

                /**
                 * 生成 pdf 实例
                 *  - 方向： l 横向，p 纵向
                 *  - 测量单位："pt"，"mm"，"cm"，"m"，"in"，"px"
                 *  - 格式：默认 a4
                 */
                const PDF = new jsPDF('p', 'pt', 'a4')
                // 计算居中位置
                const xOffset = (PDF.internal.pageSize.getWidth() - imgWidth) / 2

                // html 页面的实际高度小于生成 pdf 的页面高度时，即内容未超过 pdf 一页显示的范围，无需分页
                if (htmlHeight <= pageHeight) {
                    /**
                     * 在 PDF 文档中添加图像
                     *  - 图像数据
                     *  - 图像格式
                     *  - x 轴位置
                     *  - y 轴位置
                     *  - 图像宽度
                     *  - 图像高度
                     */
                    PDF.addImage(imageData, 'JPEG', xOffset, 0, imgWidth, imgHeight)
                } else {
                    while (htmlHeight > 0) {
                        PDF.addImage(imageData, 'JPEG', xOffset, position, imgWidth, imgHeight)

                        // 更新高度与偏移量
                        htmlHeight -= pageHeight
                        position -= A4_HEIGHT

                        if (htmlHeight > 0) {
                            // 在 PDF 文档中添加新页面
                            PDF.addPage()
                        }
                    }
                }

                // 保存 pdf 文件
                PDF.save('设备状态监测报告.pdf')
            })
        },
        fmtComponentScore(row) {
            let score = 90
            if (row.has_fault && row.health_score > 90) {
                return score.toFixed(2)
            }
            return row.health_score.toFixed(2)
        },
        formatImage(imageData) {
            return `data:image/jpeg;base64,${imageData}`
        },
        getNow() {
            return moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
        },
        openReportDialog(row) {
            this.deviceForm = row
            this.reportVisible = true
        },
        openImageDialog(row) {
            this.dialog.imgData = row.image_data
            this.dialog.stationName = row.station_name
            this.dialog.visible = true
        },
        fetchData() {
            this.loading = true
            getAllHealth().then(res => {
                if (res.data.success) {
                    this.devices = res.data.data
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },
        getHealthScoreColor(alarm_code) {
            if (alarm_code == 0) return 'gray'
            if (alarm_code == 1000) return 'green'
            if (alarm_code >= 1200) return 'red'
            return 'orange'
        },
        getHealthBackColor(alarm_code) {
            if (alarm_code == 0) return 'health-info'
            if (alarm_code == 1000) return 'health-good'
            if (alarm_code >= 1200) return 'health-danger'
            return 'health-warning'
        },
        fmtComponentHealth(alarm_code) {
            if (alarm_code == 0) return '暂无有效数据'
            if (alarm_code == 1000) return '健康'
            return '关注'
        },
        getComponentStatus(alarm_code) {
            if (alarm_code == 0) return 'info'
            if (alarm_code == 1000) return 'success'
            if (alarm_code >= 1200) return 'danger'
            return 'warning'
        },
        fmtDeviceHealth(components) {
            if (components.every(item => item.alarm_code == 0)) {
                return '暂无有效数据'
            }
            if (components.every(item => item.alarm_code <= 1000)) {
                return '设备健康'
            }
            return '设备需关注'
        },
        getDeviceStatus(components) {
            if (components.every(item => item.alarm_code == 0)) {
                return 'info'
            }
            if (components.every(item => item.alarm_code <= 1000)) {
                return 'success'
            }

            if (components.some(item => item.alarm_code >= 1200)) {
                return 'danger'
            }

            return 'warning'
        }
    },
    created() {
        this.fetchData()
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
.device-detail-form,
.data-analysis-div {
    width: 96%;
    margin-left: 2%;
}
.device-detail-form label,
.form-title {
    width: 16%;
    font-size: 20px;
    font-weight: bolder;
}

.device-detail-form .el-form-item__content {
    font-size: 20px; /* 设置对应内容区域的字体大小 */
}

.title-component {
    color: black;
    font-weight: bolder;
}
.data-analysis-title {
    text-align: center;
    opacity: 0.5;
    width: 90%;
    margin-left: 5%;
    margin-top: 20px;
    padding: 5px 0;
    border-radius: 4px;
    display: flex;
    align-items: center; /* 垂直居中对齐 */
}

.icon-class {
    transform: scale(1.5);
    margin-left: 20px;
}
.custom-header {
    margin-top: -10px;
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center; /* 确保垂直居中对齐 */
    padding: 0 20px; /* 可根据需要调整内边距 */
}
.content-scrollbar {
    width: 100%;
}
.health-good {
    background-color: rgba(103, 194, 58, 0.5); /* 绿色半透明 */
    border: 1px solid rgb(103, 194, 58);
}

.health-warning {
    background-color: rgba(230, 162, 60, 0.5); /* 黄色半透明 */
    border: 1px solid rgb(230, 162, 60);
}

.health-danger {
    background-color: rgba(245, 108, 108, 0.5); /* 红色半透明 */
    border: 1px solid rgb(245, 108, 108);
}

.health-info {
    background-color: rgba(128, 128, 128, 0.5); /* 灰色半透明 */
    border: 1px solid rgb(128, 128, 128);
}
.echart-title {
    text-align: center;
}
.title-detail {
    font-size: 17px;
    margin-left: 10px;
}
</style>
