<template>
    <el-table :data="tableData" stripe border v-loading="loading" style="width: 100%">
        <el-table-column type="expand">
            <template #default="props">
                <p v-html="props.row.description"></p>
            </template>
        </el-table-column>
        <el-table-column min-width="20%" :label="$t('fault')" :filters="codeFilters" :filter-method="codeFilter">
            <template #default="scope">
                <el-tag disable-transitions :type="scope.row.code_level">{{ scope.row.code }}</el-tag>
                <span>{{ ' ' + scope.row.code_name }}</span>
            </template>
        </el-table-column>
        <el-table-column min-width="15%" prop="station" :label="$t('station')" :filters="stationFilters" :filter-method="stationFilter"> </el-table-column>
        <el-table-column min-width="15%" prop="component" :label="$t('component')">
            <template #default="scope">
                <i v-bind:class="getComponentIcon(scope.row.component)"></i>
                {{ $t(scope.row.component) }}
            </template>
        </el-table-column>
        <el-table-column min-width="20%" prop="start_time" :label="$t('startTime')" :formatter="dateFormatter" sortable></el-table-column>
        <el-table-column min-width="20%" prop="end_time" :label="$t('endTime')" :formatter="dateFormatter"></el-table-column>
        <el-table-column min-width="20%" prop="update_time" :label="$t('changeTime')" sortable :formatter="dateFormatter"> </el-table-column>
        <el-table-column min-width="20%">
            <template #header>
                <el-button type="primary" size="mini" @click="this.$router.push({ path: '/samples/new' })">{{ $t('add') }}</el-button>
            </template>
            <template #default="scope">
                <el-button size="mini" @click="this.$router.push({ path: '/samples/' + scope.row.id })">{{ $t('edit') }}</el-button>
                <el-button size="mini" @click="openDialog(scope.row)">{{ $t('view') }}</el-button>
                <el-popconfirm :title="$t('confirmDelete')" :confirm-button-text="$t('confirm')" :cancel-button-text="$t('cancel')" @confirm="removeData(scope.row.id)">
                    <template #reference>
                        <el-button size="mini" type="danger">{{ $t('delete') }}</el-button>
                    </template>
                </el-popconfirm>
            </template>
        </el-table-column>
    </el-table>
    <VibViewDialog :title="dialog.title" :id="dialog.id" :schemaId="dialog.schemaId" v-model:visible="dialog.visible"> </VibViewDialog>
</template>

<script>
import { inject } from 'vue'
import { getSamples, removeSample, getComponentIcon } from '@/apis'
import utils from '@/plugins/utils'
import moment from 'moment'
import VibViewDialog from '@c/VibViewDialog'

export default {
    name: 'SampleList',
    props: {},
    setup() {
        const t = inject('t')
        return {
            t
        }
    },
    components: { VibViewDialog },
    data() {
        return {
            tempData: [],
            timer: null,
            tableData: [],
            rmsData: [],
            loading: true,
            dialog: {},
            stationFilters: []
        }
    },
    watch: {
        '$root.searchInput': function (newValue) {
            clearTimeout(this.timer) //清除延迟执行
            this.timer = setTimeout(() => {
                //设置延迟执行
                this.tableData = this.tempData.filter(item => utils.containsString(item, newValue))
            }, 500)
        }
    },
    computed: {
        codeFilters() {
            // 在这里定义你的过滤器数组
            return [
                { text: this.$t('health'), value: 'success' },
                { text: this.$t('middle_fault'), value: 'warning' },
                { text: this.$t('high_fault'), value: 'danger' }
            ]
        }
    },
    methods: {
        fetchData() {
            this.loading = true
            getSamples().then(res => {
                if (res.data.success) {
                    this.tempData = res.data.data ? res.data.data : []
                    this.tableData = this.tempData
                    this.initFilters()
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },
        initFilters() {
            let filters = new Set()
            this.tableData.forEach(item => filters.add(item.station))
            this.stationFilters = Array.from(filters).map(item => {
                return { text: item, value: item }
            })
        },
        removeData(id) {
            removeSample(id).then(res => {
                if (res.data.success) {
                    this.$success(res.data.msg)
                    this.fetchData()
                } else {
                    this.$error(res.data.msg)
                }
            })
        },
        getComponentIcon(cellValue) {
            return getComponentIcon(cellValue)
        },
        formatUpdatetime(date) {
            if (date) {
                return moment(date).utcOffset(0).format('YYYY-MM-DD HH:mm:ss')
            }
            return ''
        },

        dateFormatter: function (row, column) {
            let date = row[column.property]
            if (date === undefined) {
                return ''
            }
            return moment(date).utcOffset(0).format('YYYY-MM-DD HH:mm:ss')
        },
        openDialog(row) {
            this.dialog.id = row.id
            this.dialog.schemaId = row.schema_id
            this.dialog.title = row.station + ' ' + this.$t(row.component) + ' - ' + row.code + ' ' + row.code_name
            this.dialog.visible = true
        },
        stationFilter(value, row) {
            return row.station === value
        },
        codeFilter(value, row) {
            return row.code_level === value
        }
    },
    created() {
        this.fetchData()
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style></style>
