<template>
    <div class="distribute-container">
        <el-row class="echart-title">
            <el-col :span="6">
                <span class="title-detail">近一周数据分布</span>
            </el-col>
        </el-row>
        <el-row>
            <el-col :span="18" :offset="3">
                <div :id="tableName + type" style="width: 100%; height: 400px" v-loading="loading"></div>
            </el-col>
        </el-row>
    </div>
</template>

<script>
import { healthDistributed } from '@/apis'
import * as echarts from 'echarts'

export default {
    name: 'HealthDistribute',
    props: {
        tableName: String
        // previousDays: {
        //     type: Number,
        //     default: 0
        // }
    },
    data() {
        return {
            type: 'distribute',
            loading: false,
            distributedData: []
        }
    },
    watch: {},
    computed: {},
    methods: {
        drawDistributed() {
            //校验表单
            if (!this.tableName) {
                this.$error('没有组件信息')
                return
            }
            this.loading = true
            healthDistributed(this.tableName).then(res => {
                if (res.data.success) {
                    this.distributedData = res.data.data
                    this.$nextTick(() => this.echartsInitDistributed())
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },
        echartsInitDistributed() {
            //初始化数据
            let dimensions = this.distributedData.dimensions
            let source = this.distributedData.source
            let total = this.distributedData.total
            let series = []

            series.push({
                type: 'bar'
                // label: {
                //     show: true, // 显示标签
                //     position: 'top', // 标签位置
                //     fontSize: 12, // 字体大小
                //     color: '#666' // 字体颜色
                // }
            })
            // 添加对应的折线图
            series.push({
                type: 'line',
                // smooth: true,
                symbol: 'circle',
                symbolSize: 8,
                lineStyle: {
                    width: 2
                },
                label: {
                    show: true,
                    position: 'top',
                    fontSize: 12,
                    formatter: function (params) {
                        const count = Object.values(params.value)[0]
                        if (total != 0) {
                            let result = (count / total) * 100
                            result = result.toFixed(2)
                            return result + '%'
                        }
                        return count
                    }
                }
            })

            let myChart = echarts.init(document.getElementById(this.tableName + this.type))
            // 指定图表的配置项和数据
            let option = {
                legend: { show: false },
                tooltip: {},
                dataset: {
                    dimensions: dimensions,
                    source: source
                },
                xAxis: {
                    type: 'category',
                    name: 'RMS范围',

                    axisLabel: {
                        interval: 0, // 强制显示所有标签
                        // rotate: 45, // 标签斜着显示
                        // nameGap: 35,    // 坐标轴名称与轴线之间的距离
                        formatter: function (value) {
                            // 如果标签太长，可以使用下面的代码换行显示
                            return value.split(' ').join('\n')
                        },
                        textStyle: {
                            fontSize: 12,
                            align: 'center'
                        }
                    }
                },
                yAxis: {
                    name: 'Count',
                    axisLine: {
                        show: true
                    }
                },
                series: series
            }
            // 清除缓存
            myChart.clear()
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option)
        }
    },
    created() {
        this.drawDistributed()
    }
}
</script>
<style>
.distribute-container {
    width: 100%;
    margin-top: 20px;
}
.echart-title {
    text-align: center;
}
.title-detail {
    font-size: 17px;
}
</style>
