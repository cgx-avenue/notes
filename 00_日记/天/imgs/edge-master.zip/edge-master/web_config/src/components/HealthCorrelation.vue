<template>
    <div class="correlation-container">
        <el-row class="echart-title">
            <el-col :span="5">
                <span class="title-detail">数据相关性</span>
            </el-col>
        </el-row>
        <el-row>
            <el-col :span="20" :offset="2">
                <div :id="tableName + type" style="width: 100%; height: 400px" v-loading="loading"></div>
            </el-col>
        </el-row>
    </div>
</template>

<script>
import { healthCorrelation } from '@/apis'
import * as echarts from 'echarts'

export default {
    name: 'HealthCorrelation',
    props: {
        tableName: String
    },
    data() {
        return {
            type: 'correlation',
            loading: false,
            correlationData: []
        }
    },
    watch: {},
    computed: {},
    methods: {
        drawCorrelation() {
            //校验表单
            if (!this.tableName) {
                this.$error('没有组件信息')
                return
            }
            this.loading = true
            healthCorrelation(this.tableName).then(res => {
                if (res.data.success) {
                    this.correlationData = res.data.data
                    this.$nextTick(() => this.echartsInitCorrelation())
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },
        echartsInitCorrelation() {
            let categories = Object.keys(this.correlationData);
            let matrix = [];
            categories.forEach((row, rowIndex) => {
                categories.forEach((col, colIndex) => {
                    matrix.push([rowIndex, colIndex, this.correlationData[row][col]]);
                });
            });

            let myChart = echarts.init(document.getElementById(this.tableName + this.type))
            // 指定图表的配置项和数据
            let option = {
                tooltip: {
                    position: 'top',
                    formatter: function (params) {
                        const xLabel = categories[params.value[0]];
                        const yLabel = categories[params.value[1]];
                        const value = params.value[2];
                        return `${xLabel} 与 ${yLabel} 的相关性: ${value}`;
                    }
                },
                animation: false,
                grid: {
                    height: '80%',
                    top: '10%'
                },
                xAxis: {
                    type: 'category',
                    data: categories,
                    splitArea: {
                        show: true
                    },
                    axisLabel: {
                        interval: 0, // 强制显示所有标签
                    }
                },
                yAxis: {
                    type: 'category',
                    data: categories,
                    splitArea: {
                        show: true
                    }
                },
                visualMap: {
                    min: -1,
                    max: 1,
                    calculable: true,
                    orient: 'vertical',
                    left: 'right',
                    bottom: '30px',
                    color: ['#d73027', '#fee08b', '#1a9850'] 
                },
                series: [
                    {
                        type: 'heatmap',
                        data: matrix,
                        label: {
                            show: true,
                            formatter: function (params) {
                                console.log(params)
                                return params.value[2].toFixed(3);
                            }
                        },
                        emphasis: {
                            itemStyle: {
                                shadowBlur: 10,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            };
            // 清除缓存
            myChart.clear()
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option)
        }
    },
    created() {
        this.drawCorrelation()
    }
}
</script>
<style>
.correlation-container {
    width: 100%;
    margin-top: 30px;
}

.echart-title {
    text-align: center;
}

.title-detail {
    font-size: 17px;
}
</style>
