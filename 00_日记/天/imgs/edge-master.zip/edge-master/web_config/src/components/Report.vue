<template>
    <el-form ref="form" :rules="rules" size="large" class="report-form">
        <el-form-item :label="$t('chartType')">
            <el-radio-group v-model="type">
                <el-radio label="scatter"><i class="iconfont icon-scatter"></i> {{ $t('scatter') }}</el-radio>
                <el-radio label="distributed"><i class="iconfont icon-bar"></i> {{ $t('distribution') }}</el-radio>
                <el-radio label="trend"><i class="iconfont icon-trend"></i> {{ $t('trend') }}</el-radio>
            </el-radio-group>
        </el-form-item>
        <!-- 散点图 -->
        <el-form-item :label="$t('sampleTime')" v-show="type === 'scatter'">
            <el-col>
                <el-date-picker v-model="timeRange" type="datetimerange" :range-separator="$t('to')" :start-placeholder="$t('startTime')" :end-placeholder="$t('endTime')"> </el-date-picker>
            </el-col>
            <el-col class="line" :span="2">&nbsp;</el-col>
            <el-col>
                <el-autocomplete class="inline-input" value-key="value" :fetch-suggestions="searchSchema" :placeholder="$t('addStation')" @select="handleSelectSchema">
                    <template #default="scope">
                        <span style="float: left">{{ scope.item.station }}</span>
                        <span style="float: right; color: #8492a6; font-size: 13px">{{ $t(scope.item.component) }}</span>
                    </template>
                </el-autocomplete>
            </el-col>
        </el-form-item>
        <el-form-item :label="reportSchema.station + ' ' + $t(reportSchema.component)" v-show="type === 'scatter'" v-for="reportSchema in scatterSchemas" :key="reportSchema.id">
            <el-col>
                <el-checkbox-group v-model="reportSchema.checkedList">
                    <el-checkbox v-for="feature in reportSchema.features" :label="feature" :key="feature" border size="large">
                        {{ feature }}
                    </el-checkbox>
                </el-checkbox-group>
            </el-col>
            <el-col class="line" :span="2">&nbsp;</el-col>
            <el-col>
                <el-button type="danger" plain icon="el-icon-delete" @click="remove(reportSchema.id)">{{ $t('remove') }}</el-button>
            </el-col>
        </el-form-item>
        <!-- 分布图 -->
        <el-form-item :label="$t('sampleTime')" v-show="type === 'distributed'">
            <el-date-picker v-model="timeRange" type="datetimerange" :range-separator="$t('to')" :start-placeholder="$t('startTime')" :end-placeholder="$t('endTime')"> </el-date-picker>
        </el-form-item>
        <el-form-item :label="$t('station')" v-show="type === 'distributed'">
            <el-checkbox-group v-model="distributedSchemas">
                <el-checkbox v-for="schema in schemas" :label="schema" :key="schema.id" border class="margin-bottom-10px" size="large">
                    {{ schema.station + ' ' + $t(schema.component) }}
                </el-checkbox>
            </el-checkbox-group>
        </el-form-item>
        <!-- 趋势图 -->
        <el-form-item :label="$t('station')" v-show="type === 'trend'">
            <el-radio-group v-model="trendSchema">
                <el-radio :label="schema" v-for="schema in schemas" :key="schema.id" class="margin-bottom-10px">
                    {{ schema.station + ' ' + $t(schema.component) }}
                </el-radio>
            </el-radio-group>
        </el-form-item>
        <el-form-item :label="$t('trendMonth')" v-show="type === 'trend'">
            <el-checkbox-group v-model="trendMonths">
                <el-checkbox v-for="month in last6Months" :label="month" :key="month" border size="large">
                    {{ month }}
                </el-checkbox>
            </el-checkbox-group>
        </el-form-item>
        <!-- 健康报告 -->
        <el-form-item label="工位" v-show="type === 'document'">
            <el-radio-group v-model="documentSchema">
                <el-radio :label="schema" v-for="schema in schemas" :key="schema.id" class="margin-bottom-10px">
                    {{ schema.station + ' ' + $t(schema.component) }}
                </el-radio>
            </el-radio-group>
        </el-form-item>

        <el-form-item size="large" style="margin-left: 210px">
            <el-button type="primary" plain v-show="type === 'scatter'" @click="drawScatter">{{ $t('draw') }}</el-button>
            <el-button type="primary" plain v-show="type === 'distributed'" @click="drawDistributed">{{ $t('draw') }}</el-button>
            <el-button type="primary" plain v-show="type === 'trend'" @click="drawTrend">{{ $t('draw') }}</el-button>
            <el-button type="primary" plain v-show="type === 'document'" @click="drawDocument">{{ $t('draw') }}</el-button>
        </el-form-item>
    </el-form>
    <el-dialog v-model="dialogVisibleScatter" width="80%" center destroy-on-close>
        <el-row>
            <el-col :span="19"></el-col>
            <el-col :span="5">
                <el-switch v-model="normalize" size="large" :active-text="$t('normalizedData')" :inactive-text="$t('rawData')" @change="normalizeChange" />
            </el-col>
        </el-row>
        <el-row>
            <div id="echartsScatter" style="width: 100%; height: 400px" v-loading="loading"></div>
        </el-row>
    </el-dialog>
    <el-dialog v-model="dialogVisible" width="80%" center>
        <div id="echarts" style="width: 100%; height: 400px" v-loading="loading"></div>
    </el-dialog>
    <el-dialog v-model="dialogVisibleTrend" width="80%" center>
        <el-row>
            <el-col :span="16">
                <div id="echartsTrend" style="width: 100%; height: 400px" v-loading="loading"></div>
            </el-col>
            <el-col :span="8">
                <el-table :data="trendTableData" style="width: 100%">
                    <el-table-column prop="month" min-width="45%" :label="$t('month')"></el-table-column>
                    <el-table-column prop="total" :label="$t('sampleTotal')"></el-table-column>
                    <el-table-column prop="percent" min-width="55%" :label="$t('greaterThreshold') + '%'"></el-table-column>
                </el-table>
            </el-col>
        </el-row>
    </el-dialog>

</template>

<script>
import { getSchemas, scatterReport, distributedReport, trendReport, getSampleAlgorithms, detectReport } from '@/apis'
import * as echarts from 'echarts'
import moment from 'moment'

export default {
    name: 'Report',
    props: {},
    data() {
        return {
            type: 'scatter',
            loading: false,
            dialogVisible: false,
            dialogVisibleScatter: false,
            dialogVisibleTrend: false,
            documentTips: '',
            normalize: false,
            //所有工位信息
            schemas: [],
            timeRange: [],
            //作图工位
            scatterSchemas: [],
            distributedSchemas: [],
            trendSchema: '',
            documentSchema: '',
            documentData: '',
            //最近六个月
            last6Months: [],
            //趋势图月份
            trendMonths: [],
            //报表数据
            scatterData: [],
            distributedData: [],
            trendData: [],
            trendTableData: [],
            documentTrendData: [],
            algorithmOptions: [],
            detectData: ''
        }
    },
    watch: {},
    computed: {},
    methods: {

        normalizeChange(flag) {
            this.loading = true
            scatterReport(flag, this.timeRange[0], this.timeRange[1], this.scatterSchemas).then(res => {
                if (res.data.success) {
                    this.scatterData = res.data.data
                    this.$nextTick(() => this.echartsInitScatter())
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },
        fetchData() {
            getSchemas().then(res => {
                if (res.data.success) {
                    this.schemas = res.data.data
                } else {
                    this.$error(res.data.msg)
                }
            })
        },
        getAlgorithmsOptions() {
            getSampleAlgorithms().then(res => {
                if (res.data.success) {
                    this.algorithmOptions = res.data.data
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },
        searchSchema(queryString, cb) {
            let results = this.schemas
            //过滤掉已经选中的
            results = results.filter(result => {
                let reportIds = this.scatterSchemas.map(schema => schema.id)
                return !(reportIds.indexOf(result.id) >= 0)
            })
            if (queryString) {
                //根据关键词搜索
                results = results.filter(result => result.station.toLowerCase().indexOf(queryString.toLowerCase()) >= 0)
            }
            cb(results)
        },
        handleSelectSchema(item) {
            let reportSchema = {}
            reportSchema.id = item.id
            reportSchema.name = item.station + ' ' + item.component
            reportSchema.station = item.station
            reportSchema.sensor = item.sensor
            reportSchema.component = item.component
            reportSchema.features = item.features.map(feature => feature.feature).filter(feature => feature.toLowerCase() !== 'timestamp')
            //默认勾选vibrms
            reportSchema.checkedList = reportSchema.features.filter(feature => feature.toLowerCase().indexOf('vibrms') >= 0)
            this.scatterSchemas.push(reportSchema)
        },
        fmtFeatrue(documentSchema) {
            let rmsFeature = documentSchema.features.find(feature => feature.feature.toLowerCase() === 'vibrms')
            return rmsFeature
        },
        fmtAlgorithm(documentSchema) {
            if (documentSchema.algorithm == null || documentSchema.algorithm == '') return this.$t('algorithmTips')

            let algorithm = this.algorithmOptions.find(item => item.value === documentSchema.algorithm).label
            return algorithm
        },
        getLast6Months() {
            //创建现在的时间
            let data = new Date()
            //获取年
            let year = data.getFullYear()
            //获取月
            let mon = data.getMonth() + 2
            for (let i = 0; i < 6; i++) {
                mon = mon - 1
                if (mon <= 0) {
                    year = year - 1
                    mon = mon + 12
                }
                if (mon < 10) {
                    mon = '0' + mon
                }
                this.last6Months[i] = year + '-' + mon
            }
            this.last6Months.reverse()
            //this.last6Months = ["2021-01", "2021-02", "2021-03", "2021-04", "2021-05", "2021-06"]
        },
        remove(id) {
            this.scatterSchemas = this.scatterSchemas.filter(schema => schema.id !== id)
        },
        drawScatter() {
            //校验表单
            if (!this.timeRange[0] || !this.timeRange[1]) {
                this.$error(this.$t('selectSampleTime'))
                return
            }
            if (this.timeRange[1] - this.timeRange[0] > 3600 * 24 * 1000) {
                this.$warning(this.$t('selectWarning'))
            }
            if (this.scatterSchemas.length === 0) {
                this.$error(this.$t('selectStation'))
                return
            }
            let featureCount = this.scatterSchemas.reduce((total, curr) => total + curr.checkedList.length, 0)
            if (featureCount === 0) {
                this.$error(this.$t('selectFeature'))
                return
            }
            this.normalize = false
            this.dialogVisibleScatter = true
            this.loading = true
            scatterReport(this.normalize, this.timeRange[0], this.timeRange[1], this.scatterSchemas).then(res => {
                if (res.data.success) {
                    this.scatterData = res.data.data
                    this.$nextTick(() => this.echartsInitScatter())
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },
        drawDistributed() {
            //校验表单
            if (!this.timeRange[0] || !this.timeRange[1]) {
                this.$error(this.$t('selectSampleTime'))
                return
            }
            if (this.distributedSchemas.length === 0) {
                this.$error(this.$t('selectStation'))
                return
            }
            this.dialogVisible = true
            this.loading = true
            distributedReport(this.timeRange[0], this.timeRange[1], this.distributedSchemas).then(res => {
                if (res.data.success) {
                    this.distributedData = res.data.data
                    this.$nextTick(() => this.echartsInitDistributed())
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },
        drawTrend() {
            if (!this.trendSchema) {
                this.$error(this.$t('selectStation'))
                return
            }
            if (this.trendMonths.length === 0) {
                this.$error(this.$t('selectMonth'))
                return
            }
            this.dialogVisibleTrend = true
            this.loading = true
            this.trendMonths.sort()
            // 获取vibrms阈值
            let rmsFeature = this.trendSchema.features.find(feature => feature.feature.toLowerCase() === 'vibrms')
            let threshold = rmsFeature && rmsFeature.high ? rmsFeature.high : null
            trendReport(this.trendSchema, this.trendMonths, threshold).then(res => {
                if (res.data.success) {
                    this.trendData = res.data.data
                    // 填充统计表格数据
                    this.trendTableData = []
                    for (let i = 0; i < this.trendMonths.length; i++) {
                        let percent = this.$t('noPercent')
                        if (threshold) {
                            percent = ((this.trendData.thresholds[i] * 100) / this.trendData.totals[i]).toFixed(6)
                        }
                        this.trendTableData.push({
                            month: this.trendMonths[i],
                            total: this.trendData.totals[i],
                            percent: percent
                        })
                    }
                    this.$nextTick(() => this.echartsInitTrend())
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },

        echartsInitScatter() {
            //初始化数据
            let legends = []
            let series = []
            let that = this
            this.scatterData.forEach(item => {
                item.legend = item.legend
                    .split(/\s+/)
                    .map((part, index) => (index === 1 ? this.$t(part) : part))
                    .join(' ')
                legends.push(item.legend)
                series.push({
                    name: item.legend,
                    symbolSize: 5,
                    type: 'scatter',
                    data: item.data,
                    large: true
                })
            })
            let myChart = echarts.init(document.getElementById('echartsScatter'))
            // 指定图表的配置项和数据
            let option = {
                tooltip: {
                    trigger: 'item',
                    formatter: function (params) {
                        let color = params.color
                        return `${params.seriesName}：<br/>${that.$t('time')}：${params.value[0]}<br/>
            ${that.$t('number')}：<div style="width: 14px; height: 14px; background-color: ${color}; border-radius: 50%; display: inline-block;box-shadow: 0 0 7px ${color};"></div>
            &nbsp;${params.value[1]}<br/>`
                    }
                },
                legend: {
                    show: true,
                    data: legends
                },
                xAxis: {
                    name: this.$t('time'),
                    type: 'time',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        formatter: function (value) {
                            return moment(new Date(value)).format('HH:mm:ss')
                        }
                    }
                },
                yAxis: {
                    name: 'RMS mm/s2',
                    axisLine: {
                        show: true
                    }
                },
                dataZoom: [
                    {
                        type: 'slider'
                    },
                    {
                        type: 'inside'
                    }
                ],
                series: series
            }
            // 清除缓存
            myChart.clear()
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option)
        },
        echartsInitDistributed() {
            //初始化数据
            let dimensions = this.distributedData.dimensions
            let source = this.distributedData.source
            let series = []
            let legends = []
            dimensions.forEach((part, index) => {
                if (index > 0) {
                    legends.push(
                        part
                            .split(' ')
                            .map((v, k) => (k == 1 ? this.$t(v) : v))
                            .join(' ')
                    )
                }
            })

            this.distributedSchemas.forEach((_, index) => series.push({ name: legends[index], type: 'bar' }))
            let myChart = echarts.init(document.getElementById('echarts'))
            // 指定图表的配置项和数据
            let option = {
                legend: {
                    show: true,
                    data: legends
                },
                tooltip: {},
                dataset: {
                    dimensions: dimensions,
                    source: source
                },
                xAxis: {
                    type: 'category',
                    name: this.$t('rmsRange')
                },
                yAxis: {
                    name: this.$t('count'),
                    axisLine: {
                        show: true
                    }
                },
                dataZoom: [
                    {
                        type: 'slider'
                    },
                    {
                        type: 'inside'
                    }
                ],
                series: series
            }
            // 清除缓存
            myChart.clear()
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option)
        },
        echartsInitTrend() {
            //初始化数据
            let myChart = echarts.init(document.getElementById('echartsTrend'))
            const selectedKeys = {
                [this.$t('sampleSize')]: false,
                [this.$t('maximum')]: false,
                [this.$t('greaterThreshold')]: false
            }
            // 指定图表的配置项和数据
            let option = {
                tooltip: {},
                legend: {
                    show: true,
                    data: [this.$t('sampleSize'), this.$t('maximum'), this.$t('minimum'), this.$t('average'), this.$t('median'), this.$t('standardDeviation'), this.$t('lowerQuartile'), this.$t('upperQuartile'), this.$t('greaterThreshold')],
                    selected: selectedKeys
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: this.trendMonths
                },
                yAxis: {
                    //name: 'RMS mm/s2',
                    axisLine: {
                        show: true
                    }
                },
                series: [
                    {
                        name: this.$t('sampleSize'),
                        type: 'line',
                        data: this.trendData.totals
                    },
                    {
                        name: this.$t('maximum'),
                        type: 'line',
                        data: this.trendData.maxs
                    },
                    {
                        name: this.$t('minimum'),
                        type: 'line',
                        data: this.trendData.mins
                    },
                    {
                        name: this.$t('averages'),
                        type: 'line',
                        data: this.trendData.means
                    },
                    {
                        name: this.$t('median'),
                        type: 'line',
                        data: this.trendData.medians
                    },
                    {
                        name: this.$t('standardDeviation'),
                        type: 'line',
                        data: this.trendData.stds
                    },
                    {
                        name: this.$t('lowerQuartile'),
                        type: 'line',
                        data: this.trendData.q1s
                    },
                    {
                        name: this.$t('upperQuartile'),
                        type: 'line',
                        data: this.trendData.q3s
                    },
                    {
                        name: this.$t('greaterThreshold'),
                        type: 'line',
                        data: this.trendData.thresholds
                    }
                ]
            }
            // 清除缓存
            myChart.clear()
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option)
        },
    },
    created() {
        this.getLast6Months()
        this.fetchData()
        this.getAlgorithmsOptions()
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
.document-form {
    width: 50%;
}

.document-form .el-form-item {
    width: 45%;
}

.document-form .el-tag {
    font-size: 17px;
}

.document-form .el-form-item__label {
    font-size: 18px;
    font-weight: bolder;
    color: black;
}

.document-form .el-form-item__content {
    font-size: 18px;
}

.document-data-form .el-form-item__label {
    font-size: 17px;
    color: black;
    font-weight: bolder;
}

.document-data-form .el-form-item__content {
    font-size: 17px;
    color: black;
}

.report-form .el-form-item__label {
    width: 180px;
    color: #99a9bf;
}

.report-form label + div.el-form-item__content {
    margin-left: 30px;
    width: 90%;
}

.report-form .el-textarea {
    width: 81%;
}

.report-form .el-select {
    width: 36%;
}

.report-form .el-checkbox {
    margin-right: 0;
}

.report-form .el-button + .el-button {
    margin-left: 0 !important;
}

.report-form .el-checkbox.is-bordered + .el-checkbox.is-bordered {
    margin-left: 0;
}

.report-form .el-checkbox.is-bordered {
    margin-right: 10px;
}

.margin-bottom-10px {
    margin-bottom: 10px;
}
</style>
