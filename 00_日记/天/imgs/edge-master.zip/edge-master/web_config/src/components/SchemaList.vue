<template>
    <el-table :data="tableData" stripe border v-loading="loading" style="width: 100%">
        <el-table-column type="expand">
            <template #default="props">
                <el-form label-position="left" inline class="demo-table-expand">
                    <el-form-item label="Host">
                        <span>{{ props.row.host }}</span>
                    </el-form-item>
                    <el-form-item label="Port">
                        <span>{{ props.row.port }}</span>
                    </el-form-item>
                    <el-form-item label="Topic">
                        <span>{{ props.row.topic }}</span>
                    </el-form-item>
                </el-form>
                <el-divider></el-divider>
                <el-table :data="props.row.features" style="width: 100%">
                    <el-table-column min-width="20%" prop="feature" :label="$t('feature')"></el-table-column>
                    <el-table-column min-width="20%" prop="address" :label="$t('address')"></el-table-column>
                    <el-table-column min-width="15%" prop="middle" :label="$t('middle_threshold')"></el-table-column>
                    <el-table-column min-width="15%" prop="middle_code" :label="$t('middle_warning_code')">
                        <template #default="scope">
                            <el-tag disable-transitions type="warning" v-if="scope.row.middle_code">
                                <el-link type="warning" :underline="false" :href="'/codes?code=' + scope.row.middle_code" target="_blank" class="tag-link">
                                    {{ scope.row.middle_code }}
                                </el-link>
                            </el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column min-width="15%" prop="high" :label="$t('high_threshold')"></el-table-column>
                    <el-table-column min-width="15%" prop="high_code" :label="$t('high_warning_code')">
                        <template #default="scope">
                            <el-tag disable-transitions type="danger" v-if="scope.row.high_code">
                                <el-link type="danger" :underline="false" :href="'/codes?code=' + scope.row.high_code" target="_blank" class="tag-link">
                                    {{ scope.row.high_code }}
                                </el-link>
                            </el-tag>
                        </template>
                    </el-table-column>
                </el-table>
            </template>
        </el-table-column>
        <el-table-column min-width="15%" prop="station" :label="$t('station')" :filters="stationFilters" :filter-method="stationFilter"> </el-table-column>
        <el-table-column min-width="15%" prop="component" :label="$t('component')">
            <template #default="scope">
                <i v-bind:class="getComponentIcon(scope.row.component)"></i>
                {{ $t(scope.row.component) }}
            </template>
        </el-table-column>
        <el-table-column min-width="15%" prop="sensor" :label="$t('sensor')">
            <template #default="scope">
                <el-tag disable-transitions :type="getSensorColor(scope.row.sensor)">{{ fmtSensor(scope.row.sensor) }}</el-tag>
            </template>
        </el-table-column>
        <el-table-column min-width="12%" prop="protocol" :label="$t('protocol')"></el-table-column>
        <el-table-column min-width="12%" prop="dynamic_threshold" :label="$t('dynamicThreshold')">
            <template #default="scope">
                <el-switch v-model="scope.row.dynamic_threshold" disabled></el-switch>
            </template>
        </el-table-column>
        <el-table-column min-width="20%">
            <template #header>
                <div class="button-column">
                    <el-button type="primary" size="mini" @click="this.$router.push({ path: '/schemas/new' })">{{ $t('add') }}</el-button>
                    <el-popconfirm :title="$t('createTableInfo')" :confirm-button-text="$t('confirm')" :cancel-button-text="$t('cancel')" @confirm="createTables()">
                        <template #reference>
                            <el-button type="danger" size="mini">{{ $t('createTables') }}</el-button>
                        </template>
                    </el-popconfirm>
                </div>
            </template>
            <template #default="scope">
                <div class="button-column">
                    <el-button size="mini" @click="this.$router.push({ path: '/schemas/' + scope.row.id })">
                        {{ $t('edit') }}
                    </el-button>
                    <el-button size="mini" @click="this.$router.push({ path: '/schemas/copy_' + scope.row.id })">
                        {{ $t('copy') }}
                    </el-button>
                    <el-button size="mini" type="success" @click="uploadData(scope.row)">
                        {{ $t('import_data_file') }}
                    </el-button>
                    <el-popconfirm :confirm-button-text="$t('confirm')" :cancel-button-text="$t('cancel')" :title="$t('confirmDelete')" @confirm="removeData(scope.row.id)">
                        <template #reference>
                            <el-button class="danger-button" size="mini" type="danger">{{ $t('delete') }}</el-button>
                        </template>
                    </el-popconfirm>
                </div>
            </template>
        </el-table-column>
    </el-table>
    <el-dialog :title="$t('import_data_file')" v-model="dialogVisible" width="30%" :destroy-on-close="true" :before-close="handleClose">
        <el-upload ref="uploadRef" action name="files" :auto-upload="false" :multiple="true" :file-list="fileList" :data="fileData" accept=".xlsx,.xls" :limit="5" :on-exceed="handleExceed" :on-change="changeFileList" :on-remove="removeFile" style="width: 100%" v-loading="loading">
            <el-button type="primary" size="small">{{ $t('selectFile') }}</el-button>

            <template #tip>
                <div class="el-upload__tip">{{ $t('uploadInfo') }}</div>
            </template>
        </el-upload>

        <template #footer>
            <div style="text-align: right">
                <el-button @click="submitUpload" size="small" type="primary">{{ $t('import') }}</el-button>
                <el-button @click="handleClose" size="small">{{ $t('close') }}</el-button>
            </div>
        </template>
    </el-dialog>
</template>

<script>
import { getSchemas, removeSchema, createTables, getComponentIcon, getSensorOptions, uploadData } from '@/apis'
import { ElMessage } from 'element-plus'
import utils from '@/plugins/utils'

export default {
    name: 'SchemaList',
    props: {},
    data() {
        return {
            tempData: [],
            timer: null,
            tableData: [],
            loading: true,
            stationFilters: [],
            dialogVisible: false,
            fileList: [],
            fileData: {}
        }
    },
    watch: {
        '$root.searchInput': function (newValue) {
            clearTimeout(this.timer) //清除延迟执行
            this.timer = setTimeout(() => {
                //设置延迟执行
                this.tableData = this.tempData.filter(item => utils.containsString(item, newValue))
            }, 500)
        }
    },
    computed: {},
    methods: {
        submitUpload() {
            if (this.fileList.length <= 0) {
                ElMessage.error(this.$t('noFileCheck'))
                return
            }
            const form = new FormData()

            form.append('data', JSON.stringify(this.fileData))

            this.fileList.forEach(f => {
                form.append('files', f.raw)
            })

            this.loading = true
            uploadData(form).then(res => {
                if (res && res.data.success) {
                    this.$success(res.data.msg)
                    //清空数据
                    this.$refs['uploadRef'].clearFiles()
                    this.fileList = []
                    this.fileData = {}
                    this.dialogVisible = false
                } else {
                    this.$error(res ? res.data.msg : this.$t('importFaild'))
                }

                this.loading = false
            })
        },
        handleExceed(file, files) {
            ElMessage.error(this.$t('fileCountCheck'))
        },
        // handleError() {
        //   this.$message({
        //     message: "上传失败!",
        //     type: "error",
        //   });
        // },
        // handleSuccess(response) {
        //   console.log(response);
        //   if (response.success) {
        //     this.$message({
        //       message: "上传成功",
        //       type: "success",
        //     });

        //     //清空数据
        //     this.$refs["uploadRef"].clearFiles();
        //     this.fileList = [];
        //     (this.fileData = {}), (this.fileUploadVisible = false);
        //   } else {
        //     let msg = "";
        //     if (response.data) {
        //       msg = JSON.stringify(response.data);
        //     }
        //     this.$message({
        //       message: "上传失败信息:" + msg.substr(0, 1000),
        //       type: "error",
        //     });
        //   }
        // },

        uploadData(row) {
            this.fileData = row
            this.dialogVisible = true
        },

        changeFileList(file, fileList) {
            const type = ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']
            if (type.indexOf(file.raw.type) === -1) {
                ElMessage.error(this.$t('excelCheck'))
                fileList.splice(-1)
            } else if (file.raw.size / 1024 / 1024 > 2) {
                ElMessage.error(this.$t('fileSizeCheck'))
                fileList.splice(-1)
            }
            this.fileList = fileList
        },
        removeFile(file) {
            this.fileList.forEach((item, index) => {
                if (item.uuid == file.uuid) {
                    this.fileList.splice(index, 1)
                    return
                }
            })
        },
        handleClose() {
            this.dialogVisible = false
            this.$refs['uploadRef'].clearFiles()
            this.fileList = []
            this.fileData = {}
        },

        fetchData() {
            this.loading = true
            getSchemas().then(res => {
                if (res.data.success) {
                    this.tempData = res.data.data ? res.data.data : []
                    this.tableData = this.tempData
                    this.initFilters()
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },
        initFilters() {
            let filters = new Set()
            this.tableData.forEach(item => filters.add(item.station))
            this.stationFilters = Array.from(filters).map(item => {
                return { text: item, value: item }
            })
        },
        removeData(id) {
            removeSchema(id).then(res => {
                if (res.data.success) {
                    this.$success(res.data.msg)
                    this.fetchData()
                } else {
                    this.$error(res.data.msg)
                }
            })
        },
        createTables() {
            createTables().then(res => {
                if (res.data.success) {
                    this.$success(res.data.msg)
                } else {
                    this.$error(res.data.msg)
                }
            })
        },
        getComponentIcon(cellValue) {
            return getComponentIcon(cellValue)
        },
        getSensorColor(value) {
            if (value) {
                return getSensorOptions().find(item => item.value === value).color
            }
        },
        fmtSensor(value) {
            if (value) {
                return getSensorOptions().find(item => item.value === value).label
            }
        },
        stationFilter(value, row) {
            return row.station === value
        }
    },
    created() {
        this.fetchData()
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
.tag-link span {
    font-size: 12px;
    font-weight: 0;
}

.demo-table-expand {
    font-size: 0;
}

.demo-table-expand label {
    width: 90px;
    color: #99a9bf;
}

.demo-table-expand .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 32%;
}

.button-column {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
</style>
