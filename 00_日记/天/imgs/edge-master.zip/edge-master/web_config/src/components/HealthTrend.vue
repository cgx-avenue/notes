<template>
    <div class="trend-container">
        <el-row class="echart-title">
            <el-col :span="12">
                <span class="title-detail">近三月数据趋势（反馈数据分散程度和变化趋势）</span>
            </el-col>
        </el-row>
        <el-row style="margin-top: 20px">
            <el-col :span="16">
                <div :id="tableName + type" style="width: 100%; height: 400px" v-loading="loading"></div>
            </el-col>
            <el-col :span="7">
                <el-table :data="trendTableData" style="width: 100%">
                    <el-table-column prop="month" label="月份"></el-table-column>
                    <el-table-column prop="total" label="样本总量"></el-table-column>
                    <el-table-column prop="percent" label="大于阈值%"></el-table-column>
                </el-table>
            </el-col>
        </el-row>
    </div>
</template>

<script>
import { healthTrend } from '@/apis'
import * as echarts from 'echarts'

export default {
    name: 'HealthTrend',
    props: {
        tableName: String
        // features: {
        //     type: Array,
        //     default: () => []
        // }
    },
    data() {
        return {
            type: 'trend',
            loading: false,
            trendData: [],
            trendTableData: [],
            last3Months: []
        }
    },
    watch: {},
    computed: {},
    methods: {
        getLast3Months() {
            //创建现在的时间
            let data = new Date()
            //获取年
            let year = data.getFullYear()
            //获取月
            let mon = data.getMonth() + 2
            for (let i = 0; i < 3; i++) {
                mon = mon - 1
                if (mon <= 0) {
                    year = year - 1
                    mon = mon + 12
                }
                if (mon < 10) {
                    mon = '0' + mon
                }
                this.last3Months[i] = year + '-' + mon
            }
            this.last3Months.reverse()
        },
        drawTrend() {
            if (!this.tableName) {
                this.$error('没有组件信息')
                return
            }

            this.loading = true
            healthTrend(this.tableName).then(res => {
                if (res.data.success) {
                    this.trendData = res.data.data
                    // 填充统计表格数据
                    this.trendTableData = []
                    for (let i = 0; i < this.last3Months.length; i++) {
                        let percent = '未设置高级阈值'
                        if (typeof this.trendData.thresholds[i] === 'number') {
                            percent = ((this.trendData.thresholds[i] * 100) / this.trendData.totals[i]).toFixed(6)
                        }
                        this.trendTableData.push({
                            month: this.last3Months[i],
                            total: this.trendData.totals[i],
                            percent: percent
                        })
                    }
                    this.$nextTick(() => this.echartsInitTrend())
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },
        echartsInitTrend() {
            //初始化数据
            let myChart = echarts.init(document.getElementById(this.tableName + this.type))
            // 指定图表的配置项和数据
            let option = {
                tooltip: {},
                legend: {
                    show: true,
                    data: ['样本数量', '最大值', '最小值', '均值', '中位数', '标准差', '下四分位数', '上四分位数', '大于阈值'],
                    selected: {
                        样本数量: false,
                        最大值: false,
                        大于阈值: false
                    }
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: this.last3Months
                },
                yAxis: {
                    //name: 'RMS mm/s2',
                    axisLine: {
                        show: true
                    }
                },
                series: [
                    {
                        name: '样本数量',
                        type: 'line',
                        data: this.trendData.totals
                    },
                    {
                        name: '最大值',
                        type: 'line',
                        data: this.trendData.maxs
                    },
                    {
                        name: '最小值',
                        type: 'line',
                        data: this.trendData.mins
                    },
                    {
                        name: '均值',
                        type: 'line',
                        data: this.trendData.means
                    },
                    {
                        name: '中位数',
                        type: 'line',
                        data: this.trendData.medians
                    },
                    {
                        name: '标准差',
                        type: 'line',
                        data: this.trendData.stds
                    },
                    {
                        name: '下四分位数',
                        type: 'line',
                        data: this.trendData.q1s
                    },
                    {
                        name: '上四分位数',
                        type: 'line',
                        data: this.trendData.q3s
                    },
                    {
                        name: '大于阈值',
                        type: 'line',
                        data: this.trendData.thresholds
                    }
                ]
            }
            // 清除缓存
            myChart.clear()
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option)
        }
    },
    created() {
        this.getLast3Months()
        this.drawTrend()
    }
}
</script>
<style>
.trend-container {
    width: 100%;
    margin-top: 40px;
}
.echart-title {
    text-align: left;
}
.title-detail {
    font-size: 17px;
}
</style>
