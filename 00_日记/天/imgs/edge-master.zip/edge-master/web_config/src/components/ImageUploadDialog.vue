<template>
    <el-dialog :title="stationName + ' 设备图片上传'" v-model="dialogVisible" width="40%" :destroy-on-close="true" :before-close="handleClose">
        <el-upload v-loading="loading" :file-list="fileList" action :on-change="handleChange" ref="uploadRef" name="files" :auto-upload="false" :show-file-list="false" accept=".jpg,.jpeg,.png">
            <!-- <template #trigger> -->
            <el-button type="success" size="small">选择图片</el-button>
            <!-- </template> -->
            <!-- <el-button size="small" style="visibility: hidden">隐藏</el-button>
            <el-button type="danger" size="small" @click="handleRemove">删除图片</el-button> -->
            <template #tip>
                <div class="el-upload__tip">图片只接受.jpg,.jpeg,.png格式，必须小于 5MB</div>
            </template>
        </el-upload>
        <el-image v-if="imgSrc != ''" style="max-width: 50%; margin-top: 10px;" :src="imgSrc" :zoom-rate="1.2" :max-scale="7" :min-scale="0.2" :preview-src-list="[imgSrc]" :initial-index="4" fit="cover" />

        <template #footer>
            <div style="text-align: right">
                <el-button @click="submitImage" size="small" type="primary">上传</el-button>
                <el-button @click="handleClose" size="small">关闭</el-button>
            </div>
        </template>
    </el-dialog>
</template>

<script>
import { ElMessage } from 'element-plus'
import { uploadImage } from '@/apis'

export default {
    name: 'ImageUploadDialog',
    props: {
        stationName: String,
        visible: {
            type: Boolean,
            default: false
        },
        imgData: {
            type: String,
            default: ''
        }
    },
    data() {
        return {
            loading: false,
            dialogVisible: false,
            disabled: false,
            previewDialogVisible: false,
            fileList: [],
            imgSrc: '',
            dialogImageUrl: ''
        }
    },
    watch: {
        visible: function (newVisible, oldVisible) {
            this.dialogVisible = newVisible
            if (newVisible && !oldVisible) {
                // this.fetchData()
                this.imgSrc = this.imgData == '' ? '' : `data:image/jpeg;base64,${this.imgData}`
            }
        }
    },
    methods: {
        beforeUpload(file) {
            const isJPG = file.type === 'image/jpeg'
            const isPNG = file.type === 'image/png'
            const isLt10M = file.size / 1024 / 1024 < 10

            if (!isJPG && !isPNG) {
                ElMessage.error('上传图片只能是 JPG/PNG 格式!')
                return false
            }
            if (!isLt10M) {
                ElMessage.error('上传图片大小不能超过 10MB!')
                return false
            }
            return true
        },
        handleRemove() {
            this.imgSrc = ''
            this.fileList = []
        },
        handleClose() {
            this.$emit('update:visible', false)
            this.$refs['uploadRef'].clearFiles()
            this.imgSrc = ''
            this.fileList = []
        },
        handleChange(file, fileList) {
            this.imgSrc = URL.createObjectURL(file.raw)
            this.fileList[0] = file
        },

        // fetchData() {
        //     this.loading = true
        //     getStationImage(this.stationName).then(res => {
        //         if (res.data.success) {
        //             if (res.data.data) {
        //                 this.imgSrc = `data:image/jpeg;base64,${res.data.data}`
        //             }
        //         } else {
        //             this.$error(res.data.msg)
        //         }
        //         this.loading = false
        //     })
        // },

        submitImage() {
            if (this.fileList.length <= 0 && this.imgSrc == '') {
                ElMessage.error('请先上传图片！')
                return
            }
            if (this.fileList.length <= 0 && this.imgSrc != '') {
                this.handleClose()
                return
            }
            const form = new FormData()
            form.append('station_name', this.stationName)
            form.append('file', this.fileList[0].raw)
            this.loading = true
            uploadImage(form).then(res => {
                if (res && res.data.success) {
                    this.$success(res.data.msg)
                    //清空数据
                    this.$refs['uploadRef'].clearFiles()
                    this.fileList = []
                    this.imgSrc = ''
                    this.$emit('update:visible', false)
                    this.$emit('uploadComplete')
                } else {
                    this.$error(res ? res.data.msg : '图片上传失败')
                }
                this.loading = false
            })
        }
    },
    created() {}
}
</script>
<style></style>
