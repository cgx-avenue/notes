<template>
    <el-dialog :title="title" v-model="dialogVisible" @close="onClose" width="80%" center destroy-on-close>
        <div id="echarts" style="width: 100%; height: 400px" v-loading="loading"></div>
    </el-dialog>
</template>
<script>
import { getSampleRmsById, getSchemaById, viewSampleRms } from '@/apis'
import * as echarts from 'echarts'
import moment from 'moment'

export default {
    name: 'VibViewDialog',
    props: {
        id: String,
        title: String,
        schemaId: String,
        startTime: String,
        endTime: String,
        visible: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            rmsData: [],
            loading: true,
            dialogVisible: false,
            selectedDate: []
        }
    },
    watch: {
        visible: function (newVisible, oldVisible) {
            this.dialogVisible = newVisible
            if (newVisible && !oldVisible) {
                this.drawScatter()
                this.selectedDate = []
            }
        }
    },
    methods: {
        drawScatter() {
            this.loading = true

            if (this.id) {
                getSampleRmsById(this.id).then(res => {
                    if (res.data.success) {
                        this.rmsData = res.data.data
                        getSchemaById(this.schemaId).then(res => {
                            let feature = res.data.data.features.find(feature => feature.feature.toLowerCase() === 'vibrms')
                            this.$nextTick(() => this.echartsInit(feature.middle, feature.high))
                        })
                    } else {
                        this.$error(res.data.msg)
                    }
                    this.loading = false
                })
            } else {
                //如果id不存在，则是预览
                let form = {
                    start_time: this.startTime,
                    end_time: this.endTime,
                    schema_id: this.schemaId
                }
                viewSampleRms(form).then(res => {
                    if (res.data.success) {
                        this.rmsData = res.data.data
                        getSchemaById(this.schemaId).then(res => {
                            let feature = res.data.data.features.find(feature => feature.feature.toLowerCase() === 'vibrms')
                            this.$nextTick(() => this.echartsInit(feature.middle, feature.high))
                        })
                    } else {
                        this.$error(res.data.msg)
                    }
                    this.loading = false
                })
            }
        },
        echartsInit(middle, high) {
            let myChart = echarts.init(document.getElementById('echarts'))
            // 指定图表的配置项和数据
            let markLineData = []
            if (middle) {
                markLineData.push({
                    name: this.$t('middle_threshold'),
                    yAxis: middle,
                    silent: true,
                    lineStyle: {
                        type: 'solid',
                        color: '#e6a23c'
                    },
                    label: {
                        position: 'end',
                        formatter: this.$t('middle_threshold')
                    },
                    tooltip: {
                        trigger: 'item',
                        formatter: function (params) {
                            return `${params.data.name}：<b>${params.data.value}<b/>`
                        }
                    }
                })
            }
            if (high) {
                markLineData.push({
                    name: this.$t('high_threshold'),
                    yAxis: high,
                    silent: true,
                    lineStyle: {
                        type: 'solid',
                        color: '#f56c6c'
                    },
                    label: {
                        position: 'end',
                        formatter: this.$t('high_threshold')
                    },
                    tooltip: {
                        trigger: 'item',
                        formatter: function (params) {
                            return `${params.data.name}：<b>${params.data.value}<b/>`
                        }
                    }
                })
            }
            let option = {
                tooltip: {
                    trigger: 'axis'
                },
                // legend: {
                //   show: true,
                //   data: ['运动', '静止']
                // },
                xAxis: {
                    name: this.$t('time'),
                    type: 'time',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        formatter: function (value) {
                            return moment(new Date(value)).format('HH:mm:ss')
                        }
                    }
                },
                yAxis: {
                    name: 'RMS mm/s2',
                    axisLine: {
                        show: true
                    }
                },
                dataZoom: [
                    {
                        type: 'slider'
                    },
                    {
                        type: 'inside'
                    }
                ],
                animation: false,
                series: [
                    // {
                    //   name: '运动',
                    //   symbolSize: 5,
                    //   type: 'scatter',
                    //   data: this.rmsData.filter(data => data[2] === true),
                    //   itemStyle: {
                    //     normal: {
                    //       color: 'red'
                    //     }
                    //   },
                    //   markLine: {
                    //     symbol: "none",
                    //     data: markLineData
                    //   }
                    // },
                    {
                        // name: '静止',
                        symbolSize: 5,
                        type: 'scatter',
                        data: this.rmsData,
                        itemStyle: {
                            normal: {
                                color: 'blue'
                            }
                        },
                        large: true,
                        markLine: {
                            symbol: 'none',
                            data: markLineData
                        }
                    }
                ]
            }
            if (this.startTime && this.endTime) {
                option.brush = {
                    toolbox: ['lineX', 'clear'],
                    xAxisIndex: 'all',
                    yAxisIndex: 'all',
                    brushType: 'lineX'  // 固定为lineX类型
                }
            }
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option)

            myChart.on('brushStart', function () {
                // 开始选择时关闭大数据模式
                myChart.setOption({
                    series: [{
                        large: false
                    }]
                });
            });

            myChart.on('brushEnd', function () {
                // 选择结束后重新开启大数据模式
                myChart.setOption({
                    series: [{
                        large: true
                    }]
                });
            });
            // 添加brushSelected事件监听器
            let that = this
            myChart.on('brushSelected', function (params) {
                let selectedData = []
                let brushComponent = params.batch[0]
                // console.log(brushComponent)
                for (let sIdx = 0; sIdx < brushComponent.selected.length; sIdx++) {
                    let selectedSeries = brushComponent.selected[sIdx]
                    let seriesIndex = selectedSeries.seriesIndex
                    // let seriesName = myChart.getOption().series[seriesIndex].name;
                    let dataIndex = selectedSeries.dataIndex
                    let seriesData = myChart.getOption().series[seriesIndex].data
                    for (let i = 0; i < dataIndex.length; i++) {
                        selectedData.push(seriesData[dataIndex[i]])
                    }
                }

                if (selectedData.length > 0) {
                    that.selectedDate[0] = selectedData[0][0]
                    that.selectedDate[1] = selectedData[selectedData.length - 1][0]
                } else {
                    that.selectedDate = []
                }
                // 处理完选中数据后重新开启大数据模式
                myChart.setOption({
                    series: [{
                        large: true
                    }]
                })
            })
        },

        onClose() {
            this.$emit('changeDatetime', this.selectedDate)
            this.$emit('update:visible', false)
        }
    },
    created() { }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style></style>
