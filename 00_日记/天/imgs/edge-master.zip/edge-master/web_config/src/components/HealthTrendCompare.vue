<template>
    <div class="compare-container">
        <el-row class="echart-title">
            <el-col :span="12">
                <span class="title-detail">数据指标对比（反馈数据分散程度和集中趋势）</span>
            </el-col>
        </el-row>
        <el-row>
            <el-col :span="20" :offset="2">
                <el-table :data="compareTableData" style="width: 100%" v-loading="loading">
                    <el-table-column prop="cycle">
                        <template #default="scope">
                            {{ formatCycle(scope.row.cycle) }}
                        </template>
                    </el-table-column>
                    <el-table-column prop="max" label="最大值">
                        <template #default="scope">
                            <span>{{ scope.row.max }}</span>
                            <!-- 只在第一行（index为0）添加图标 -->
                            <template v-if="scope.$index === 0">
                                <el-icon v-if="scope.row.max > getSecondRowValue(scope.column.property)"
                                    style="color: red;">
                                    <Top />
                                </el-icon>
                                <el-icon v-else-if="scope.row.max < getSecondRowValue(scope.column.property)"
                                    style="color: green;">
                                    <Bottom />
                                </el-icon>
                            </template>
                        </template>
                    </el-table-column>
                    <el-table-column prop="min" label="最小值">
                        <template #default="scope">
                            <span>{{ scope.row.min }}</span>
                            <!-- 只在第一行（index为0）添加图标 -->
                            <template v-if="scope.$index === 0">
                                <el-icon v-if="scope.row.min > getSecondRowValue(scope.column.property)"
                                    style="color: red;">
                                    <Top />
                                </el-icon>
                                <el-icon v-else-if="scope.row.min < getSecondRowValue(scope.column.property)"
                                    style="color: green;">
                                    <Bottom />
                                </el-icon>
                            </template>
                        </template>
                    </el-table-column>
                    <el-table-column prop="mean" label="均值">
                        <template #default="scope">
                            <span>{{ scope.row.mean }}</span>
                            <!-- 只在第一行（index为0）添加图标 -->
                            <template v-if="scope.$index === 0">
                                <el-icon v-if="scope.row.mean > getSecondRowValue(scope.column.property)"
                                    style="color: red;">
                                    <Top />
                                </el-icon>
                                <el-icon v-else-if="scope.row.mean < getSecondRowValue(scope.column.property)"
                                    style="color: green;">
                                    <Bottom />
                                </el-icon>
                            </template>
                        </template>
                    </el-table-column>
                    <el-table-column prop="median" label="中位数">
                        <template #default="scope">
                            <span>{{ scope.row.median }}</span>
                            <!-- 只在第一行（index为0）添加图标 -->
                            <template v-if="scope.$index === 0">
                                <el-icon v-if="scope.row.median > getSecondRowValue(scope.column.property)"
                                    style="color: red;">
                                    <Top />
                                </el-icon>
                                <el-icon v-else-if="scope.row.median < getSecondRowValue(scope.column.property)"
                                    style="color: green;">
                                    <Bottom />
                                </el-icon>
                            </template>
                        </template>
                    </el-table-column>
                    <el-table-column prop="std" label="标准差">
                        <template #default="scope">
                            <span>{{ scope.row.std }}</span>
                            <!-- 只在第一行（index为0）添加图标 -->
                            <template v-if="scope.$index === 0">
                                <el-icon v-if="scope.row.std > getSecondRowValue(scope.column.property)"
                                    style="color: red;">
                                    <Top />
                                </el-icon>
                                <el-icon v-else-if="scope.row.std < getSecondRowValue(scope.column.property)"
                                    style="color: green;">
                                    <Bottom />
                                </el-icon>
                            </template>
                        </template>
                    </el-table-column>
                    <el-table-column prop="q1" label="下四分位数">
                        <template #default="scope">
                            <span>{{ scope.row.q1 }}</span>
                            <!-- 只在第一行（index为0）添加图标 -->
                            <template v-if="scope.$index === 0">
                                <el-icon v-if="scope.row.q1 > getSecondRowValue(scope.column.property)"
                                    style="color: red;">
                                    <Top />
                                </el-icon>
                                <el-icon v-else-if="scope.row.q1 < getSecondRowValue(scope.column.property)"
                                    style="color: green;">
                                    <Bottom />
                                </el-icon>
                            </template>
                        </template>
                    </el-table-column>
                    <el-table-column prop="q3" label="上四分位数">
                        <template #default="scope">
                            <span>{{ scope.row.q3 }}</span>
                            <!-- 只在第一行（index为0）添加图标 -->
                            <template v-if="scope.$index === 0">
                                <el-icon v-if="scope.row.q3 > getSecondRowValue(scope.column.property)"
                                    style="color: red;">
                                    <Top />
                                </el-icon>
                                <el-icon v-else-if="scope.row.q3 < getSecondRowValue(scope.column.property)"
                                    style="color: green;">
                                    <Bottom />
                                </el-icon>
                            </template>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
        </el-row>
        <el-row>
            <el-col :span="20" :offset="2" style="margin-top: 10px; font-size: 12px">
                <span>* 四分位数是将时间区间的数据从小到大排序后，处于25%，50%和75%位置上的数据。</span><br>
                <span>- 下四分位数：即所观测时间区间内的数据有25%的数据小于该值；</span><br>
                <span>- 中位数 ：即所观测时间区间内的数据有50%的数据小于等于该值；</span><br>
                <span>- 上四分位数：即所观测时间区间内的数据有75%的数据小于该值；</span><br>
            </el-col>
        </el-row>
    </div>
</template>

<script>
import { healthCompare } from '@/apis'

export default {
    name: 'HealthTrendCompare',
    props: {
        tableName: String
    },
    data() {
        return {
            loading: false,
            compareTableData: []
        }
    },
    watch: {},
    computed: {},
    methods: {
        getSecondRowValue(property) {
            if (this.compareTableData.length < 2) return 0
            return this.compareTableData[1][property]
        },
        formatCycle(cycle) {
            if (cycle == 7) return '近一周数据'
            if (cycle == 30) return '近一月数据'
            return ''
        },
        fectchData() {
            //校验表单
            if (!this.tableName) {
                this.$error('没有组件信息')
                return
            }
            this.loading = true
            healthCompare(this.tableName).then(res => {
                if (res.data.success) {
                    this.compareTableData = res.data.data
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        }
    },
    created() {
        this.fectchData()
    }
}
</script>
<style>
.compare-container {
    width: 100%;
}
.echart-title {
    text-align: center;
}
.title-detail {
    font-size: 17px;
}
</style>
