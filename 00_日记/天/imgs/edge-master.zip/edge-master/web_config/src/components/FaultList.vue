<template>
    <el-table :data="tableData" stripe border v-loading="loading" style="width: 100%">
        <el-table-column min-width="15%" :label="$t('fault')" :filters="codeFilters" :filter-method="codeFilter">
            <template #default="scope">
                <el-tag disable-transitions :type="scope.row.code_level">
                    {{ scope.row.code }}
                </el-tag>
                <span>{{ ' ' + scope.row.code_name }}</span>
            </template>
        </el-table-column>
        <el-table-column min-width="15%" prop="station" :label="$t('station')" :filters="stationFilters" :filter-method="stationFilter"> </el-table-column>
        <el-table-column min-width="15%" prop="component" :label="$t('component')">
            <template #default="scope">
                <i v-bind:class="getComponentIcon(scope.row.component)"></i>
                {{ $t(scope.row.component) }}
            </template>
        </el-table-column>
        <el-table-column min-width="15%" prop="start_time" :label="$t('startTime')" :formatter="dateFormatter"></el-table-column>
        <el-table-column min-width="15%" prop="end_time" :label="$t('endTime')" :formatter="dateFormatter"></el-table-column>
        <el-table-column min-width="10%" prop="origin" :label="$t('origin')"></el-table-column>
        <el-table-column min-width="20%">
            <template #default="scope">
                <el-button size="mini" @click="openDialog(scope.row)">{{ $t('view') }}</el-button>
                <el-popconfirm :title="$t('confirmInfo')" :confirm-button-text="$t('confirm')" :cancel-button-text="$t('cancel')" @confirm="confirm(scope.row.id)">
                    <template #reference>
                        <el-button size="mini" type="primary">{{ $t('confirm') }}</el-button>
                    </template>
                </el-popconfirm>
                <el-popconfirm :title="$t('confirmMis')" :confirm-button-text="$t('confirm')" :cancel-button-text="$t('cancel')" @confirm="misjudgment(scope.row.id)">
                    <template #reference>
                        <el-button size="mini" type="danger">{{ $t('misinformation') }}</el-button>
                    </template>
                </el-popconfirm>
            </template>
        </el-table-column>
    </el-table>
    <VibViewDialog :title="dialog.title" :id="dialog.id" :schemaId="dialog.schemaId" v-model:visible="dialog.visible"> </VibViewDialog>
</template>

<script>
import { getFaults, confirmFault, misjudgmentFault, getComponentIcon } from '@/apis'
import moment from 'moment'
import VibViewDialog from '@c/VibViewDialog'

export default {
    name: 'FaultList',
    props: {},
    components: { VibViewDialog },
    data() {
        return {
            tempData: [],
            tableData: [],
            loading: true,
            dialog: {},

            stationFilters: []
        }
    },
    watch: {},
    computed: {
        codeFilters() {
            // 在这里定义你的过滤器数组
            return [
                { text: this.$t('health'), value: 'success' },
                { text: this.$t('middle_fault'), value: 'warning' },
                { text: this.$t('high_fault'), value: 'danger' }
            ]
        }
    },
    methods: {
        fetchData() {
            this.loading = true
            getFaults().then(res => {
                if (res.data.success) {
                    this.tempData = res.data.data ? res.data.data : []
                    this.tableData = this.tempData
                    this.initFilters()
                } else {
                    this.$error(res.data.msg)
                }
                this.loading = false
            })
        },
        initFilters() {
            let filters = new Set()
            this.tableData.forEach(item => filters.add(item.station))
            this.stationFilters = Array.from(filters).map(item => {
                return { text: item, value: item }
            })
        },
        confirm(id) {
            confirmFault(id).then(res => {
                if (res.data.success) {
                    this.$success(res.data.msg)
                    this.fetchData()
                } else {
                    this.$error(res.data.msg)
                }
            })
        },
        misjudgment(id) {
            misjudgmentFault(id).then(res => {
                if (res.data.success) {
                    this.$success(res.data.msg)
                    this.fetchData()
                } else {
                    this.$error(res.data.msg)
                }
            })
        },
        getComponentIcon(cellValue) {
            return getComponentIcon(cellValue)
        },
        dateFormatter: function (row, column) {
            let date = row[column.property]
            if (date === undefined) {
                return ''
            }
            return moment(date).utcOffset(0).format('YYYY-MM-DD HH:mm:ss')
        },
        openDialog(row) {
            this.dialog.id = row.id
            this.dialog.schemaId = row.schema_id
            this.dialog.title = row.station + ' ' + this.$t(row.component) + ' - ' + row.code + ' ' + row.code_name
            this.dialog.visible = true
        },
        stationFilter(value, row) {
            return row.station === value
        },
        codeFilter(value, row) {
            return row.code_level === value
        }
    },
    created() {
        this.fetchData()
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style></style>
