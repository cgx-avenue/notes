import { createRouter, createWebHistory } from 'vue-router'
import Login from "@c/Login"
import SchemaDetail from "@c/SchemaDetail"
import SchemaList from "@c/SchemaList"
import SampleDetail from "@c/SampleDetail"
import SampleList from "@c/SampleList"
import CodeList from "@c/CodeList"
import CodeDetail from "@c/CodeDetail"
import DiagnosisList from "@c/DiagnosisList"
import Report from "@c/Report"
import FaultList from "@c/FaultList"
import HealthReport from '@c/HealthReport'
import i18n from './i18n' // 导入i18n实例

const routerHistory = createWebHistory()

const router = createRouter({
  history: routerHistory,
  routes: [
    {
      path: '/',
      redirect: 'schemas'
    },
    {
      path: '/login',
      component: Login,
      meta: { title: 'login'}
    },
    {
      path: '/schemas/:id',
      component: SchemaDetail,
      meta: { title: 'schemaDetail'}
    },
    {
      path: '/schemas',
      component: SchemaList,
      meta: { title: 'stationManagement'}
    },
    {
      path: '/diagnosis',
      component: DiagnosisList,
      meta: { title: 'diagnosticAlgorithm'}
    },
    {
      path: '/samples/:id',
      component: SampleDetail,
      meta: { title: 'sampleDetail'}
    },
    {
      path: '/samples',
      component: SampleList,
      meta: { title: 'sampleManagement'}
    },
    {
      path: '/faults',
      component: FaultList,
      meta: { title: 'faultManagement'}
    },
    {
      path: '/codes',
      component: CodeList,
      meta: { title: 'faultCodes'}
    },
    {
      path: '/codes/:code',
      component: CodeDetail,
      meta: { title: 'faultDetail'}
    },
    {
      path: '/reports',
      component: Report,
      meta: { title: 'graphicalReports'}
    },
    {
      path: '/health',
      component: HealthReport,
      meta: { title: '健康报告' }
    },
  ]
})

const updateDocumentTitle = (t, route) => {
  if (route.meta.title) {
    document.title = t(route.meta.title) + ' | DaaS Web Config'
  }
}


router.beforeEach((to, from, next) => {
  /* 路由发生变化修改页面title */
  updateDocumentTitle(i18n.global.t, to)
  next()
})

export { updateDocumentTitle }
export default router