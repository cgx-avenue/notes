import { createApp } from "vue";
import store from "./store";
import router from "./router";
import App from "./App.vue";
import installElementPlus from "./plugins/element";
import installMessage from "./plugins/message";
import installAxios from "./plugins/axios";
import { QuillEditor } from '@vueup/vue-quill'
import '@vueup/vue-quill/dist/vue-quill.snow.css';
import '@vueup/vue-quill/dist/vue-quill.bubble.css';
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import i18n from './i18n'
import "./styles/index.scss";
import "./assets/icon/iconfont.css";
import * as math from "mathjs";

const app = createApp(App);
installElementPlus(app);
installMessage(app, i18n.global.t);
installAxios(app);
app.use(store)
app.use(i18n)
app.use(router);
app.component('QuillEditor', QuillEditor)
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
    app.component(key, component)
}
app.config.globalProperties.$math = math;
app.mount("#app");
