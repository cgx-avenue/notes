yarn build
docker build -t daas/web-config .