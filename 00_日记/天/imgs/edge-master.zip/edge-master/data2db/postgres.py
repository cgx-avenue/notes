import psycopg2
from DBUtils.PooledDB import PooledDB
from log import logger
from config import CONFIG


class DataBase:
    disconnected = False

    # 连接
    def __init__(self):
        try:
            self.pool = PooledDB(creator=psycopg2,
                                 mincached=10,
                                 blocking=True,
                                 host=CONFIG['DATABASE']['HOST'],
                                 port=CONFIG['DATABASE']['PORT'],
                                 database=CONFIG['DATABASE']['DATABASE'],
                                 user=CONFIG['DATABASE']['USER'],
                                 password=CONFIG['DATABASE']['PASSWORD'])
            logger.info("establish database connection success")
        except Exception as e:
            logger.error('establish database connection error: ', exc_info=e)
            raise

    # 获取连接
    def get_connection(self):
        # 如果连接已经断开，重新建立连接
        if self.disconnected:
            if self.pool:
                self.pool.close()
            self.__init__()
        try:
            db = self.pool.connection()
            cur = db.cursor()
            # 连接成功，设置连接状态
            self.disconnected = False
            return db, cur
        except Exception as e:
            # 无效连接异常，设置连接状态为断开
            logger.error('get connection error: ', exc_info=e)
            self.disconnected = True
            raise

    # 取单条数据
    def query_one(self, sql):
        db, cur = self.get_connection()
        result = None
        try:
            cur.execute(sql)
            result = cur.fetchone()
        except Exception as e:
            logger.error("query one error: ", exc_info=e)
            self.disconnected = True
        finally:
            if cur:
                cur.close()
            if db:
                db.close()
        return result

    # 取所有数据
    def query_all(self, sql):
        db, cur = self.get_connection()
        result = None
        try:
            cur.execute(sql)
            result = cur.fetchall()
        except Exception as e:
            logger.error("query all error: ", exc_info=e)
            self.disconnected = True
        finally:
            if cur:
                cur.close()
            if db:
                db.close()
        return result

    # 执行sql
    def exec(self, sql):
        db, cur = self.get_connection()
        try:
            cur.execute(sql)
            db.commit()
        except Exception as e:
            db.rollback()
            logger.error("execute sql error: ", exc_info=e)
            self.disconnected = True
        finally:
            if cur:
                cur.close()
            if db:
                db.close()


db = DataBase()