import json
import logging


def load_config():
    f = open("./config.json", encoding='utf-8')
    config = json.load(f)
    return config


CONFIG = load_config()


'''
DEBUG
INFO
WARNING
ERROR
CRITICAL
'''


def get_log_level():
    log_level = CONFIG['LOG_LEVEL']
    if log_level == 'DEBUG':
        return logging.DEBUG
    elif log_level == 'INFO':
        return logging.INFO
    elif log_level == 'WARNING':
        return logging.WARNING
    elif log_level == 'ERROR':
        return logging.ERROR
    elif log_level == 'CRITICAL':
        return logging.CRITICAL
    else:
        return logging.NOTSET


LOG_LEVEL = get_log_level()
