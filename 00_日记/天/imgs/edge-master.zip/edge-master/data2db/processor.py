import queue
import json
import time

from postgres import db
from config import CONFIG
from log import logger

feature_map = {}
table_map = {}
timeout_map = {}
last_check_time = 0


def process(table_name, payload):
    # 校验缓存中是否有超时的数据
    check_timeout_q()
    # 如果表名没有在缓存，初始化
    if table_name not in table_map:
        table_map[table_name] = queue.Queue()
        timeout_map[table_name] = int(time.time())
    # 从缓存里面获取每个表对应的Queue, mqtt传过来的数据线放加入q, 当q里面数量达到一定的时候，批量取出数据并且入库
    q = table_map[table_name]
    q.put(json.loads(payload))
    # 如果当前队列数量大于批大小，取出数据，放入线程池进行批量插入
    if q.qsize() > CONFIG['BATCH_SIZE']:
        empty_queue(table_name, q, CONFIG['BATCH_SIZE'])


def empty_queue(table_name, q, size):
    table_values = []
    for i in range(size):
        table_values.append(q.get())
    try:
        batch_insert(table_name, table_values)
        timeout_map[table_name] = int(time.time())
    except Exception as e:
        logger.error("add to thread pool error: ", exc_info=e)


# 检查队列里面的数据是否超时，如果长时间没有到达batch大小，依然进行入库操作
def check_timeout_q():
    now = int(time.time())
    global last_check_time
    if last_check_time == 0:
        last_check_time = now
        return
    # 比如配置的超时时间是20s，那么最多10s检查一次是否超时
    if (now - last_check_time) < CONFIG['TIMEOUT'] / 2:
        return
    # 设置最后检查时间为当前时间
    last_check_time = now
    for key in timeout_map.keys():
        last_update = timeout_map[key]
        if last_update + CONFIG['TIMEOUT'] > now:
            q = table_map[key]
            empty_queue(key, q, q.qsize())


def batch_insert(table_name, table_values, retry=0):
    if len(table_values) == 0:
        return
    # 最多重试3次
    if retry > CONFIG['RETRY_TIMES']:
        logger.error("insert failed after tried for {} times, table: {}, values: {}, ".format(retry - 1, table_name, table_values))
        return
    # 重试的时候
    if retry != 0:
        time.sleep(CONFIG['RETRY_DELAY'])
        logger.info("retry batch insert data {} for {} times".format(table_name, retry))
    try:
        # 根据values获取字段名称
        fields = [key for key, value in table_values[0].items()]
        # 准备sql前半部分
        sql = "insert into " + str.lower(table_name) + " ("
        for field in fields:
            sql = sql + str.lower(field) + ","
        sql = sql[:-1] + ") values "
        # 拼接sql values部分
        insert_values = ""
        for value in table_values:
            sb = ""
            for field in fields:
                sb += "'{}',".format(value[field])
            insert_values = insert_values + "(" + sb[:-1] + "),"

        sql = sql + insert_values[:-1] +' ON CONFLICT ("timestamp") DO NOTHING'
        db.exec(sql)
        # 插入数据到表
        logger.info("batch insert data {} for the {}rd time".format(table_name, retry))
        logger.debug("insert data {}, value {}".format(table_name, insert_values))
    except Exception as e:
        logger.error("batch insert error, table: {}, value: {} : ".format(table_name, table_values), exc_info=e)
        batch_insert(table_name, table_values, retry + 1)
