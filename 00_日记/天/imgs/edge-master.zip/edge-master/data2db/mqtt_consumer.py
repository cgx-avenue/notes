import paho.mqtt.client as mqtt
from log import logger
import random
from config import CONFIG, LOG_LEVEL
import processor
# import multiprocessing

TOPIC_PREFIX = "data/"


# The callback for when the client receives a CONNACK response from the server.
def on_connect(client, userdata, flags, rc):
    logger.debug("Connected with result code "+str(rc))

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    client.subscribe(TOPIC_PREFIX+'#')


def on_log(client, userdata, level, buf):
    logger.debug("mqtt log: " + buf)


# The callback for when a PUBLISH message is received from the server.
def on_message(client, userdata, msg):
    topic = msg.topic
    # topic = "prefix/tablename"
    paths = topic.split('/')
    if not paths[0] + '/' == TOPIC_PREFIX:
        return
    if len(paths) > 1:
        table_name = paths[1]
    else:
        return
    # 发送到处理单元处理数据
    processor.process(table_name, msg.payload)


# but note that the client id must be unique on the broker. Leaving the client
# id parameter empty will generate a random id for you.
# cleanSession 设为false，客户端掉线后 服务器端不会清除session，
# 当重连后可以接收之前订阅主题的消息。当客户端上线后会接受到它离线的这段时间的消息
my_client = mqtt.Client(clean_session=True, client_id=f'data2db-{random.randint(0, 1000)}')


# 启动函数
def mqtt_run():
    my_client.on_connect = on_connect
    my_client.on_message = on_message
    my_client.on_log = on_log
    my_client.connect(CONFIG["MQTT"]["HOST"], CONFIG["MQTT"]["PORT"], CONFIG["MQTT"]["KEEP_ALIVE"])
    my_client.loop_forever(timeout=1.0, retry_first_connection=True)


if __name__ == '__main__':
    # multiprocessing.freeze_support()
    # 启动 MQTT
    mqtt_run()
