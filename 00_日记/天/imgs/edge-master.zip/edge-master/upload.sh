cd web_config
yarn build
cd ..
rsync -av -e ssh --exclude='*/node_modules/' --rsync-path="sudo rsync" ./* root@iotlab.live:/home/daas