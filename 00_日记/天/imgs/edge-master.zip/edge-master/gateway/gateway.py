from threads.daemon_thread import DaemonThread
# import multiprocessing



if __name__ == '__main__':
    # multiprocessing.freeze_support()
    DaemonThread().start()