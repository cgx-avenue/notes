from ..utils.util import gettime, formatmodify, dynamic_import
from ..utils.log import logger
from .base_protocol_thread import BaseProtocolThread
import time
import sys
import threading
from opcua import Client
import zmq


class ZmqThread(BaseProtocolThread):

    def get_client(self):
        context = zmq.Context()
        sub_socket = context.socket(zmq.SUB)
        return sub_socket

    def connect(self):
        if self._connected is False:
            try:
                self.sub_socket.connect(self.component.endpoint)
                self.sub_socket.setsockopt(zmq.SUBSCRIBE, b"")
                self._connected = True
            except Exception as e:
                log().logger.error("endpoint:"+self.end_point+"|ZMQ Server connect failed")
                self._connected = False
        return self._connected

    def get_data_from_server(self):
        body = {"timestamp": "'"+str(gettime())+"'"}
        try:
            msg_str = str(self.sub_socket.recv(), encoding='ascii')
            sub_msg_list = eval(msg_str)[-1]
            for feature in self.component.features:
                for submsg in sub_msg_list:
                    if submsg[0] == feature.address:
                        body[featrue.name] = formatmodify(submsg[1])
            if len(body.keys()) <= 1:
                return
            values_queue_dict[self.table_name].put(body)
        except Exception as ex:
            log().logger.error("endpoint:" + self.end_point + "|ZMQ can not find node ", ex)

    def thread_sleep(self):
        time.sleep(app_configs.data2dbInterval)
