from utils.log import logger
from utils.util import gettime
from threads.base_protocol_thread import BaseProtocolThread
import snap7



class S7(BaseProtocolThread):

    def __init__(self, schema):
        super().__init__(schema)

    def get_client(self):
        try:
            return snap7.client.Client()
        except Exception as e:
            logger.error("S7 client create failed: {}".format(self._table_name), exc_info=e)

    def connect(self):
        # snap7 获取client实例连接状态
        # self._client.get_connected
        if self._connected:
            return
        try:
            self._client.connect(address=self._host, rack=0, slot=3, tcpport=self._port)
            self._connected = True
            logger.info('Connected to s7 server: {}'.format(self._table_name))
        except:
            logger.error("S7 Server connect failed: {}".format(self._table_name), exc_info=True)
            self._connected = False
        return self._connected

    def get_data_from_server(self):
        # 获取当前时间
        payload = {'timestamp': str(gettime())}
        for feature in self._features:
            db_number = feature['address']['db_number']
            start = feature['address']['start']
            size = feature['address']['size']
            reading = self._client.db_read(db_number, start, size)
            # bytearray 转换成 string
            payload[feature['feature']] = str(reading, "utf-8")

        logger.debug('Push data to mqtt: {}'.format(payload))
        self.forward_msg(payload)


'''
{
    "vibDkw": "ns=2;s=SVW_CMS2000_1 VIB1 DKW",
    "vibRms": "ns=2;s=VIB1 RMS",
    "vibMax": "ns=2;s=VIB1 Peak",
    "vibKurtosis": "ns=2;s=VIB1 Kurtosis",
    "vibSkewness": "ns=2;s=VIB1 Skewness",
    "waveIndex": "ns=2;s=VIB1 WaveIndex",
    "peakIndex": "ns=2;s=VIB1 PeakIndex",
    "impulseIndex": "ns=2;s=VIB1 ImpulseIndex",
    "fftRms": "ns=2;s=VIB1 FFTRMS",
    "fftRms10": "ns=2;s=VIB1 FFTRMS-10",
    "fftRms200": "ns=2;s=VIB1 FFTRMS-200",
}
'''