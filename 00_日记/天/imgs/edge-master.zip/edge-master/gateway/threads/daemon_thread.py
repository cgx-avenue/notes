import threading
import time
from abc import ABCMeta
from utils.log import logger
from utils.postgres import db
from threads.modbus_thread import ModbustcpThread
from threads.mqtt_thread import MqttThread
from threads.opcua_thread import OpcuaThread
from threads.s7_thread import S7

PROMISE = {
    # 'ZMQ': ZmqThread,
    'OPCUA': OpcuaThread,
    'MODBUSTCP': ModbustcpThread,
    'MQTT': MqttThread,
    'S7': S7,
}


class DaemonThread(threading.Thread, metaclass=ABCMeta):
    _schema_ids = []

    def run(self):
        while True:
            schemas = db.query_all(
                "select id, station, sensor, component, protocol, host, port, topic, features from schema")
            id_list = [item[0] for item in schemas]
            schemas = [{
                'id': item[0],
                'station': item[1],
                'sensor': item[2],
                'component': item[3],
                'protocol': item[4],
                'host': item[5],
                'port': item[6],
                'topic': item[7],
                'features': item[8],
            } for item in schemas]

            # 找到新增的schema id，为其创建线程
            diff_list = set(id_list).difference(DaemonThread._schema_ids)  # id_list中有而_schema_ids中没有的差集
            DaemonThread._schema_ids = id_list
            if diff_list:
                threads = []
                for schema in schemas:
                    if schema['id'] in diff_list:
                        t = PROMISE[schema['protocol'].upper()](schema)
                        logger.info("gateway 新增线程: {}, {}, {}".format(schema['host'], schema['port'], schema['topic']))
                        threads.append(t)
                for thr in threads:
                    thr.start()
            time.sleep(1.0)