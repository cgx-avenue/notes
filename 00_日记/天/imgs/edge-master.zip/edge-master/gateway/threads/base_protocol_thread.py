import threading
import json
import time
from abc import ABCMeta, abstractmethod
from concurrent.futures import ThreadPoolExecutor
from utils.log import logger
from threads.sender import sender
from utils.postgres import db

executor = ThreadPoolExecutor(150)


class BaseProtocolThread(threading.Thread, metaclass=ABCMeta):

    def __init__(self, schema):
        super().__init__()
        self._table_name = str.lower('{}_{}_{}'.format(schema['station'], schema['sensor'], schema['component']))
        self._id = schema['id']
        self._host = schema['host']
        self._port = schema['port']
        self._topic = schema['topic']
        self._features = json.loads(schema['features'])
        self._connected = False
        self._client = self.get_client()
        self._survive = True

    @abstractmethod
    def connect(self):
        pass

    # 生成各协议对应的客户端
    @abstractmethod
    def get_client(self):
        pass

    # 各个协议获取数据的抽象方法，用于轮询获取数据的协议
    @abstractmethod
    def get_data_from_server(self):
        pass

    @classmethod
    def get_class(cls):
        return cls

    def thread_sleep(self):
        schema = db.query_one(
            "select id, station, sensor, component, protocol, host, port, topic, features from schema where id='{}'".format(
                self._id))
        # 如果本条线程schema id不存在，则立即终止
        if not schema:
            logger.info("gateway 删除线程: {}".format(self._id))
            self._survive = False
        # 如果本条线程的id存在，但host, port, topic发生变化，创建新线程后终止原有线程
        else:
            schema = {
                'id': schema[0],
                'station': schema[1],
                'sensor': schema[2],
                'component': schema[3],
                'protocol': schema[4],
                'host': schema[5],
                'port': schema[6],
                'topic': schema[7],
                'features': schema[8],
            }
            if schema['host'] != self._host or schema['port'] != self._port or schema['topic'] != self._topic:
                logger.info("gateway 更改线程: {}, {}, {}".format(schema['host'], schema['port'], schema['topic']))
                t = self.get_class()(schema)
                t.start()
                self._survive = False
        time.sleep(1.0)


    # 发送转换过的payload到data2db mqtt
    def forward_msg(self, payload):
        sender.forward_msg(self._table_name, payload)

    def run(self):
        while True:
            if not self._survive:
                break
            try:
                if self.connect():
                    self.get_data_from_server()
            except Exception as e:
                self._connected = False
                logger.error("Gateway error: ", exc_info=e)
            finally:
                self.thread_sleep()
