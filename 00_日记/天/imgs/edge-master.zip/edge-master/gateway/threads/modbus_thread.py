from utils.util import gettime
from utils.modbusutil import read_float, parse_function_code
from threads.base_protocol_thread import BaseProtocolThread
from utils.log import logger
import json
import modbus_tk.defines as cst
import modbus_tk.modbus_tcp as modbus_tcp


class ModbustcpThread(BaseProtocolThread):

    def __init__(self, schema):
        super().__init__(schema)

    def get_client(self):
        try:
            master = modbus_tcp.TcpMaster(host=self._host, port=self._port)
            master.set_timeout(5.0)
            self._connected = True
            return master
        except Exception as e:
            self._connected = False
            logger.error("MODBUSTCP master create failed: {}, {}".format(self._host, self._port), exc_info=e)

    def connect(self):
        if self._connected is False:
            try:
                # 当重新连接网络，还是用的旧客户端，拿不到数据，应该创建新的客户端
                self._client = self.get_client()
                status_value = self._client.execute(1, cst.READ_INPUT_REGISTERS, 1, 1)
                if status_value is not None:
                    self._connected = True
            except Exception as e:
                logger.error("MODBUSTCP Server connect failed: {}, {}".format(self._host, self._port))
                self._connected = False
        return self._connected

    # 读取modbus服务器寄存器的值
    def get_value(self, node):
        try:
            value = self._client.execute(node['slaveId'], parse_function_code(node['functionCode']), node['startAddress'], node['xquantity'])
            return self._getparsedic()[node['outputType']](value)
        except Exception as e:
            self._connected = False
            logger.error('Modbustcp addressError: {}, {}'.format(node['functionCode'], node['startAddress']), exc_info=e)

    def get_data_from_server(self):
        # 获取当前时间
        payload = {'timestamp': str(gettime())}
        # 获取数据点
        for feature in self._features:
            data_point = json.loads(feature['address'])
            payload[feature['feature']] = self.get_value(data_point)
        logger.debug('Push data to mqtt: {}'.format(payload))
        self.forward_msg(payload)

    def _getparsedic(self):
        return {
            'float': read_float
        }

