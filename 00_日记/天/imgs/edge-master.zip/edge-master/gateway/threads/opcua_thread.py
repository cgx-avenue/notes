from utils.log import logger
from utils.util import gettime
from threads.base_protocol_thread import BaseProtocolThread
from opcua import Client


class OpcuaThread(BaseProtocolThread):

    def __init__(self, schema):
        super().__init__(schema)
        self._nodes = []

    def get_end_point(self):
        return 'opc.tcp://{}:{}'.format(self._host, self._port)

    def get_client(self):
        try:
            return Client(self.get_end_point())
        except Exception as e:
            logger.error("OPCUA client create failed: {}".format(self.get_end_point()), exc_info=e)

    def connect(self):
        if self._connected:
            return
        try:
            self._client.connect()
            self._nodes = self.get_nodes()
            self._connected = True
            logger.info('Connected to opcua server: {}'.format(self.get_end_point()))
        except:
            logger.error("OPCUA Server connect failed: {}".format(self.get_end_point()), exc_info=True)
            self._connected = False
        return self._connected

    def get_data_from_server(self):
        values = self._client.get_values(self._nodes)
        # 获取当前时间
        payload = {'timestamp': str(gettime())}
        # 获取数据点
        for i in range(len(values)):
            payload[self._features[i]['feature']] = values[i]
        logger.debug('Push data to mqtt: {}'.format(payload))
        self.forward_msg(payload)

    def get_nodes(self):
        nodes = []
        for feature in self._features:
            node = self._client.get_node(feature['address'])
            nodes.append(node)
        return nodes



'''
{
    "vibDkw": "ns=2;s=SVW_CMS2000_1 VIB1 DKW",
    "vibRms": "ns=2;s=VIB1 RMS",
    "vibMax": "ns=2;s=VIB1 Peak",
    "vibKurtosis": "ns=2;s=VIB1 Kurtosis",
    "vibSkewness": "ns=2;s=VIB1 Skewness",
    "waveIndex": "ns=2;s=VIB1 WaveIndex",
    "peakIndex": "ns=2;s=VIB1 PeakIndex",
    "impulseIndex": "ns=2;s=VIB1 ImpulseIndex",
    "fftRms": "ns=2;s=VIB1 FFTRMS",
    "fftRms10": "ns=2;s=VIB1 FFTRMS-10",
    "fftRms200": "ns=2;s=VIB1 FFTRMS-200",
}
'''