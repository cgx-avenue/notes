import paho.mqtt.client as mqtt
import json
from config import CONFIG
from utils.log import logger


class Sender:
    # 连接
    def __init__(self):
        self._connected = False
        try:
            self._host = CONFIG['MQTT']['HOST']
            self._port = CONFIG['MQTT']['PORT']
            self.client = mqtt.Client(protocol=3)
            self.client.on_message = self._on_message
            self.client.on_connect = self._on_connect
            self.client.on_disconnect = self._on_disconnect
            self.client._clean_session = False
            self.client.connect(self._host, self._port, keepalive=CONFIG['MQTT']['KEEP_ALIVE'])
            self._connected = True
            self.client.loop_start()
            logger.info("Sender mqtt loop starts")
        except:
            logger.error('Connect to mqtt error: {}, {}'.format(self._host, self._port), exc_info=True)

    def _on_message(self, client, userdata, msg):
        pass

    def _on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            logger.info("MQTT server connect successful: {}, {}".format(self._host, self._port))

    def _on_disconnect(self, client, userdata, rc):
        if rc != 0:
            logger.info("MQTT server disconnected: {}, {}".format(self._host, self._port))

    # 发送转换过的payload到data2db mqtt
    def forward_msg(self, topic, payload):
        if not self._connected:
            self.__init__()
        self.client.publish('data/' + topic, json.dumps(payload))


sender = Sender()