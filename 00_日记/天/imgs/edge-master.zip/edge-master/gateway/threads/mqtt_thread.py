import paho.mqtt.client as mqtt
import time
import random

from threads.base_protocol_thread import BaseProtocolThread
from utils.log import logger



class MqttThread(BaseProtocolThread):

    def __init__(self, schema):
        super().__init__(schema)

    def get_client(self):
        client = None
        try:
            client = mqtt.Client(protocol=3,
                                 clean_session=True,
                                 client_id=f'mqtt-thread-{self._table_name}-{random.randint(0, 1000)}')
            client.on_message = self._on_message
            client.on_connect = self._on_connect
            client.on_disconnect = self._on_disconnect
            client._clean_session = False
            client.connect(self._host, self._port, keepalive=60)  # 订阅频道
            client.subscribe(self._topic)
            self._connected = True
            client.loop_start()
        except Exception as e:
            logger.error('Connect to mqtt error: {}, {}, {}'.format(self._host, self._port, self._topic), exc_info=e)
            self._connected = False
        finally:
            return client

    # 从mqtt获取的数据直接传入数据缓存队列
    def _on_message(self, client, userdata, msg):
        try:
            # 根据schema里面的features解析payload
            origin_payload = eval(str(msg.payload, encoding='ascii'))
            # 转发整理好的payload到下一级
            payload = {}
            for feature in self._features:
                # 将TimeStamp转换小写
                if str.lower(feature['feature']) == 'timestamp':
                    payload['timestamp'] = origin_payload[feature['address']]
                else:
                    # timestamp: _time, 左边为数据库字段，右边为mqtt消息
                    payload[feature['feature']] = origin_payload[feature['address']]

            logger.debug('Push data to {} mqtt: {}'.format(self._topic, payload))
            self.forward_msg(payload)
        except Exception as e:
            logger.error("Push data error", exc_info=e)

    def _on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            logger.info("MQTT broker connect successful: {}, {}, {}".format(self._host, self._port, self._topic))

    def _on_disconnect(self, client, userdata, rc):
        if rc != 0:
            logger.info("MQTT broker disconnected: {}, {}, {}".format(self._host, self._port, self._topic))

    def connect(self):
        if self._connected is False:
            logger.info("MQTT client reconnecting. {}, {}, {}".format(self._host, self._port, self._topic))
            self.get_client()
            time.sleep(30)
        return self._connected

    def get_data_from_server(self):
        return super().get_data_from_server()


