from opcua import Client
import time
import threading
from utils.log import logger
import _thread
from utils.util import gettime
from utils.eventmanager import Event, EventManager
import datetime
import os
lock = threading.Lock()
eventManager = EventManager()


def synchronized(func):

    func.__lock__ = threading.Lock()

    def lock_func(*args, **kwargs):
        with func.__lock__:
            return func(*args, **kwargs)
    return lock_func


def _start_read(simpleopcua):
    while True:
        try:
            if not simpleopcua.connected:
                continue
            if simpleopcua.is_restart_xtools_time():
                simpleopcua.restart_xtools()
                simpleopcua.connected = False
                continue
            nodeids = simpleopcua._node_ids
            nodenames = simpleopcua._node_name
            values = simpleopcua._client.get_values(nodeids)
            cur_node_value = {}
            for i in range(len(values)):
                cur_node_value[nodenames[i]] = values[i]
            cur_node_value['timestamp'] = "'"+str(gettime())+"'"
            event = Event(simpleopcua.endpoint)
            event.dict = cur_node_value
            eventManager.SendEvent(event)  # 发送数据
            time.sleep(1.0)
        except Exception as e:
            logger.error("endpoint:" + simpleopcua.endpoint +
                               "|read opcua server data failed ",  exc_info=e)


class SubHandler(object):
    def __init__(self, func):
        self._func = func

    def datachange_notification(self, node, val, data):
        self._func(node, val)


class Simpleopcua():
    _instant = None
    _client = None
    _nodes = {}
    _nodesvalue = {}
    _node_ids = []
    _node_name = []
    _sub = None
    _currentday = int(datetime.datetime.now().strftime('%d'))
    @synchronized
    def __new__(cls, *args, **kwargs):
        if cls._instant is None:
            cls._instant = super().__new__(cls)
        return cls._instant

    def __init__(self, endpoint, is_subscription=True):
        self.endpoint = endpoint
        self.connected = False
        self.is_subscription = is_subscription

    @property
    def client(self):
        if lock.locked() is False:
            try:
                lock.acquire()
                return self._get_client()
            finally:
                lock.release()
        else:
            return self._get_client()

    def is_restart_xtools_time(self):
        tempday = int(datetime.datetime.now().strftime('%d'))
        if tempday > self._currentday:
            self._currentday = tempday
            currenttime = int(datetime.datetime.now().strftime('%H'))
            return currenttime >= 5

    def restart_xtools(self):
        os.system('restartxtools.bat')

    def _get_client(self):
        if(self._client is None):
            self._client = Client(self.endpoint)
            self._client.connect()
            if self.is_subscription == True:
                handle = SubHandler(self.set_node_value)
                self._sub = self._client.create_subscription(500, handle)
            else:
                _thread.start_new_thread(_start_read, (self,))
            self.connected = True
        return self._client

    def add_nodes(self, nodelist):
        for node_name in nodelist:
            if self.is_subscription == True:  # 订阅模式
                if node_name not in self._nodes:
                    nodeid = self.client.get_node(node_name)
                    self._nodes[node_name] = nodeid
                    self._sub.subscribe_data_change(nodeid)
                    self._nodesvalue[nodeid] = 0
            else:  # 集中读取所有数据
                nodeid = self.client.get_node(node_name)
                if nodeid not in self._node_name:
                    self._node_ids.append(nodeid)
                    self._node_name.append(node_name)

    def get_node_value(self, node_name):
        lock.acquire()
        try:
            value = self._nodesvalue[self._nodes[node_name]]
            return value
        except Exception as e:
            print("opc ua client get value failed")
        finally:
            lock.release()

    def set_node_value(self, node_id, node_value):
        lock.acquire()
        try:
            self._nodesvalue[node_id] = node_value
        except Exception as e:
            print("opc ua client set value failed")
        finally:
            lock.release()

    def connect(self):
        try:
            if self.connected:
                return True
            else:
                self.client
                return self.connected
        except Exception as e:
            self.connected = False
