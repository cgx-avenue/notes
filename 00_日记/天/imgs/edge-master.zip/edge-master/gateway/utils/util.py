import requests
import json
import os
import datetime
import importlib


def string_cutoff(strdata, length):
    if len(strdata) < length:
        return strdata
    else:
        return strdata[0:length]


def json_reader(config_filepath):
    
    if not os.path.exists(config_filepath):
        raise Exception('ERROR: Configure file %s does not exist' % config_filepath)

    with open(config_filepath,'r') as load_f:
        load_dict = json.load(load_f)
        return load_dict


def jsonreader_fromweb(url):
    r0 = requests.get(url)
    content =  json.loads(str((r0.content),'utf-8'))
    return content["body"]


def gettime():
    timenow = (datetime.datetime.now()).isoformat()
    timenow = timenow[:-7]
    timenow = timenow.replace('T',' ')
    return timenow


def get_currenttime():
    currenttime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    return currenttime


# format transfer
def formatmodify(data):
    if isinstance(data,str):
        return int(data)
    elif isinstance(data,float):
        return round(data,3)
    elif isinstance(data,int):
        return data


def dynamic_import(module):
    return importlib.import_module(module)
