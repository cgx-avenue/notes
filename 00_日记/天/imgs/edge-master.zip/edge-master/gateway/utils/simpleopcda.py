import OpenOPC
#import pywintypes
import time


#pywintypes.datetime = pywintypes.TimeType

class Simpleopcda:
    
    def __init__(self,server_str,group_name = 'mygroup'):
        self._opc =OpenOPC.client()
        self._opc.connect(server_str)
        self._group =group_name
    
    def singleread(self,address):
        return self._opc.read(address,self._group)
    
    def write(self,addressvalue_dic:dict):
        return self._opc.write(list(addressvalue_dic))
