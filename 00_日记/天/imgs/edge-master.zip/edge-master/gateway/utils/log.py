import logging
from config import LOG_LEVEL


class log():
    _instant = None
    _logFmt = '%(asctime)s.%(msecs)03d %(levelname)s %(filename)s %(funcName)s line=%(lineno)d %(process)d %(message)s'
    _logdatefmt = '%Y-%m-%d,%H:%M:%S'
    _logPath = r'log/gateway.log'
    _loggerlevel = LOG_LEVEL
    _logger = None

    def __new__(cls, *args, **kwargs):
        if cls._instant is None:
            cls._instant = super().__new__(cls)
        return cls._instant

    @property
    def logger(self):
        if self._logger is None:
            logger = logging.getLogger('default')
            logger.setLevel(self._loggerlevel)
            ch = logging.StreamHandler()
            ch.setLevel(logging.DEBUG)
            # create file handler
            fh = logging.FileHandler(self._logPath)
            fh.setLevel(LOG_LEVEL)
            format = logging.Formatter(self._logFmt, self._logdatefmt)
            fh.setFormatter(format)
            ch.setFormatter(format)
            logger.addHandler(fh)
            logger.addHandler(ch)
            self._logger = logger
        return self._logger


logger = log().logger

#if __name__ == '__main__':
#    log().logger.debug("debug test")
#    log().logger.info("info test")
#    log().logger.error("error test")
