import struct
import modbus_tk.defines as cst


def read_float(*args, reverse=False):
    for n, m in args:
        n, m = '%04x' % n, '%04x' % m
    if reverse:
        v = n + m
    else:
        v = m + n
    y_bytes = bytes.fromhex(v)
    y = struct.unpack('!f', y_bytes)[0]
    return round(y, 5)


def float_to_bytes(f):
    bs = struct.pack("f", f)
    return bs[3], bs[2], bs[1], bs[0]


def parse_function_code(type):
    if type == 4:
        return cst.READ_INPUT_REGISTERS
    if type == 3:
        return cst.HOLDING_REGISTERS
    return cst.READ_INPUT_REGISTERS
