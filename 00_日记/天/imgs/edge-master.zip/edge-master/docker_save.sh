# shellcheck disable=SC2164
# shellcheck disable=SC2103
docker save -o data2db.tar daas/data2db
docker save -o schema.tar daas/schema
docker save -o gateway.tar daas/gateway
docker save -o web-config.tar daas/web-config
docker save -o fault-detect.tar daas/fault-detect
