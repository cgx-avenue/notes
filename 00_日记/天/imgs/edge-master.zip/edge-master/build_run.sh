# shellcheck disable=SC2164
# shellcheck disable=SC2103
docker image prune -f
docker-compose down

cd schema
docker build -t daas/schema .
cd ../web_config
docker build -t daas/web-config .
#cd ../simulator
#docker build -t daas/simulator .
cd ../gateway
docker build -t daas/gateway .
cd ../data2db
docker build -t daas/data2db .
cd ../fault_detect
docker build -t daas/fault-detect .
cd ..

docker-compose up -d